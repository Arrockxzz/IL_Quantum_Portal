import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { ClaimRecord, UploadedFileMeta } from '../types';

// Column normalization dictionary mapping variations to standard keys
const COLUMN_MAP: Record<string, string> = {
  'policy': 'policy_name',
  'policy name': 'policy_name',
  'policy_name': 'policy_name',
  'policy no': 'policy_no',
  'policy_no': 'policy_no',
  'iltc': 'iltc_tag',
  'iltc tag': 'iltc_tag',
  'iltc_tag': 'iltc_tag',
  'network': 'whether_hospital_networked',
  'network hospital': 'whether_hospital_networked',
  'whether_hospital_networked': 'whether_hospital_networked',
  'claim no': 'claim_number',
  'claim number': 'claim_number',
  'claim_number': 'claim_number',
  'claimed amt': 'claimed_amount',
  'claimed amount': 'claimed_amount',
  'claimed_amount': 'claimed_amount',
  'approved amt': 'net_sanct_amt',
  'approved amount': 'net_sanct_amt',
  'net_sanct_amt': 'net_sanct_amt',
  'paid amt': 'payment_amount',
  'payment amount': 'payment_amount',
  'payment_amount': 'payment_amount',
  'outstanding amt': 'claim_r_os_amt',
  'claim_r_os_amt': 'claim_r_os_amt',
  'disallowed amt': 'disallowed_amount',
  'disallowed amount': 'disallowed_amount',
  'disallowed_amount': 'disallowed_amount',
  'copayment': 'copayment_amt',
  'copayment amt': 'copayment_amt',
  'copayment_amt': 'copayment_amt',
  'relation': 'relation_group',
  'relation group': 'relation_group',
  'relation_group': 'relation_group',
  'type': 'type_of_claim',
  'type of claim': 'type_of_claim',
  'type_of_claim': 'type_of_claim',
  'status': 'updated_status',
  'updated status': 'updated_status',
  'updated_status': 'updated_status',
  'age band': 'age_band',
  'age_band': 'age_band',
  'disease': 'disease_category',
  'disease category': 'disease_category',
  'disease_category': 'disease_category',
  'ipd opd': 'ipd_opd',
  'ipd/opd': 'ipd_opd',
  'ipd_opd': 'ipd_opd',
  'city': 'hospital_city',
  'hospital city': 'hospital_city',
  'hospital_city': 'hospital_city',
  'state': 'hospital_state',
  'hospital state': 'hospital_state',
  'hospital_state': 'hospital_state',
  'hospital': 'hospital_name',
  'hospital name': 'hospital_name',
  'hospital_name': 'hospital_name',
  'month': '__monthYear',
  'month year': '__monthYear',
  'monthyear': '__monthYear',
  '__monthyear': '__monthYear',
};

function normalizeHeaderKey(key: string): string {
  const cleanKey = key.trim().toLowerCase();
  return COLUMN_MAP[cleanKey] || cleanKey.replace(/\s+/g, '_');
}

export function normalizeRawRow(row: Record<string, any>, defaultMonthYear: string = '2026-07'): ClaimRecord {
  const normalized: any = {
    id: `CLM-${Math.floor(100000 + Math.random() * 900000)}`,
    policy_name: 'Group Health Insurance Premier',
    policy_no: 'POL-GHI-88392',
    iltc_tag: 'ILTC-A1',
    whether_hospital_networked: 'Network',
    claim_number: `CLM-${Math.floor(1000 + Math.random() * 9000)}`,
    claimed_amount: 0,
    net_sanct_amt: 0,
    payment_amount: 0,
    claim_r_os_amt: 0,
    disallowed_amount: 0,
    copayment_amt: 0,
    relation_group: 'Self',
    type_of_claim: 'Cashless',
    updated_status: 'Claim Settled',
    age_band: '31-45 Yrs',
    disease_category: 'General Medicine',
    ipd_opd: 'IPD',
    hospital_city: 'Mumbai',
    hospital_state: 'Maharashtra',
    hospital_name: 'Apollo Hospital',
    reason_for_disallowance: 'None',
    __monthYear: defaultMonthYear,
  };

  Object.keys(row).forEach((rawKey) => {
    const stdKey = normalizeHeaderKey(rawKey);
    let val = row[rawKey];

    if (val !== undefined && val !== null) {
      if (typeof val === 'string') val = val.trim();

      if (['claimed_amount', 'net_sanct_amt', 'payment_amount', 'claim_r_os_amt', 'disallowed_amount', 'copayment_amt'].includes(stdKey)) {
        const num = parseFloat(String(val).replace(/[^0-9.-]+/g, ''));
        normalized[stdKey] = isNaN(num) ? 0 : num;
      } else {
        normalized[stdKey] = String(val);
      }
    }
  });

  return normalized as ClaimRecord;
}

export function parseCsvFile(file: File): Promise<ClaimRecord[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const records: ClaimRecord[] = results.data.map((row: any) => normalizeRawRow(row));
          resolve(records);
        } catch (err) {
          reject(err);
        }
      },
      error: (error) => reject(error),
    });
  });
}

export function parseExcelFile(file: File): Promise<ClaimRecord[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const allRecords: ClaimRecord[] = [];

        workbook.SheetNames.forEach((sheetName) => {
          const sheet = workbook.Sheets[sheetName];
          const jsonRows: any[] = XLSX.utils.sheet_to_json(sheet);
          jsonRows.forEach((row) => {
            allRecords.push(normalizeRawRow(row));
          });
        });

        resolve(allRecords);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
