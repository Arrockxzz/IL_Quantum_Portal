import { PortalSettings } from '../types';

export interface ChartPaletteColors {
  primary: string;
  secondary: string;
  tertiary: string;
  quaternary: string;
  accent: string;
  gradientFrom: string;
  gradientTo: string;
}

export const CHART_PALETTES: Record<string, ChartPaletteColors> = {
  'enterprise-blue': {
    primary: '#2563eb',   // Cobalt Executive Blue
    secondary: '#06b6d4', // Vibrant Cyan / Teal
    tertiary: '#4f46e5',  // Indigo Blue
    quaternary: '#f59e0b',// Amber Gold
    accent: '#10b981',   // Emerald Green
    gradientFrom: '#2563eb',
    gradientTo: '#0284c7',
  },
  'neon-cyber': {
    primary: '#00f0ff',   // Electric Cyan
    secondary: '#ff007f', // Cyber Pink
    tertiary: '#7000ff',  // Deep Violet
    quaternary: '#00ff66',// Matrix Emerald
    accent: '#ffaa00',   // Amber Gold
    gradientFrom: '#00f0ff',
    gradientTo: '#7000ff',
  },
  'il-sunset': {
    primary: '#ea580c',   // Orange 600
    secondary: '#dc2626', // Red 600
    tertiary: '#d97706',  // Amber 600
    quaternary: '#e11d48',// Rose 600
    accent: '#f59e0b',   // Amber 500
    gradientFrom: '#ea580c',
    gradientTo: '#dc2626',
  },
  'matrix-green': {
    primary: '#10b981',   // Emerald
    secondary: '#06b6d4', // Cyan
    tertiary: '#84cc16',  // Lime
    quaternary: '#14b8a6',// Teal
    accent: '#22c55e',   // Green
    gradientFrom: '#10b981',
    gradientTo: '#06b6d4',
  },
  'ai-aurora': {
    primary: '#8b5cf6',   // Purple
    secondary: '#ec4899', // Pink
    tertiary: '#3b82f6',  // Blue
    quaternary: '#a855f7',// Violet
    accent: '#f43f5e',   // Rose
    gradientFrom: '#8b5cf6',
    gradientTo: '#ec4899',
  },
  'monochrome-steel': {
    primary: '#38bdf8',   // Sky
    secondary: '#94a3b8', // Slate
    tertiary: '#64748b',  // Dark Slate
    quaternary: '#00f0ff',// Cyan
    accent: '#e2e8f0',   // Light
    gradientFrom: '#38bdf8',
    gradientTo: '#64748b',
  },
};

export function getChartPalette(paletteKey?: string): ChartPaletteColors {
  if (paletteKey && CHART_PALETTES[paletteKey]) {
    return CHART_PALETTES[paletteKey];
  }
  return CHART_PALETTES['il-sunset'];
}

export function getThemeAccentColors(themePreset?: string) {
  switch (themePreset) {
    case 'enterprise-blue':
      return {
        brandText: 'text-blue-600',
        brandBg: 'bg-blue-600',
        brandBorder: 'border-blue-500',
        glowShadow: 'shadow-[0_0_20px_rgba(37,99,235,0.25)]',
        accentHex: '#2563eb',
      };
    case 'cyber-quantum':
      return {
        brandText: 'text-cyan-400',
        brandBg: 'bg-cyan-600',
        brandBorder: 'border-cyan-500',
        glowShadow: 'shadow-[0_0_20px_rgba(0,240,255,0.25)]',
        accentHex: '#00f0ff',
      };
    case 'neon-matrix':
      return {
        brandText: 'text-emerald-400',
        brandBg: 'bg-emerald-600',
        brandBorder: 'border-emerald-500',
        glowShadow: 'shadow-[0_0_20px_rgba(16,185,129,0.25)]',
        accentHex: '#10b981',
      };
    case 'deep-cosmos':
      return {
        brandText: 'text-purple-400',
        brandBg: 'bg-purple-600',
        brandBorder: 'border-purple-500',
        glowShadow: 'shadow-[0_0_20px_rgba(168,85,247,0.25)]',
        accentHex: '#a855f7',
      };
    case 'high-tech-dark':
      return {
        brandText: 'text-slate-200',
        brandBg: 'bg-slate-700',
        brandBorder: 'border-slate-500',
        glowShadow: 'shadow-[0_0_20px_rgba(255,255,255,0.15)]',
        accentHex: '#94a3b8',
      };
    case 'il-orange':
    default:
      return {
        brandText: 'text-orange-600',
        brandBg: 'bg-orange-600',
        brandBorder: 'border-orange-500',
        glowShadow: 'shadow-[0_0_20px_rgba(234,88,12,0.25)]',
        accentHex: '#ea580c',
      };
  }
}
