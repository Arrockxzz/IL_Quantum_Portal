import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { MetricKpis, DepartmentData, RegionalMetric } from '../types';

export function generateDashboardPdfReport(
  kpis: MetricKpis,
  departments: DepartmentData[],
  regions: RegionalMetric[]
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Header Banner
  doc.setFillColor(79, 70, 229); // Indigo-600
  doc.rect(0, 0, 210, 24, 'F');

  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text('ICICI Lombard | IL QUANTUM Portal Executive Report', 14, 15);

  const formattedDate = new Date().toLocaleString('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Generated: ${formattedDate}`, 196, 15, { align: 'right' });

  // Subheader / System status bar
  doc.setFillColor(248, 250, 252);
  doc.rect(0, 24, 210, 12, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.line(0, 36, 210, 36);

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.text('Cluster Node: us-east-1a (LIVE UPDATING)', 14, 31.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(
    `Throughput: ${kpis.requestsPerSec.toLocaleString()} req/s  |  Avg Latency: ${kpis.latencyMs}ms  |  Uptime: ${kpis.uptimePercent}%`,
    85,
    31.5
  );

  // Section 1: Executive KPI Metrics
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('1. Key Performance Indicators (KPIs)', 14, 45);

  const formatCurrency = (val: number) => `$${val.toLocaleString()}`;

  const kpiData = [
    [
      'Annual Recurring Revenue (ARR)',
      formatCurrency(kpis.arr),
      `+${kpis.arrGrowthYoY}% YoY`,
      'Exceeding Target (+14.2%)',
    ],
    [
      'Monthly Recurring Revenue (MRR)',
      formatCurrency(kpis.mrr),
      '+2.8% MoM',
      'Target: $1,250,000',
    ],
    [
      'Active User Base',
      kpis.activeUsers.toLocaleString(),
      `+${kpis.activeUsersTodayDelta} today`,
      '+14.2% MoM Growth',
    ],
    [
      'System Uptime & Health',
      `${kpis.uptimePercent}%`,
      'Optimal',
      'Target: 99.99%',
    ],
    [
      'Customer NPS Score',
      `${kpis.npsScore} / 100`,
      'Top 5% SaaS',
      `Churn Rate: ${kpis.churnRatePercent}%`,
    ],
  ];

  autoTable(doc, {
    startY: 48,
    head: [['Metric Name', 'Current Value', 'Change / Status', 'Benchmark / Target']],
    body: kpiData,
    theme: 'grid',
    headStyles: {
      fillColor: [79, 70, 229],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
    bodyStyles: {
      textColor: [15, 23, 42],
      fontSize: 8,
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 14, right: 14 },
  });

  // Section 2: Top-Performing Departments & Division Breakdown
  let currentY = (doc as any).lastAutoTable.finalY + 10;

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('2. Top-Performing Departments & Division Breakdown', 14, currentY);

  // Sort departments by attainment (revenue / target)
  const sortedDepts = [...departments].sort(
    (a, b) => b.revenue / b.target - a.revenue / a.target
  );

  const deptData = sortedDepts.map((d, index) => {
    const pct = Math.round((d.revenue / d.target) * 100);
    const rankLabel = index === 0 ? '🏆 Top Performer' : `#${index + 1}`;
    return [
      rankLabel,
      d.name,
      d.lead,
      `$${(d.revenue / 1000000).toFixed(2)}M`,
      `$${(d.target / 1000000).toFixed(2)}M`,
      `${pct}%`,
      `+${d.growthYoY}%`,
      `${d.healthScore}/100`,
    ];
  });

  autoTable(doc, {
    startY: currentY + 4,
    head: [
      ['Rank', 'Department', 'Lead', 'YTD Revenue', 'Target', 'Attainment', 'YoY Growth', 'Health'],
    ],
    body: deptData,
    theme: 'grid',
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
    bodyStyles: {
      textColor: [15, 23, 42],
      fontSize: 8,
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 14, right: 14 },
  });

  // Section 3: Regional Distribution
  currentY = (doc as any).lastAutoTable.finalY + 10;

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('3. Regional Revenue & Active User Distribution', 14, currentY);

  const regionData = regions.map((r) => [
    r.region,
    `$${r.revenue.toLocaleString()}`,
    `+${r.growth}%`,
    r.activeUsers.toLocaleString(),
    `${r.uptime}%`,
  ]);

  autoTable(doc, {
    startY: currentY + 4,
    head: [['Region', 'Revenue ($)', 'Growth YoY', 'Active Users', 'Uptime %']],
    body: regionData,
    theme: 'grid',
    headStyles: {
      fillColor: [79, 70, 229],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
    bodyStyles: {
      textColor: [15, 23, 42],
      fontSize: 8,
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 14, right: 14 },
  });

  // Section 4: Executive Insights Summary
  currentY = (doc as any).lastAutoTable.finalY + 10;

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('4. Executive Summary & Actionable Recommendations', 14, currentY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const topDept = sortedDepts[0];
  const bullet1 = `• Top Performing Division: ${topDept?.name} is leading attainment at ${Math.round(
    ((topDept?.revenue || 0) / (topDept?.target || 1)) * 100
  )}% of target with +${topDept?.growthYoY}% YoY growth under lead ${topDept?.lead}.`;
  const bullet2 = `• Revenue Trajectory: ARR sits at ${formatCurrency(
    kpis.arr
  )} with strong +${kpis.arrGrowthYoY}% YoY momentum driven by enterprise cloud and AI suite expansions.`;
  const bullet3 = `• System Performance: Latency is stable at ${kpis.latencyMs}ms with ${kpis.uptimePercent}% uptime across all active cluster nodes.`;

  doc.text(bullet1, 14, currentY + 6);
  doc.text(bullet2, 14, currentY + 11);
  doc.text(bullet3, 14, currentY + 16);

  // Footer / Page Numbers
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `DATAFLOW Platform — Executive Summary Report  |  Page ${i} of ${totalPages}`,
      105,
      288,
      { align: 'center' }
    );
  }

  // Trigger file download
  const dateStamp = new Date().toISOString().split('T')[0];
  doc.save(`DATAFLOW_Executive_Report_${dateStamp}.pdf`);
}
