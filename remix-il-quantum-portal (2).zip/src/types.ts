export interface MetricKpis {
  arr: number; // Annual Recurring Revenue ($)
  mrr: number; // Monthly Recurring Revenue ($)
  arrGrowthYoY: number; // %
  activeUsers: number;
  activeUsersTodayDelta: number;
  latencyMs: number; // ms
  uptimePercent: number; // %
  churnRatePercent: number; // %
  npsScore: number;
  requestsPerSec: number;
}

export interface TimeSeriesPoint {
  time: string;
  arr: number;
  mrr: number;
  cloudRevenue: number;
  aiRevenue: number;
  saasRevenue: number;
  latencyMs: number;
  requestsPerSec: number;
}

export interface DepartmentData {
  id: string;
  name: string;
  iconName: string;
  revenue: number;
  target: number;
  growthYoY: number;
  activeProjects: number;
  healthScore: number; // 0 - 100
  headcount: number;
  lead: string;
  topMetric: string;
}

export interface RegionalMetric {
  code: string;
  region: string;
  revenue: number;
  growth: number;
  activeUsers: number;
  uptime: number;
  flagEmoji: string;
}

export interface RealTimeLog {
  id: string;
  timestamp: string;
  type: 'sale' | 'signup' | 'system' | 'alert' | 'deployment';
  title: string;
  detail: string;
  value?: string;
  region?: string;
  status: 'success' | 'info' | 'warning' | 'error';
}

export interface FilterState {
  department: string; // 'all' | department id
  region: string; // 'all' | region code
  timeRange: '24h' | '7d' | '30d' | 'YTD';
  simulationSpeedMs: number; // e.g. 2000 (2s), 0 for paused
  isPaused: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: string;
  suggestedActions?: string[];
  isError?: boolean;
}

export type PageStep = 'HOMEPAGE' | 'NAVIGATION' | 'DASHBOARD';

export interface ClaimRecord {
  id: string;
  policy_name: string;
  policy_no: string;
  iltc_tag: string;
  whether_hospital_networked: string;
  claim_number: string;
  claimed_amount: number;
  net_sanct_amt: number;
  payment_amount: number;
  claim_r_os_amt: number;
  disallowed_amount: number;
  copayment_amt: number;
  relation_group: string;
  type_of_claim: string;
  updated_status: string;
  age_band: string;
  disease_category: string;
  ipd_opd: string;
  hospital_city: string;
  hospital_state: string;
  hospital_name: string;
  reason_for_disallowance?: string;
  __monthYear: string;
  [key: string]: any;
}

export interface UploadedFileMeta {
  id: string;
  name: string;
  type: string;
  size: number;
  rawSize: string;
  status: 'Queued' | 'Processing' | 'Uploaded' | 'Empty' | 'Error';
  monthYear: string;
  rowCount: number;
  progress: number;
  errorMessage?: string;
}

export interface GlobalSlicerFilters {
  policy_name: string[];
  policy_no: string[];
  iltc_tag: string[];
  whether_hospital_networked: string[];
  relation_group: string[];
  type_of_claim: string[];
  updated_status: string[];
  age_band: string[];
  disease_category: string[];
  ipd_opd: string[];
  __monthYear: string[];
}

export interface PortalSettings {
  themePreset: 'enterprise-blue' | 'il-orange' | 'cyber-quantum' | 'neon-matrix' | 'deep-cosmos' | 'high-tech-dark';
  colorScheme: 'default' | 'vibrant' | 'monochrome';
  chartPalette: 'enterprise-blue' | 'neon-cyber' | 'il-sunset' | 'matrix-green' | 'ai-aurora' | 'monochrome-steel';
  backgroundStyle: 'enterprise-blue' | 'cyber-grid' | 'holo-matrix' | 'dark-synth' | 'glass-white';
  enableParticles: boolean;
  enableScanlines: boolean;
  enableGlowEffects: boolean;
  chartAnimationSpeed: 'fast' | 'normal' | 'smooth';
  darkMode: boolean;
  fontSize: 'small' | 'medium' | 'large';
  topNLimit: number;
  maxFileSizeMb: number;
}

export interface CustomChartConfig {
  chartType: 'bar' | 'pie' | 'line' | 'horizontalBar';
  xAxis: string;
  yAxis: string;
  groupDimension: string;
  topN: number;
}

