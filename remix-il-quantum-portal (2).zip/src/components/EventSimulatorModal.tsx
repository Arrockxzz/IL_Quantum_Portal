import React, { useState } from 'react';
import { Zap, X, AlertTriangle, TrendingUp, Radio, Rocket, DollarSign } from 'lucide-react';

interface EventSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerPreset: (eventType: string) => void;
  onTriggerCustom: (title: string, detail: string, value: string, impactType: 'growth' | 'anomaly' | 'deployment') => void;
}

export const EventSimulatorModal: React.FC<EventSimulatorModalProps> = ({
  isOpen,
  onClose,
  onTriggerPreset,
  onTriggerCustom,
}) => {
  const [customTitle, setCustomTitle] = useState('');
  const [customDetail, setCustomDetail] = useState('');
  const [customValue, setCustomValue] = useState('');
  const [impactType, setImpactType] = useState<'growth' | 'anomaly' | 'deployment'>('growth');

  if (!isOpen) return null;

  const presets = [
    {
      id: 'enterprise_contract',
      title: '🚀 Global Enterprise Policy Contract Approved',
      description: 'Matrix sync with Fortune 500 company on 3-year Titan Plan (+$120,000/yr)',
      badge: '+$120k/yr ARR',
      icon: DollarSign,
      color: 'border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-950/60 text-emerald-300',
    },
    {
      id: 'viral_launch',
      title: '⚡ Matrix Portal Spike - 2,400 Signups',
      description: 'Surge of 2,400 new subscriber claims within 10 minutes & 3x node throughput spike',
      badge: '+2,400 Users',
      icon: Rocket,
      color: 'border-cyan-500/40 hover:border-cyan-400 hover:bg-cyan-950/60 text-cyan-300',
    },
    {
      id: 'latency_spike',
      title: '⚠️ APAC Claim Node Latency Anomaly',
      description: 'Simulate regional fiber degradation causing 95ms latency surge to test AI bot',
      badge: '95ms Anomaly',
      icon: AlertTriangle,
      color: 'border-amber-500/40 hover:border-amber-400 hover:bg-amber-950/60 text-amber-300',
    },
    {
      id: 'cluster_autoscale',
      title: '🛡️ Automated Cyber Infra Self-Healing',
      description: 'Provision 12 new GPU cluster nodes & auto-reroute European claim streams',
      badge: 'Uptime 99.99%',
      icon: Radio,
      color: 'border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-950/60 text-emerald-300',
    },
  ];

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;
    onTriggerCustom(customTitle, customDetail || 'Custom simulated event injected into Matrix core', customValue || 'Impact Live', impactType);
    setCustomTitle('');
    setCustomDetail('');
    setCustomValue('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm font-mono">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl p-6 shadow-2xl relative text-slate-800 animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-orange-600 text-white rounded-xl shadow-2xs">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight text-slate-900 uppercase">REAL-TIME EVENT INJECTOR</h2>
              <p className="text-xs text-slate-500 font-medium">Inject telemetry surges, server load spikes, or claim approvals</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preset Presets List */}
        <div className="my-5 space-y-3">
          <label className="text-xs font-black text-orange-700 uppercase tracking-widest">
            Quick One-Click Matrix Simulations
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {presets.map((preset) => (
              <button
                key={preset.id}
                onClick={() => {
                  onTriggerPreset(preset.id);
                  onClose();
                }}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-orange-50/60 hover:border-orange-300 transition-all text-left flex flex-col justify-between hover:scale-[1.01] active:scale-95 cursor-pointer shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-black text-slate-900">{preset.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-normal">{preset.description}</p>
                </div>
                <span className="mt-2 text-[10px] font-mono font-bold text-orange-800 bg-orange-100 px-2 py-0.5 rounded w-fit border border-orange-200 shadow-2xs">
                  {preset.badge}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Event Builder */}
        <form onSubmit={handleCustomSubmit} className="pt-4 border-t border-slate-200 space-y-3">
          <label className="text-xs font-black text-slate-800 uppercase tracking-widest block">
            Custom Event Generator
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Event Title (e.g. Q4 Regional Approval)"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-orange-500 font-mono"
              required
            />
            <input
              type="text"
              placeholder="Value / Delta (e.g. +$45,000)"
              value={customValue}
              onChange={(e) => setCustomValue(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-orange-500 font-mono"
            />
          </div>

          <textarea
            placeholder="Event Detail Description..."
            value={customDetail}
            onChange={(e) => setCustomDetail(e.target.value)}
            rows={2}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-orange-500 font-mono"
          />

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2 text-xs text-slate-700 font-medium">
              <span>Type:</span>
              <select
                value={impactType}
                onChange={(e) => setImpactType(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 text-slate-800 rounded-lg px-2 py-1 text-xs focus:outline-none font-mono cursor-pointer"
              >
                <option value="growth">📈 Claim Approval Surge</option>
                <option value="anomaly">⚠️ Latency Anomaly</option>
                <option value="deployment">🚀 Matrix Subroutine</option>
              </select>
            </div>

            <button
              type="submit"
              className="bg-orange-600 hover:bg-orange-500 text-white font-black px-4 py-2 rounded-xl text-xs transition-all shadow-2xs cursor-pointer"
            >
              INJECT EVENT
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
