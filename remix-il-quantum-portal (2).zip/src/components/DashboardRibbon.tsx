import React, { useState, useRef } from 'react';
import { ChevronLeft, Home, ChevronRight, Menu, FileSpreadsheet, Settings, LogOut, Search, X, Cpu, ChevronDown, Terminal, Radio, SlidersHorizontal } from 'lucide-react';

interface DashboardRibbonProps {
  currentModule: string;
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
  onNavigateBack: () => void;
  onNavigateNext: () => void;
  onOpenFilePicker: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  isDemoMode?: boolean;
  onToggleDemoMode?: () => void;
}

export const DashboardRibbon: React.FC<DashboardRibbonProps> = ({
  currentModule,
  onSelectModule,
  onGoHome,
  onNavigateBack,
  onNavigateNext,
  onOpenFilePicker,
  onOpenSettings,
  onLogout,
  isDemoMode = false,
  onToggleDemoMode,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [menuSearch, setMenuSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Health Claim');

  const menuTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMenuMouseEnter = () => {
    if (menuTimeoutRef.current) clearTimeout(menuTimeoutRef.current);
    setIsMenuOpen(true);
  };

  const handleMenuMouseLeave = () => {
    menuTimeoutRef.current = setTimeout(() => {
      setIsMenuOpen(false);
    }, 200);
  };

  const menuCategories = [
    {
      id: 'Health Claim',
      name: 'Health Claim Matrix',
      submodules: ['GHI Summary', 'Retail Health', 'Claim Rejections', 'OPD Tracker'],
    },
    {
      id: 'Muse Data',
      name: 'Muse Neural Data',
      submodules: ['Policy Ingestion', 'Loss Ratio Summary', 'Underwriting Data'],
    },
    {
      id: 'HCU',
      name: 'HCU Quantum Unit',
      submodules: ['Network Hospitals', 'Tariff Master', 'Pre-Auth Audit'],
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white text-slate-900 shadow-sm border-b border-slate-200 font-mono">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-[54px] flex items-center justify-between">
        
        {/* Left Section: Portal Menu & ICICI Lombard Logo & Brand Name */}
        <div className="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
          
          {/* Module Menu Hover Dropdown */}
          <div
            className="relative"
            onMouseEnter={handleMenuMouseEnter}
            onMouseLeave={handleMenuMouseLeave}
          >
            <button
              id="dashboard-menu-btn"
              className={`flex items-center px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                isMenuOpen
                  ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
              }`}
            >
              <Menu className="w-4 h-4 mr-1.5" />
              <span>PORTAL MENU</span>
            </button>

            {/* Menu Panel with Transparent Hover Bridge */}
            {isMenuOpen && (
              <div
                className="absolute left-0 mt-1 w-72 bg-white border border-slate-200 text-slate-900 rounded-xl shadow-xl z-50 p-3 space-y-2 text-xs font-mono"
                onMouseEnter={handleMenuMouseEnter}
                onMouseLeave={handleMenuMouseLeave}
              >
                {/* Search Menu Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={menuSearch}
                    onChange={(e) => setMenuSearch(e.target.value)}
                    placeholder="Filter portal modules..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-7 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 font-mono"
                  />
                  {menuSearch && (
                    <button
                      onClick={() => setMenuSearch('')}
                      className="absolute right-2 top-2 text-slate-400 hover:text-slate-700"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Categories & Submodules */}
                <div className="space-y-1 pt-1 max-h-64 overflow-y-auto">
                  {menuCategories
                    .filter(
                      (cat) =>
                        cat.name.toLowerCase().includes(menuSearch.toLowerCase()) ||
                        cat.submodules.some((s) => s.toLowerCase().includes(menuSearch.toLowerCase()))
                    )
                    .map((cat) => (
                      <div key={cat.id} className="space-y-1">
                        <button
                          onClick={() => setActiveCategory(cat.id)}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg font-bold text-left transition-colors cursor-pointer ${
                            activeCategory === cat.id
                              ? 'bg-blue-50 text-blue-700 font-black border border-blue-200'
                              : 'text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <span>{cat.name}</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>

                        {/* Submodules list */}
                        {activeCategory === cat.id && (
                          <div className="pl-3 space-y-1 border-l-2 border-blue-400 my-1">
                            {cat.submodules.map((sub) => (
                              <button
                                key={sub}
                                onClick={() => {
                                  onSelectModule(`${cat.name} > ${sub}`);
                                  setIsMenuOpen(false);
                                }}
                                className={`w-full text-left px-2 py-1 rounded text-[11px] transition-colors cursor-pointer ${
                                  currentModule.includes(sub)
                                    ? 'bg-blue-100 text-blue-900 font-bold'
                                    : 'text-slate-600 hover:text-blue-700 hover:bg-slate-50'
                                }`}
                              >
                                • {sub}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>

          <div
            onClick={onGoHome}
            className="w-9 h-9 bg-blue-600 hover:bg-blue-500 rounded-lg flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
            title="ICICI Lombard IL QUANTUM Matrix Portal"
          >
            <Cpu className="w-5 h-5 text-white animate-pulse" />
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-sm font-black tracking-wider text-slate-900 uppercase font-mono">
              ICICI LOMBARD
            </span>
            <span className="hidden sm:inline-block text-xs font-bold text-blue-600 border-l border-slate-200 pl-2">
              QUANTUM PORTAL
            </span>
          </div>
        </div>

        {/* Center/Right Section: Controls & Navigation */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Home Compact Controller [‹ 🏠 ›] */}
          <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs shadow-2xs">
            <button
              onClick={onNavigateBack}
              className="p-1 hover:bg-slate-200 rounded transition-colors text-slate-700 hover:text-slate-900 cursor-pointer"
              title="Previous Page"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onGoHome}
              className="px-2 py-1 hover:bg-slate-200 rounded transition-colors text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
              title="Home Gate"
            >
              <Home className="w-3.5 h-3.5 text-blue-600" />
            </button>
            <button
              onClick={onNavigateNext}
              className="p-1 hover:bg-slate-200 rounded transition-colors text-slate-700 hover:text-slate-900 cursor-pointer"
              title="Next Page"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Excel File Upload Trigger Icon [📊 Ingest] */}
          <button
            id="excel-upload-trigger-btn"
            onClick={onOpenFilePicker}
            className="flex items-center px-3 py-1.5 rounded-lg text-xs font-black bg-blue-600 hover:bg-blue-500 text-white border border-blue-500 shadow-2xs transition-all active:scale-95 cursor-pointer"
            title="Upload CSV / XLSX Claim Files"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-white" />
            <span>INGEST FILE</span>
          </button>

          {/* Tiny Demo Dashboard Slider Toggle Button (Icon Only) */}
          <button
            id="demo-dashboard-toggle-slider-btn"
            onClick={onToggleDemoMode}
            className={`p-2 rounded-lg border transition-all cursor-pointer flex items-center justify-center active:scale-95 shadow-2xs ${
              isDemoMode
                ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-500 ring-2 ring-blue-400/30'
                : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200 hover:text-slate-800'
            }`}
            title={isDemoMode ? "Demo Dashboard: ON (Click to turn OFF)" : "Demo Dashboard: OFF (Click to turn ON)"}
            aria-label="Toggle Demo Dashboard Mode"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              id="user-profile-btn"
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center space-x-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-800 transition-all cursor-pointer"
              title="Operator Profile"
            >
              <div className="w-5 h-5 bg-blue-600 text-white font-black rounded-full flex items-center justify-center text-[10px]">
                AS
              </div>
              <span className="hidden sm:inline-block font-mono">Ankit Sharma</span>
              <ChevronDown className="w-3 h-3 text-slate-500" />
            </button>

            {/* Profile Popup Overlay */}
            {isUserMenuOpen && (
              <div className="absolute right-0 mt-1 w-60 bg-white border border-slate-200 text-slate-900 rounded-xl shadow-xl z-50 p-3 space-y-3 text-xs font-mono">
                
                {/* User Header with Settings Icon beside Name */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div>
                    <div className="font-bold text-slate-900 text-sm">Ankit Sharma</div>
                    <div className="text-[10px] text-blue-600 font-bold flex items-center">
                      <Terminal className="w-3 h-3 mr-1 text-blue-600" /> MATRIX OPERATOR
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors border border-slate-300 cursor-pointer"
                    title="Dashboard Settings"
                  >
                    <Settings className="w-4 h-4 text-slate-700" />
                  </button>
                </div>

                {/* Profile Actions */}
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-slate-700 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5 text-slate-600" />
                    <span>Portal Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors font-bold cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Exit Session</span>
                  </button>
                </div>

              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};

