import React, { useState, useEffect } from 'react';
import { Database, Cpu, Zap, Activity, ShieldCheck, Sparkles, RefreshCw, BarChart3, LineChart, Layers, ArrowRight } from 'lucide-react';
import { PortalSettings } from '../types';
import { getThemeAccentColors } from '../utils/themeConfig';

interface FuturisticLandingHeroProps {
  onActivateDemo: () => void;
  onOpenFilePicker: () => void;
  settings: PortalSettings;
}

export const FuturisticLandingHero: React.FC<FuturisticLandingHeroProps> = ({
  onActivateDemo,
  onOpenFilePicker,
  settings,
}) => {
  const [pulsePhase, setPulsePhase] = useState(0);
  const [activeChartTab, setActiveChartTab] = useState<'neural' | 'throughput' | 'risk'>('neural');

  useEffect(() => {
    const interval = setInterval(() => {
      setPulsePhase((prev) => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const accentColors = getThemeAccentColors(settings.themePreset);

  return (
    <div className="relative min-h-[65vh] flex flex-col items-center justify-center p-6 sm:p-10 bg-slate-900/90 text-white border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-4 backdrop-blur-xl">
      
      {/* Background Animated Holographic AI Radar Rings */}
      <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full border border-blue-500/20 animate-spin-slow pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full border border-blue-500/10 pointer-events-none" />

      {/* Main Title Block */}
      <div className="relative z-10 text-center space-y-3 max-w-3xl">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-blue-950/60 border border-blue-500/40 text-blue-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
          <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
          <span>QUANTUM NEURAL ENGINE • ONLINE</span>
        </div>

        <h2 className="text-[45px] font-bold text-center text-blue-500 font-['Mulish',sans-serif] tracking-normal leading-tight drop-shadow-[0_0_25px_rgba(37,99,235,0.3)]">
          IL QUANTUM PORTAL
        </h2>

        <p className="text-[16px] font-medium text-slate-200 dark:text-slate-100 font-['Mulish',sans-serif] text-center max-w-xl mx-auto">
          A Unified Data Hub for Intelligent Decisions
        </p>
      </div>

      {/* Interactive AI Data Neural Chart & Graphic HUD Component */}
      <div className="relative z-10 w-full max-w-4xl mt-8 bg-slate-950/80 border border-slate-800 rounded-2xl p-5 shadow-2xl backdrop-blur-md">
        
        {/* HUD Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between pb-3 mb-4 border-b border-slate-800 gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="font-mono text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-orange-500" /> REAL-TIME AI TELEMETRY STREAM
            </span>
          </div>

          {/* Interactive Graphic Selector */}
          <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setActiveChartTab('neural')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer font-bold ${
                activeChartTab === 'neural' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Neural Waveform
            </button>
            <button
              onClick={() => setActiveChartTab('throughput')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer font-bold ${
                activeChartTab === 'throughput' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Slicer Bars
            </button>
            <button
              onClick={() => setActiveChartTab('risk')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer font-bold ${
                activeChartTab === 'risk' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Risk Vector
            </button>
          </div>
        </div>

        {/* Animated Graphic Canvas Render Area */}
        <div className="relative h-48 sm:h-56 w-full rounded-xl bg-slate-900/90 border border-slate-800/80 p-4 flex flex-col justify-between overflow-hidden">
          
          {/* Scanline Grid Overlay */}
          <div className="absolute inset-0 bg-scanlines opacity-10 pointer-events-none" />

          {activeChartTab === 'neural' && (
            <div className="relative z-10 h-full flex flex-col justify-between">
              {/* Dynamic Animated Wave SVG */}
              <svg className="w-full h-32 overflow-visible" viewBox="0 0 500 100" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="waveGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#ea580c" stopOpacity="0.8" />
                    <stop offset="50%" stopColor="#00f0ff" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.8" />
                  </linearGradient>
                </defs>
                
                {/* Background Grid Lines */}
                <line x1="0" y1="20" x2="500" y2="20" stroke="#1e293b" strokeDasharray="4 4" />
                <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" strokeDasharray="4 4" />
                <line x1="0" y1="80" x2="500" y2="80" stroke="#1e293b" strokeDasharray="4 4" />

                {/* Animated Sine Wave path */}
                <path
                  d={`M 0 50 Q 125 ${50 + Math.sin(pulsePhase * 0.1) * 35}, 250 50 T 500 50`}
                  fill="none"
                  stroke="url(#waveGrad)"
                  strokeWidth="3.5"
                />

                {/* Glowing Nodes */}
                {[50, 150, 250, 350, 450].map((x, idx) => {
                  const y = 50 + Math.sin((pulsePhase + idx * 20) * 0.1) * 30;
                  return (
                    <g key={idx}>
                      <circle cx={x} cy={y} r="6" fill="#ea580c" className="animate-pulse" />
                      <circle cx={x} cy={y} r="12" fill="#ea580c" opacity="0.25" />
                    </g>
                  );
                })}
              </svg>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-slate-800 pt-2">
                <span className="flex items-center gap-1"><Zap className="w-3.5 h-3.5 text-amber-400" /> Neural Pipeline Latency: 0.42ms</span>
                <span className="flex items-center gap-1"><Activity className="w-3.5 h-3.5 text-cyan-400" /> Throughput: 1.2M events/sec</span>
                <span className="text-emerald-400 font-bold">ACCURACY: 99.98%</span>
              </div>
            </div>
          )}

          {activeChartTab === 'throughput' && (
            <div className="relative z-10 h-full flex flex-col justify-between">
              {/* Dynamic Animated Bar Chart Columns */}
              <div className="h-32 flex items-end justify-between gap-3 px-4 pt-2">
                {[
                  { label: 'Hospital Network', val: 85 + Math.sin(pulsePhase * 0.1) * 10, color: 'bg-orange-500' },
                  { label: 'Disease Category', val: 92 + Math.cos(pulsePhase * 0.08) * 8, color: 'bg-cyan-500' },
                  { label: 'Policy Type', val: 78 + Math.sin(pulsePhase * 0.12) * 12, color: 'bg-emerald-500' },
                  { label: 'ILTC Tagging', val: 95 + Math.cos(pulsePhase * 0.15) * 5, color: 'bg-purple-500' },
                  { label: 'Copayment Index', val: 70 + Math.sin(pulsePhase * 0.09) * 15, color: 'bg-amber-500' },
                  { label: 'Settlement Speed', val: 88 + Math.cos(pulsePhase * 0.11) * 10, color: 'bg-rose-500' },
                ].map((bar, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group">
                    <span className="text-[10px] font-mono font-bold text-slate-300 mb-1">{Math.round(bar.val)}%</span>
                    <div className="w-full bg-slate-800 rounded-t-md overflow-hidden h-24 flex items-end">
                      <div
                        className={`w-full ${bar.color} rounded-t-md transition-all duration-300 shadow-[0_0_12px_rgba(255,255,255,0.2)]`}
                        style={{ height: `${bar.val}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-slate-400 truncate w-full text-center mt-1">{bar.label}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-slate-800 pt-2">
                <span>11-Field Slicer Indexing: ACTIVE</span>
                <span className="text-orange-400 font-bold">100% Real-Time Data Sync</span>
              </div>
            </div>
          )}

          {activeChartTab === 'risk' && (
            <div className="relative z-10 h-full flex items-center justify-around">
              <div className="flex items-center space-x-4">
                <div className="relative w-24 h-24 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="48" cy="48" r="38" stroke="#1e293b" strokeWidth="8" fill="none" />
                    <circle
                      cx="48"
                      cy="48"
                      r="38"
                      stroke="#ea580c"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray="238"
                      strokeDashoffset={238 - (238 * (82 + Math.sin(pulsePhase * 0.05) * 5)) / 100}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute font-mono text-sm font-black text-orange-400">
                    {Math.round(82 + Math.sin(pulsePhase * 0.05) * 5)}%
                  </span>
                </div>

                <div className="space-y-1 font-mono text-xs text-slate-300">
                  <div className="text-sm font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" /> Fraud & Risk Radar
                  </div>
                  <p className="text-[11px] text-slate-400">Anomalies Detected: 0.02% (Normal Range)</p>
                  <p className="text-[11px] text-slate-400">Claim Settlement Integrity: HIGH</p>
                </div>
              </div>

              <div className="hidden sm:block border-l border-slate-800 pl-6 space-y-1.5 font-mono text-xs">
                <div className="flex justify-between gap-6"><span className="text-slate-400">Model:</span><span className="text-cyan-400 font-bold">ICICI-Lombard-LLM-v4</span></div>
                <div className="flex justify-between gap-6"><span className="text-slate-400">Latency:</span><span className="text-emerald-400 font-bold">12ms Response</span></div>
                <div className="flex justify-between gap-6"><span className="text-slate-400">Status:</span><span className="text-amber-400 font-bold">OPTIMAL</span></div>
              </div>
            </div>
          )}
        </div>

        {/* Action Controls Section */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onActivateDemo}
            className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-mono font-bold rounded-xl shadow-lg hover:shadow-blue-500/30 transition-all duration-200 active:scale-95 flex items-center space-x-2 cursor-pointer text-xs sm:text-sm"
          >
            <Sparkles className="w-4 h-4 text-sky-200" />
            <span>Launch Interactive Demo Portal</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenFilePicker}
            className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white font-mono font-semibold rounded-xl border border-slate-700 transition-all active:scale-95 flex items-center space-x-2 cursor-pointer text-xs sm:text-sm"
          >
            <Database className="w-4 h-4 text-blue-400" />
            <span>Upload Claims Dataset (.xlsx / .csv)</span>
          </button>
        </div>

      </div>

    </div>
  );
};
