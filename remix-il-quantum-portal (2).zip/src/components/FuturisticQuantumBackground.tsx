import React, { useEffect, useRef } from 'react';
import { PortalSettings } from '../types';
import { getThemeAccentColors } from '../utils/themeConfig';

interface FuturisticQuantumBackgroundProps {
  settings: PortalSettings;
}

export const FuturisticQuantumBackground: React.FC<FuturisticQuantumBackgroundProps> = ({ settings }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!settings.enableParticles) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Color based on accent
    const themeAccents = getThemeAccentColors(settings.themePreset);
    const particleColorHex = themeAccents.accentHex || '#ea580c';

    // Particles setup
    const particleCount = Math.min(Math.floor((width * height) / 18000), 65);
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      pulse: number;
      pulseSpeed: number;
    }> = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.6,
        radius: Math.random() * 2 + 1,
        pulse: Math.random() * Math.PI,
        pulseSpeed: 0.02 + Math.random() * 0.03,
      });
    }

    let mouseX = -1000;
    let mouseY = -1000;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Render quantum nodes
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        p.x += p.vx;
        p.y += p.vy;
        p.pulse += p.pulseSpeed;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Draw particle dot
        const currentRadius = p.radius + Math.sin(p.pulse) * 0.8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.5, currentRadius), 0, Math.PI * 2);
        ctx.fillStyle = particleColorHex;
        ctx.globalAlpha = 0.5 + Math.sin(p.pulse) * 0.3;
        ctx.fill();

        // Connect nearby particles with laser thread lines
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 130) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = particleColorHex;
            ctx.globalAlpha = (1 - dist / 130) * 0.25;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }

        // Connect with mouse position
        const mdx = p.x - mouseX;
        const mdy = p.y - mouseY;
        const mdist = Math.sqrt(mdx * mdx + mdy * mdy);
        if (mdist < 180) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouseX, mouseY);
          ctx.strokeStyle = particleColorHex;
          ctx.globalAlpha = (1 - mdist / 180) * 0.45;
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
      }

      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [settings.enableParticles, settings.themePreset, settings.backgroundStyle]);

  // Determine background style backdrop classes
  let bgClass = 'bg-slate-950 text-slate-100';
  if (settings.backgroundStyle === 'enterprise-blue' || settings.themePreset === 'enterprise-blue') {
    bgClass = 'bg-[#f1f5f9] text-slate-900';
  } else if (settings.backgroundStyle === 'cyber-grid') {
    bgClass = 'bg-[#030712] text-slate-100';
  } else if (settings.backgroundStyle === 'holo-matrix') {
    bgClass = 'bg-[#02131b] text-cyan-100';
  } else if (settings.backgroundStyle === 'dark-synth') {
    bgClass = 'bg-[#0b0914] text-purple-100';
  } else if (settings.backgroundStyle === 'glass-white') {
    bgClass = 'bg-slate-50 text-slate-900';
  }

  return (
    <div className={`fixed inset-0 pointer-events-none z-0 overflow-hidden transition-colors duration-500 ${bgClass}`}>
      {/* Dynamic Futuristic Grid Overlay */}
      {settings.backgroundStyle !== 'glass-white' && (
        <div 
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: `linear-gradient(to right, rgba(255, 255, 255, 0.08) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(255, 255, 255, 0.08) 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
          }}
        />
      )}

      {/* Futuristic Scanline Sweep FX */}
      {settings.enableScanlines && (
        <div className="absolute inset-0 bg-scanlines opacity-20 pointer-events-none animate-scanline" />
      )}

      {/* Particle Canvas */}
      {settings.enableParticles && (
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-60" />
      )}

      {/* Corner Futuristic HUD Reticles */}
      <div className={`absolute top-3 left-3 w-8 h-8 border-t-2 border-l-2 opacity-70 ${
        settings.themePreset === 'enterprise-blue' ? 'border-blue-500/40' : 'border-orange-500/40'
      }`} />
      <div className={`absolute top-3 right-3 w-8 h-8 border-t-2 border-r-2 opacity-70 ${
        settings.themePreset === 'enterprise-blue' ? 'border-blue-500/40' : 'border-orange-500/40'
      }`} />
      <div className={`absolute bottom-3 left-3 w-8 h-8 border-b-2 border-l-2 opacity-70 ${
        settings.themePreset === 'enterprise-blue' ? 'border-blue-500/40' : 'border-orange-500/40'
      }`} />
      <div className={`absolute bottom-3 right-3 w-8 h-8 border-b-2 border-r-2 opacity-70 ${
        settings.themePreset === 'enterprise-blue' ? 'border-blue-500/40' : 'border-orange-500/40'
      }`} />
    </div>
  );
};
