import React from 'react';
import { Play, Pause, RefreshCw, Zap, Download, Activity, Server, Radio, FileText } from 'lucide-react';
import { FilterState } from '../types';

interface HeaderProps {
  filterState: FilterState;
  setFilterState: React.Dispatch<React.SetStateAction<FilterState>>;
  onManualTick: () => void;
  onOpenSimulator: () => void;
  onResetData: () => void;
  onExportData: () => void;
  onDownloadPdfReport?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  filterState,
  setFilterState,
  onManualTick,
  onOpenSimulator,
  onResetData,
  onExportData,
  onDownloadPdfReport,
}) => {
  const togglePause = () => {
    setFilterState((prev) => ({
      ...prev,
      isPaused: !prev.isPaused,
    }));
  };

  const handleSpeedChange = (speedMs: number) => {
    setFilterState((prev) => ({
      ...prev,
      simulationSpeedMs: speedMs,
      isPaused: speedMs === 0,
    }));
  };

  return (
    <header id="main-header" className="bg-white border-b border-slate-200 text-slate-900 sticky top-0 z-30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        
        {/* Brand & Live Beacon */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-sm text-white">
            <Activity className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2.5">
              <h1 className="text-xl font-bold tracking-tight text-slate-800 font-sans">
                IL <span className="text-indigo-600">QUANTUM</span> PORTAL
              </h1>
              <span className="bg-slate-100 rounded-full px-3 py-1 text-xs font-semibold text-slate-600 flex items-center gap-2 border border-slate-200">
                <span className={`w-2 h-2 rounded-full ${filterState.isPaused ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} />
                {filterState.isPaused ? 'STREAM PAUSED' : 'LIVE UPDATING'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              ICICI Lombard Health Management & Analytics Portal
            </p>
          </div>
        </div>

        {/* Real-Time Engine Controls */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          
          {/* Simulation Speed Switcher */}
          <div className="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200 text-xs font-medium">
            <button
              id="pause-toggle-btn"
              onClick={togglePause}
              className={`flex items-center px-2.5 py-1.5 rounded-md transition-all ${
                filterState.isPaused
                  ? 'bg-amber-100 text-amber-800 font-semibold border border-amber-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title={filterState.isPaused ? 'Resume Real-time Stream' : 'Pause Real-time Stream'}
            >
              {filterState.isPaused ? <Play className="w-3.5 h-3.5 mr-1 text-amber-600" /> : <Pause className="w-3.5 h-3.5 mr-1 text-slate-600" />}
              {filterState.isPaused ? 'Paused' : 'Live'}
            </button>

            <span className="h-4 w-px bg-slate-300 mx-1" />

            <button
              id="speed-1s-btn"
              onClick={() => handleSpeedChange(1000)}
              className={`px-2 py-1.5 rounded-md transition-all ${
                !filterState.isPaused && filterState.simulationSpeedMs === 1000
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              1s
            </button>
            <button
              id="speed-2s-btn"
              onClick={() => handleSpeedChange(2000)}
              className={`px-2 py-1.5 rounded-md transition-all ${
                !filterState.isPaused && filterState.simulationSpeedMs === 2000
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              2s
            </button>
            <button
              id="speed-5s-btn"
              onClick={() => handleSpeedChange(5000)}
              className={`px-2 py-1.5 rounded-md transition-all ${
                !filterState.isPaused && filterState.simulationSpeedMs === 5000
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              5s
            </button>
          </div>

          {/* Sync / Trigger Step */}
          <button
            id="manual-sync-btn"
            onClick={onManualTick}
            className="flex items-center px-3 py-1.5 text-xs font-medium bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-lg transition-colors shadow-sm active:scale-95"
            title="Inject a real-time data tick immediately"
          >
            <RefreshCw className="w-3.5 h-3.5 mr-1.5 text-indigo-600" />
            Tick
          </button>

          {/* Simulate Event Trigger Button */}
          <button
            id="inject-event-btn"
            onClick={onOpenSimulator}
            className="flex items-center px-3.5 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-all shadow-sm active:scale-95"
          >
            <Zap className="w-3.5 h-3.5 mr-1.5 text-amber-300 fill-amber-300" />
            Simulate Event
          </button>

          {/* PDF Report Button */}
          {onDownloadPdfReport && (
            <button
              id="download-pdf-report-btn"
              onClick={onDownloadPdfReport}
              className="flex items-center px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-50 text-indigo-600 border border-indigo-200 rounded-lg transition-all shadow-xs active:scale-95"
              title="Generate and Download Executive PDF Summary Report"
            >
              <FileText className="w-3.5 h-3.5 mr-1.5 text-indigo-600" />
              PDF Report
            </button>
          )}

          {/* Export & Reset dropdown/actions */}
          <div className="flex items-center space-x-1 border-l border-slate-200 pl-2">
            <button
              id="export-data-btn"
              onClick={onExportData}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
              title="Export Current Dashboard Snapshot (JSON)"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              id="reset-stream-btn"
              onClick={onResetData}
              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="Reset metrics to initial state"
            >
              <Radio className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </header>
  );
};
