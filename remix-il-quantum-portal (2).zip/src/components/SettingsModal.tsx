import React, { useState } from 'react';
import { PortalSettings } from '../types';
import { CHART_PALETTES } from '../utils/themeConfig';
import { Settings, X, RotateCcw, Check, Sun, Moon, Palette, BarChart2, Cpu, Zap, Sparkles, Sliders } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PortalSettings;
  onUpdateSettings: (newSettings: PortalSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [localSettings, setLocalSettings] = useState<PortalSettings>(settings);
  const [activeCategory, setActiveCategory] = useState<'theme' | 'charts' | 'fx' | 'data'>('theme');

  if (!isOpen) return null;

  const handleApply = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const handleReset = () => {
    const defaultSettings: PortalSettings = {
      themePreset: 'il-orange',
      colorScheme: 'default',
      chartPalette: 'il-sunset',
      backgroundStyle: 'cyber-grid',
      enableParticles: true,
      enableScanlines: true,
      enableGlowEffects: true,
      chartAnimationSpeed: 'normal',
      darkMode: true,
      fontSize: 'medium',
      topNLimit: 10,
      maxFileSizeMb: 25,
    };
    setLocalSettings(defaultSettings);
  };

  return (
    <div id="settings-modal-backdrop" className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 font-mono">
      <div className="bg-slate-900 rounded-2xl max-w-xl w-full shadow-[0_0_50px_rgba(234,88,12,0.25)] border border-slate-700/80 overflow-hidden text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Futuristic Modal Header */}
        <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-orange-600/20 border border-orange-500/40 text-orange-400">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black uppercase text-white tracking-wider flex items-center gap-2">
                PORTAL & CHART CONFIGURATION
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-500/20 border border-orange-500/40 text-orange-400 font-bold">NEXT-GEN</span>
              </h3>
              <p className="text-[10px] text-slate-400">Customize theme accent, chart palettes, background FX & telemetry</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tab Bar */}
        <div className="flex items-center justify-between bg-slate-950/60 border-b border-slate-800 px-4 py-2 text-xs font-bold gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveCategory('theme')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'theme' ? 'bg-orange-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Theme & Accent</span>
          </button>

          <button
            onClick={() => setActiveCategory('charts')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'charts' ? 'bg-orange-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Chart Palettes</span>
          </button>

          <button
            onClick={() => setActiveCategory('fx')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'fx' ? 'bg-orange-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Futuristic FX</span>
          </button>

          <button
            onClick={() => setActiveCategory('data')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'data' ? 'bg-orange-600 text-white shadow-2xs' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Buffer & Scale</span>
          </button>
        </div>

        {/* Modal Form Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 font-mono">
          
          {/* TAB 1: Theme & Accent */}
          {activeCategory === 'theme' && (
            <div className="space-y-4">
              <div>
                <label className="block font-black text-white uppercase mb-2 text-xs flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-orange-400" /> Portal Theme Preset
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { id: 'enterprise-blue', name: 'Enterprise Blue', desc: 'Executive Royal Blue & Teal Charts', color: 'bg-blue-600' },
                    { id: 'il-orange', name: 'ICICI Orange', desc: 'Quantum Orange Accent', color: 'bg-orange-600' },
                    { id: 'cyber-quantum', name: 'Quantum Cyan', desc: 'Electric AI Blue', color: 'bg-cyan-500' },
                    { id: 'neon-matrix', name: 'Neon Matrix', desc: 'Robotic Green', color: 'bg-emerald-500' },
                    { id: 'deep-cosmos', name: 'Deep Cosmos', desc: 'Violet Space Pulse', color: 'bg-purple-600' },
                    { id: 'high-tech-dark', name: 'Obsidian Dark', desc: 'Steel Metallic Gray', color: 'bg-slate-600' },
                  ].map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() =>
                        setLocalSettings((prev) => ({
                          ...prev,
                          themePreset: preset.id as any,
                          ...(preset.id === 'enterprise-blue' ? { chartPalette: 'enterprise-blue', backgroundStyle: 'enterprise-blue' } : {}),
                        }))
                      }
                      className={`flex flex-col text-left p-2.5 rounded-xl border font-bold transition-all cursor-pointer ${
                        localSettings.themePreset === preset.id
                          ? 'border-blue-500 bg-blue-950/40 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] ring-1 ring-blue-400/50'
                          : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center space-x-2 mb-1">
                        <span className={`w-3.5 h-3.5 rounded-full ${preset.color} shrink-0 shadow-2xs`} />
                        <span className="truncate font-black text-xs text-white">{preset.name}</span>
                      </div>
                      <span className="text-[9px] text-slate-400 truncate">{preset.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-black text-white uppercase mb-2 text-xs flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-blue-400" /> Background Environment
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { id: 'enterprise-blue', name: 'Executive Blue Light Canvas', desc: 'Professional Executive Slate/Blue layout' },
                    { id: 'cyber-grid', name: 'Cyber Grid & Quantum Nodes', desc: 'Interactive AI particle net' },
                    { id: 'holo-matrix', name: 'Holographic Matrix', desc: 'Cyan scanline HUD environment' },
                    { id: 'dark-synth', name: 'Deep Cosmic Dark', desc: 'Violet dark space theme' },
                    { id: 'glass-white', name: 'Clean Glass Light', desc: 'High-contrast light glass layout' },
                  ].map((bg) => (
                    <button
                      key={bg.id}
                      onClick={() => setLocalSettings((prev) => ({ ...prev, backgroundStyle: bg.id as any }))}
                      className={`p-2.5 rounded-xl border text-left font-bold transition-all cursor-pointer ${
                        localSettings.backgroundStyle === bg.id
                          ? 'border-blue-500 bg-blue-950/40 text-white shadow-2xs'
                          : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="font-bold text-xs text-white mb-0.5">{bg.name}</div>
                      <div className="text-[10px] text-slate-400">{bg.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Chart Color Palettes */}
          {activeCategory === 'charts' && (
            <div className="space-y-4">
              <div>
                <label className="block font-black text-white uppercase mb-2 text-xs flex items-center gap-1.5">
                  <BarChart2 className="w-4 h-4 text-blue-400" /> Recharts & Custom Graph Palette
                </label>
                <p className="text-[11px] text-slate-400 mb-3">
                  Instantly transforms all area, bar, line, and pie chart colors across the entire dashboard.
                </p>

                <div className="space-y-2.5">
                  {[
                    { id: 'enterprise-blue', name: 'Enterprise Executive Blue', desc: 'Cobalt Royal Blue, Teal, Indigo, Amber' },
                    { id: 'neon-cyber', name: 'Neon Cyberpunk', desc: 'Cyan, Magenta, Violet, Emerald' },
                    { id: 'il-sunset', name: 'ICICI Lombard Sunset', desc: 'Quantum Orange, Coral, Amber, Rose' },
                    { id: 'matrix-green', name: 'Robotic Matrix Green', desc: 'Emerald, Cyan, Mint Lime, Teal' },
                    { id: 'ai-aurora', name: 'AI Aurora Pulse', desc: 'Violet, Aurora Pink, Sapphire, Rose' },
                    { id: 'monochrome-steel', name: 'Steel Metallic Chrome', desc: 'Sky Blue, Titanium, Platinum, Cyan' },
                  ].map((pal) => {
                    const colors = CHART_PALETTES[pal.id];
                    const isSelected = localSettings.chartPalette === pal.id;

                    return (
                      <button
                        key={pal.id}
                        onClick={() => setLocalSettings((prev) => ({ ...prev, chartPalette: pal.id as any }))}
                        className={`w-full p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-blue-500 bg-blue-950/30 text-white shadow-[0_0_20px_rgba(37,99,235,0.25)] ring-1 ring-blue-500/50'
                            : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="text-left">
                          <div className="font-bold text-xs text-white">{pal.name}</div>
                          <div className="text-[10px] text-slate-400">{pal.desc}</div>
                        </div>

                        {/* Color Swatch Preview */}
                        <div className="flex items-center space-x-1.5 shrink-0">
                          <span className="w-4 h-4 rounded-full shadow-2xs" style={{ backgroundColor: colors.primary }} />
                          <span className="w-4 h-4 rounded-full shadow-2xs" style={{ backgroundColor: colors.secondary }} />
                          <span className="w-4 h-4 rounded-full shadow-2xs" style={{ backgroundColor: colors.tertiary }} />
                          <span className="w-4 h-4 rounded-full shadow-2xs" style={{ backgroundColor: colors.quaternary }} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Futuristic FX */}
          {activeCategory === 'fx' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
                <div>
                  <div className="font-bold text-white flex items-center gap-1.5 uppercase">
                    <Sparkles className="w-4 h-4 text-orange-400" /> AI Quantum Particle Mesh
                  </div>
                  <p className="text-[10px] text-slate-400">Interactive background particle node constellation</p>
                </div>
                <button
                  onClick={() => setLocalSettings((prev) => ({ ...prev, enableParticles: !prev.enableParticles }))}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer border ${
                    localSettings.enableParticles ? 'bg-orange-600 justify-end border-orange-400' : 'bg-slate-800 justify-start border-slate-700'
                  }`}
                >
                  <span className="w-4 h-4 bg-white rounded-full shadow-2xs" />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
                <div>
                  <div className="font-bold text-white flex items-center gap-1.5 uppercase">
                    <Zap className="w-4 h-4 text-cyan-400" /> HUD Scanlines & Grid Lines
                  </div>
                  <p className="text-[10px] text-slate-400">Cybernetic radar scanning line animations</p>
                </div>
                <button
                  onClick={() => setLocalSettings((prev) => ({ ...prev, enableScanlines: !prev.enableScanlines }))}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer border ${
                    localSettings.enableScanlines ? 'bg-orange-600 justify-end border-orange-400' : 'bg-slate-800 justify-start border-slate-700'
                  }`}
                >
                  <span className="w-4 h-4 bg-white rounded-full shadow-2xs" />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
                <div>
                  <div className="font-bold text-white flex items-center gap-1.5 uppercase">
                    <Cpu className="w-4 h-4 text-emerald-400" /> Hologram Glow Highlights
                  </div>
                  <p className="text-[10px] text-slate-400">Pulsating neon card borders and hover drop-shadows</p>
                </div>
                <button
                  onClick={() => setLocalSettings((prev) => ({ ...prev, enableGlowEffects: !prev.enableGlowEffects }))}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer border ${
                    localSettings.enableGlowEffects ? 'bg-orange-600 justify-end border-orange-400' : 'bg-slate-800 justify-start border-slate-700'
                  }`}
                >
                  <span className="w-4 h-4 bg-white rounded-full shadow-2xs" />
                </button>
              </div>

              <div>
                <label className="block font-bold text-white mb-1.5 uppercase text-xs">Chart Animation Velocity</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'fast', name: 'Rapid (300ms)' },
                    { id: 'normal', name: 'Standard (800ms)' },
                    { id: 'smooth', name: 'Ultra Smooth (1.5s)' },
                  ].map((speed) => (
                    <button
                      key={speed.id}
                      onClick={() => setLocalSettings((prev) => ({ ...prev, chartAnimationSpeed: speed.id as any }))}
                      className={`p-2 rounded-lg border text-center font-bold text-xs transition-all cursor-pointer ${
                        localSettings.chartAnimationSpeed === speed.id
                          ? 'border-orange-500 bg-orange-600 text-white'
                          : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-white'
                      }`}
                    >
                      {speed.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Data Buffer & Scale */}
          {activeCategory === 'data' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-white mb-1 uppercase text-xs">Text Display Scale</label>
                  <select
                    value={localSettings.fontSize}
                    onChange={(e) => setLocalSettings((prev) => ({ ...prev, fontSize: e.target.value as any }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 font-mono font-bold text-white focus:outline-none focus:border-orange-500 cursor-pointer text-xs"
                  >
                    <option value="small">Compact (Small)</option>
                    <option value="medium">Default (Medium)</option>
                    <option value="large">High-Def (Large)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-white mb-1 uppercase text-xs">Chart Top N Limit</label>
                  <select
                    value={localSettings.topNLimit}
                    onChange={(e) => setLocalSettings((prev) => ({ ...prev, topNLimit: Number(e.target.value) }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 font-mono font-bold text-white focus:outline-none focus:border-orange-500 cursor-pointer text-xs"
                  >
                    <option value={5}>Top 5 Categories</option>
                    <option value={10}>Top 10 Categories</option>
                    <option value={15}>Top 15 Categories</option>
                    <option value={25}>Top 25 Categories</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-white mb-1 uppercase text-xs">Max Upload Dataset Buffer (MB)</label>
                <input
                  type="number"
                  value={localSettings.maxFileSizeMb}
                  onChange={(e) => setLocalSettings((prev) => ({ ...prev, maxFileSizeMb: Number(e.target.value) }))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 font-mono font-bold text-white focus:outline-none focus:border-orange-500 text-xs"
                  min={5}
                  max={100}
                />
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
          <button
            onClick={handleReset}
            className="flex items-center space-x-1.5 text-slate-400 hover:text-white font-bold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET DEFAULTS</span>
          </button>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white border border-slate-700 rounded-xl font-bold bg-slate-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center space-x-1.5 px-5 py-2 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white font-black rounded-xl shadow-[0_0_15px_rgba(234,88,12,0.3)] cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>APPLY CONFIG</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
