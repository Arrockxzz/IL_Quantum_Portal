import React, { useState, useMemo } from 'react';
import { ClaimRecord, CustomChartConfig, PortalSettings } from '../types';
import { getChartPalette } from '../utils/themeConfig';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { Sliders, BarChart2, PieChart as PieIcon, TrendingUp, Layers } from 'lucide-react';

interface CustomChartBuilderProps {
  claims: ClaimRecord[];
  settings?: PortalSettings;
}

export const CustomChartBuilder: React.FC<CustomChartBuilderProps> = ({ claims, settings }) => {
  const [config, setConfig] = useState<CustomChartConfig>({
    chartType: 'bar',
    xAxis: 'disease_category',
    yAxis: 'net_sanct_amt',
    groupDimension: 'none',
    topN: settings?.topNLimit || 8,
  });

  const palette = getChartPalette(settings?.chartPalette);
  const COLORS = [
    palette.primary,
    palette.secondary,
    palette.tertiary,
    palette.quaternary,
    palette.accent,
    '#38bdf8',
    '#ec4899',
    '#f59e0b',
  ];

  const dimensions = [
    { key: 'disease_category', label: 'Disease Category' },
    { key: 'updated_status', label: 'Claim Status' },
    { key: 'type_of_claim', label: 'Type of Claim' },
    { key: 'relation_group', label: 'Relation Group' },
    { key: 'age_band', label: 'Age Band' },
    { key: 'ipd_opd', label: 'IPD / OPD' },
    { key: 'hospital_city', label: 'Hospital City' },
    { key: 'hospital_state', label: 'Hospital State' },
    { key: 'policy_name', label: 'Policy Name' },
    { key: 'whether_hospital_networked', label: 'Network Hospital' },
    { key: '__monthYear', label: 'Month Year' },
  ];

  const metrics = [
    { key: 'net_sanct_amt', label: 'Approved Amount ($)' },
    { key: 'claimed_amount', label: 'Claimed Amount ($)' },
    { key: 'payment_amount', label: 'Paid Amount ($)' },
    { key: 'disallowed_amount', label: 'Disallowed Amount ($)' },
    { key: 'claim_count', label: 'Total Claim Count' },
  ];

  // Aggregate data according to X-Axis and Y-Axis selections
  const chartData = useMemo(() => {
    const map = new Map<string, { xVal: string; yVal: number; count: number }>();

    claims.forEach((claim) => {
      const xVal = String(claim[config.xAxis] || 'Unspecified');
      const existing = map.get(xVal) || { xVal, yVal: 0, count: 0 };

      if (config.yAxis === 'claim_count') {
        existing.yVal += 1;
      } else {
        existing.yVal += Number(claim[config.yAxis] || 0);
      }
      existing.count += 1;
      map.set(xVal, existing);
    });

    const sorted = Array.from(map.values()).sort((a, b) => b.yVal - a.yVal);
    return sorted.slice(0, config.topN);
  }, [claims, config]);

  const formatYValue = (val: number) => {
    if (config.yAxis === 'claim_count') return val.toLocaleString();
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div id="custom-chart-builder" className="hud-card rounded-2xl p-5 shadow-[0_0_25px_rgba(0,255,102,0.15)] space-y-4 my-6 font-mono">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-emerald-500/40 pb-3 gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-emerald-950 text-emerald-300 rounded-xl border border-emerald-400 shadow-[0_0_8px_#00ff66]">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-black text-white text-glow-emerald uppercase">QUANTUM CHART MATRIX BUILDER</h3>
            <p className="text-xs text-emerald-400/80">Construct custom neural telemetry visualizations from claim streams</p>
          </div>
        </div>

        {/* Chart Type Selector */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-emerald-500/40 text-xs">
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'bar' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              config.chartType === 'bar' ? 'bg-emerald-400 text-black shadow-[0_0_10px_#00ff66]' : 'text-emerald-400 hover:text-white'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 mr-1" />
            Bar
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'horizontalBar' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              config.chartType === 'horizontalBar' ? 'bg-emerald-400 text-black shadow-[0_0_10px_#00ff66]' : 'text-emerald-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 mr-1" />
            Horizontal
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'pie' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              config.chartType === 'pie' ? 'bg-emerald-400 text-black shadow-[0_0_10px_#00ff66]' : 'text-emerald-400 hover:text-white'
            }`}
          >
            <PieIcon className="w-3.5 h-3.5 mr-1" />
            Pie
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'line' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              config.chartType === 'line' ? 'bg-emerald-400 text-black shadow-[0_0_10px_#00ff66]' : 'text-emerald-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1" />
            Line
          </button>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-950 p-3 rounded-xl border border-emerald-500/30">
        
        {/* X Axis Selector */}
        <div>
          <label className="block text-[11px] font-bold text-emerald-300 mb-1">X-AXIS MATRIX DIMENSION</label>
          <select
            value={config.xAxis}
            onChange={(e) => setConfig((prev) => ({ ...prev, xAxis: e.target.value }))}
            className="w-full bg-slate-900 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono focus:outline-none focus:border-emerald-300 cursor-pointer"
          >
            {dimensions.map((d) => (
              <option key={d.key} value={d.key} className="bg-slate-950 text-emerald-300">
                {d.label}
              </option>
            ))}
          </select>
        </div>

        {/* Y Axis Selector */}
        <div>
          <label className="block text-[11px] font-bold text-emerald-300 mb-1">Y-AXIS TELEMETRY METRIC</label>
          <select
            value={config.yAxis}
            onChange={(e) => setConfig((prev) => ({ ...prev, yAxis: e.target.value }))}
            className="w-full bg-slate-900 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono focus:outline-none focus:border-emerald-300 cursor-pointer"
          >
            {metrics.map((m) => (
              <option key={m.key} value={m.key} className="bg-slate-950 text-emerald-300">
                {m.label}
              </option>
            ))}
          </select>
        </div>

        {/* Top N Limit */}
        <div>
          <label className="block text-[11px] font-bold text-emerald-300 mb-1">TOP N MATRIX NODES</label>
          <select
            value={config.topN}
            onChange={(e) => setConfig((prev) => ({ ...prev, topN: Number(e.target.value) }))}
            className="w-full bg-slate-900 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono focus:outline-none focus:border-emerald-300 cursor-pointer"
          >
            <option value={5} className="bg-slate-950 text-emerald-300">Top 5</option>
            <option value={8} className="bg-slate-950 text-emerald-300">Top 8</option>
            <option value={12} className="bg-slate-950 text-emerald-300">Top 12</option>
            <option value={20} className="bg-slate-950 text-emerald-300">Top 20</option>
          </select>
        </div>

      </div>

      {/* Chart Canvas */}
      <div className="h-72 w-full pt-2">
        {chartData.length === 0 ? (
          <div className="h-full flex items-center justify-center text-emerald-600 text-xs">
            No claim records match selected matrix config.
          </div>
        ) : config.chartType === 'bar' ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#00ff6622" />
              <XAxis dataKey="xVal" stroke="#00ff6688" fontSize={11} angle={-15} textAnchor="end" />
              <YAxis stroke="#00ff6688" fontSize={11} tickFormatter={(val) => `$${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#030712',
                  borderColor: '#00ff66',
                  borderRadius: '0.75rem',
                  color: '#00ff66',
                  fontSize: '12px',
                  boxShadow: '0 0 20px rgba(0, 255, 102, 0.4)',
                  fontFamily: 'monospace',
                }}
                formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']}
              />
              <Bar dataKey="yVal" radius={[6, 6, 0, 0]}>
                {chartData.map((_, index) => (
                  <Cell key={`bar-cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : config.chartType === 'horizontalBar' ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 10, right: 20, left: 50, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={`${palette.primary}22`} />
              <XAxis type="number" stroke="#94a3b8" fontSize={11} tickFormatter={(val) => `$${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`} />
              <YAxis dataKey="xVal" type="category" stroke="#94a3b8" fontSize={11} width={100} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: palette.primary,
                  borderRadius: '0.75rem',
                  color: '#ffffff',
                  fontSize: '12px',
                  boxShadow: `0 0 20px ${palette.primary}44`,
                  fontFamily: 'sans-serif',
                }}
                formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']}
              />
              <Bar dataKey="yVal" radius={[0, 6, 6, 0]}>
                {chartData.map((_, index) => (
                  <Cell key={`hbar-cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : config.chartType === 'pie' ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                dataKey="yVal"
                nameKey="xVal"
                cx="50%"
                cy="50%"
                outerRadius={95}
                label={({ xVal, percent }) => `${xVal} (${(percent * 100).toFixed(0)}%)`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: palette.primary,
                  borderRadius: '0.75rem',
                  color: '#ffffff',
                  fontSize: '12px',
                  boxShadow: `0 0 20px ${palette.primary}44`,
                  fontFamily: 'sans-serif',
                }}
                formatter={(value: any) => [formatYValue(Number(value)), 'Value']}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={`${palette.primary}22`} />
              <XAxis dataKey="xVal" stroke="#94a3b8" fontSize={11} angle={-15} textAnchor="end" />
              <YAxis stroke="#94a3b8" fontSize={11} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: palette.primary,
                  borderRadius: '0.75rem',
                  color: '#ffffff',
                  fontSize: '12px',
                  boxShadow: `0 0 20px ${palette.primary}44`,
                  fontFamily: 'sans-serif',
                }}
                formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']}
              />
              <Line type="monotone" dataKey="yVal" stroke={palette.primary} strokeWidth={3} dot={{ r: 4, fill: palette.secondary }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

    </div>
  );
};
