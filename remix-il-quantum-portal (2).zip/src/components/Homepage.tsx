import React, { useState } from 'react';
import { Bot, Cpu, Radio } from 'lucide-react';
import { MatrixBackground, MatrixTheme } from './MatrixBackground';

interface HomepageProps {
  onEnterPortal: () => void;
}

export const Homepage: React.FC<HomepageProps> = ({ onEnterPortal }) => {
  const [isOpening, setIsOpening] = useState(false);
  const [matrixTheme, setMatrixTheme] = useState<MatrixTheme>('emerald');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Play sci-fi audio beep if audio context is available
  const triggerCyberBeep = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(220, audioCtx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      // Audio fallback silent
    }
  };

  const handleDoorClick = () => {
    if (isOpening) return;
    triggerCyberBeep();
    setIsOpening(true);
    setTimeout(() => {
      onEnterPortal();
    }, 1100);
  };

  return (
    <div
      id="homepage-container"
      onClick={handleDoorClick}
      className="relative w-full h-screen bg-slate-50 overflow-hidden flex flex-col items-center justify-center font-mono text-slate-900 select-none cursor-pointer"
    >
      
      {/* Dynamic Matrix Canvas Background */}
      <MatrixBackground theme={matrixTheme} speed={1.2} opacity={0.5} />

      {/* Double Cyber Vault Door Overlay */}
      <div className="absolute inset-0 flex z-20 pointer-events-none">
        {/* Left Vault Door */}
        <div
          className={`w-1/2 h-full bg-slate-50 border-r-2 border-orange-400/60 shadow-2xl transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? '-translate-x-full' : 'translate-x-0'
          }`}
        />

        {/* Right Vault Door */}
        <div
          className={`w-1/2 h-full bg-slate-50 border-l-2 border-orange-400/60 shadow-2xl transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? 'translate-x-full' : 'translate-x-0'
          }`}
        />
      </div>

      {/* Theme Accent Controls (Top Left) */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute top-4 left-4 z-40 flex items-center space-x-2 bg-white border border-slate-200 p-2 rounded-xl text-[11px] shadow-sm cursor-default"
      >
        <span className="text-slate-700 font-bold flex items-center">
          <Radio className="w-3.5 h-3.5 mr-1 text-orange-600 animate-pulse" /> ACCENT:
        </span>
        <button
          onClick={() => setMatrixTheme('amber')}
          className={`w-5 h-5 rounded-full border border-orange-500 ${matrixTheme === 'amber' ? 'ring-2 ring-orange-500 bg-orange-600' : 'bg-orange-100'}`}
          title="ICICI Orange"
        />
        <button
          onClick={() => setMatrixTheme('emerald')}
          className={`w-5 h-5 rounded-full border border-emerald-500 ${matrixTheme === 'emerald' ? 'ring-2 ring-emerald-500 bg-emerald-600' : 'bg-emerald-100'}`}
          title="Emerald Green"
        />
        <button
          onClick={() => setMatrixTheme('cyan')}
          className={`w-5 h-5 rounded-full border border-sky-500 ${matrixTheme === 'cyan' ? 'ring-2 ring-sky-500 bg-sky-600' : 'bg-sky-100'}`}
          title="Cyber Blue"
        />
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`ml-2 px-2 py-0.5 rounded text-[10px] font-bold border ${soundEnabled ? 'border-orange-500 text-orange-700 bg-orange-50' : 'border-slate-300 text-slate-500'}`}
        >
          {soundEnabled ? '🔊 AUDIO ON' : '🔇 AUDIO OFF'}
        </button>
      </div>

      {/* Main Content Card Container */}
      <div className="relative z-30 flex flex-col items-center max-w-xl mx-auto text-center px-4">
        
        {/* Emblem */}
        <div className="mb-6 p-4 bg-white rounded-2xl border border-slate-200 shadow-xl relative group">
          <div className="relative w-20 h-20 bg-orange-500 rounded-xl flex items-center justify-center border border-orange-400 shadow-md">
            <Bot className="w-12 h-12 text-white animate-robot-eye drop-shadow-md" />
            <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white animate-ping" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-wider text-slate-900 mb-2 font-mono">
          IL QUANTUM
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 font-mono tracking-widest uppercase mb-8 font-bold">
          AI-POWERED HEALTH CLAIMS ANALYTICS PORTAL
        </p>

      </div>
    </div>
  );
};

