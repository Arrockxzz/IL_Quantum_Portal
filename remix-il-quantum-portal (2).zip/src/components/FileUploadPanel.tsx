import React from 'react';
import { UploadedFileMeta } from '../types';
import { FileSpreadsheet, CheckCircle2, AlertCircle, Clock, X, RefreshCw } from 'lucide-react';

interface FileUploadPanelProps {
  files: UploadedFileMeta[];
  isOpen: boolean;
  onClose: () => void;
  onRemoveFile: (fileId: string) => void;
  onOpenFilePicker: () => void;
}

export const FileUploadPanel: React.FC<FileUploadPanelProps> = ({
  files,
  isOpen,
  onClose,
  onRemoveFile,
  onOpenFilePicker,
}) => {
  if (!isOpen) return null;

  return (
    <div id="file-upload-panel" className="bg-white border-b border-slate-200 text-slate-800 p-4 shadow-md z-30 transition-all font-mono">
      <div className="max-w-7xl mx-auto space-y-3">
        
        {/* Panel Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div className="flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-orange-600" />
            <h3 className="text-sm font-black text-slate-900 uppercase">PARSED DATASETS</h3>
            <span className="bg-orange-50 text-orange-800 border border-orange-200 text-xs px-2.5 py-0.5 rounded-full font-bold shadow-2xs">
              {files.length} FILE{files.length !== 1 ? 'S' : ''}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenFilePicker}
              className="px-3 py-1 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-black shadow-2xs transition-all cursor-pointer"
            >
              + UPLOAD FILE
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* File Queue List */}
        {files.length === 0 ? (
          <div className="py-6 text-center text-slate-500 text-xs font-medium">
            NO STREAM FILE LOADED. CLICK "+ UPLOAD FILE" TO PARSE CSV/XLSX MATRIX FILE.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-56 overflow-y-auto pr-1">
            {files.map((file) => (
              <div
                key={file.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col justify-between space-y-2 text-xs shadow-2xs"
              >
                <div className="flex items-start justify-between">
                  <div className="truncate pr-2">
                    <div className="font-bold text-slate-900 truncate" title={file.name}>
                      {file.name}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5 font-medium">
                      {file.rawSize} • {file.rowCount.toLocaleString()} ROWS
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveFile(file.id)}
                    className="text-slate-400 hover:text-rose-600 p-0.5 rounded hover:bg-slate-200 cursor-pointer"
                    title="Remove Dataset"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Status Badge & Progress */}
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1 font-bold">
                    <span className="flex items-center">
                      {file.status === 'Uploaded' && <CheckCircle2 className="w-3 h-3 text-emerald-600 mr-1" />}
                      {file.status === 'Processing' && <RefreshCw className="w-3 h-3 text-orange-600 animate-spin mr-1" />}
                      {file.status === 'Queued' && <Clock className="w-3 h-3 text-slate-500 mr-1" />}
                      {file.status === 'Error' && <AlertCircle className="w-3 h-3 text-rose-600 mr-1" />}
                      <span
                        className={
                          file.status === 'Uploaded'
                            ? 'text-emerald-700'
                            : file.status === 'Processing'
                            ? 'text-orange-700'
                            : file.status === 'Error'
                            ? 'text-rose-600'
                            : 'text-slate-700'
                        }
                      >
                        {file.status}
                      </span>
                    </span>
                    <span className="text-slate-700 font-mono">{file.progress}%</span>
                  </div>

                  <div className="w-full bg-slate-200 border border-slate-300 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        file.status === 'Uploaded'
                          ? 'bg-emerald-500'
                          : file.status === 'Error'
                          ? 'bg-rose-500'
                          : 'bg-orange-500'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
