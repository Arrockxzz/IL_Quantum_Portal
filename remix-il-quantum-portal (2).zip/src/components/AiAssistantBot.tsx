import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, X, Minimize2, Maximize2, Copy, Check, Cpu, Terminal, Radio, Volume2, VolumeX } from 'lucide-react';
import { ChatMessage, MetricKpis, DepartmentData, RegionalMetric } from '../types';

interface AiAssistantBotProps {
  kpis: MetricKpis;
  departments: DepartmentData[];
  regions: RegionalMetric[];
}

export const AiAssistantBot: React.FC<AiAssistantBotProps> = ({ kpis, departments, regions }) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [soundOn, setSoundOn] = useState<boolean>(true);
  const [eyeState, setEyeState] = useState<'happy' | 'analyzing' | 'normal'>('normal');

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      content: `🤖 **CYBER QUANTUM BOT v4.0 ONLINE**\n\nI am your **AI Matrix Data Companion**. Real-time telemetry connection established.\n\n- **Claims Revenue Matrix**: $${(kpis.arr / 1000000).toFixed(2)}M\n- **Neural Latency**: ${kpis.latencyMs}ms\n- **Active Audited Claims**: ${kpis.activeUsers}\n\nAsk me to analyze claims, detect fraud anomalies, or forecast loss ratios!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedActions: [
        'ANALYZE MATRIX CLAIMS',
        'DETECT LOSS RATIO ANOMALIES',
        'FORECAST Q3 CLAIMS',
      ],
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const triggerRobotSynthSound = () => {
    if (!soundOn) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      osc.frequency.setValueAtTime(1200, audioCtx.currentTime + 0.08);
      osc.frequency.setValueAtTime(900, audioCtx.currentTime + 0.16);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } catch (e) {
      // audio fallback
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    triggerRobotSynthSound();
    setEyeState('analyzing');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          dashboardState: {
            kpis,
            departments,
            regions,
            timestamp: new Date().toISOString(),
          },
          chatHistory: messages.map((m) => ({ role: m.sender, content: m.content })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      setEyeState('happy');
      triggerRobotSynthSound();

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        content: data.reply || 'Matrix neural core processed data successfully.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: data.suggestedActions || ['Audit Rejections', 'Hospital Network Analysis'],
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('Error fetching AI response:', err);
      setEyeState('normal');
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        content: `⚠️ **MATRIX NEURAL BUS ERROR**\n\nUnable to reach Gemini 3.6 Flash endpoint.\n\n*Details: ${err.message || String(err)}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
      setTimeout(() => setEyeState('normal'), 2000);
    }
  };

  const handleCopy = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Format markdown text with cyber styling
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-xs font-bold text-cyan-300 mt-2 mb-1">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={idx} className="text-xs font-black text-emerald-300 mt-2 mb-1 text-glow-emerald">{line.replace('## ', '')}</h3>;
      }
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        return (
          <li key={idx} className="ml-3 list-disc text-[11px] text-emerald-300/90 my-0.5 font-mono">
            {formatInlineBold(line.trim().substring(2))}
          </li>
        );
      }
      if (line.trim() === '') {
        return <div key={idx} className="h-1" />;
      }
      return (
        <p key={idx} className="text-[11px] text-emerald-300/90 leading-relaxed my-0.5 font-mono">
          {formatInlineBold(line)}
        </p>
      );
    });
  };

  const formatInlineBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-white text-glow-emerald">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  if (!isOpen || isMinimized) {
    return (
      <button
        id="reopen-ai-bot-btn"
        onClick={() => {
          setIsOpen(true);
          setIsMinimized(false);
          triggerRobotSynthSound();
        }}
        className="fixed top-16 right-4 z-50 w-10 h-10 bg-orange-600 hover:bg-orange-500 text-white rounded-full shadow-lg flex items-center justify-center border border-orange-400 hover:scale-110 active:scale-95 transition-all cursor-pointer group"
        title="AI Cyber Bot v4.0"
      >
        <Bot className="w-5 h-5 text-white animate-robot-eye" />
        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white animate-pulse" />
      </button>
    );
  }

  return (
    <div
      id="ai-bot-panel"
      className="fixed top-16 right-4 z-50 w-80 sm:w-80 h-[400px] bg-white border border-slate-200 rounded-2xl shadow-2xl flex flex-col text-slate-800 font-mono overflow-hidden animate-in fade-in zoom-in-95 duration-200"
    >
      {/* Robot Panel Header */}
      <div className="bg-slate-50 px-3 py-2.5 rounded-t-2xl border-b border-slate-200 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2">
          
          {/* Expressive Robot Avatar Eye Box */}
          <div className="relative w-7 h-7 rounded-lg bg-orange-600 text-white flex items-center justify-center shadow-xs">
            <Bot className={`w-4 h-4 ${eyeState === 'analyzing' ? 'animate-spin' : 'animate-robot-eye'}`} />
            <span className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${eyeState === 'happy' ? 'bg-cyan-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`} />
          </div>

          <div>
            <div className="flex items-center space-x-1.5">
              <h3 className="text-xs font-black text-slate-900 tracking-wider uppercase">CYBER BOT</h3>
              <span className="text-[9px] bg-orange-100 text-orange-800 border border-orange-200 px-1 py-0.2 rounded font-bold">GEMINI 3.6</span>
            </div>
            <p className="text-[9px] text-emerald-600 flex items-center font-bold">
              <Radio className="w-2.5 h-2.5 mr-1 text-emerald-600 animate-pulse" /> LINK ACTIVE
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-0.5">
          <button
            onClick={() => setSoundOn(!soundOn)}
            className="p-1 text-slate-500 hover:text-slate-800 rounded-md hover:bg-slate-200 transition-colors cursor-pointer"
            title={soundOn ? 'Sound FX On' : 'Sound FX Muted'}
          >
            {soundOn ? <Volume2 className="w-3.5 h-3.5 text-orange-600" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
          </button>

          <button
            id="minimize-ai-bot-btn"
            onClick={() => setIsMinimized(true)}
            className="p-1 text-slate-500 hover:text-slate-800 rounded-md hover:bg-slate-200 transition-colors cursor-pointer"
            title="Minimize to top-right icon"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>
          <button
            id="close-ai-bot-btn"
            onClick={() => setIsOpen(false)}
            className="p-1 text-slate-500 hover:text-rose-600 rounded-md hover:bg-slate-200 transition-colors cursor-pointer"
            title="Close Assistant"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expanded Content Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50/50">
        {messages.map((msg, index) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[92%] p-2.5 text-[11px] leading-relaxed border ${
                msg.sender === 'user'
                  ? 'bg-orange-600 border-orange-500 text-white rounded-xl rounded-tr-none shadow-xs'
                  : msg.isError
                  ? 'bg-rose-50 border-rose-300 text-rose-800 rounded-xl rounded-tl-none'
                  : 'bg-white border-slate-200 text-slate-800 rounded-xl rounded-tl-none shadow-2xs'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1 pb-1 border-b border-slate-100">
                <span className={`text-[9px] font-bold tracking-widest uppercase flex items-center ${msg.sender === 'user' ? 'text-orange-100' : 'text-orange-700'}`}>
                  {msg.sender === 'user' ? (
                    'OPERATOR'
                  ) : (
                    <>
                      <Bot className="w-3 h-3 mr-1 text-orange-600" />
                      CYBER BOT
                    </>
                  )}
                </span>
                <div className="flex items-center space-x-1">
                  <span className={`text-[8px] ${msg.sender === 'user' ? 'text-orange-200' : 'text-slate-400'}`}>{msg.timestamp}</span>
                  {msg.sender === 'ai' && (
                    <button
                      onClick={() => handleCopy(msg.content, index)}
                      className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                      title="Copy Log"
                    >
                      {copiedIndex === index ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>

              <div>{renderFormattedContent(msg.content)}</div>
            </div>

            {/* Suggested Actions */}
            {msg.suggestedActions && msg.suggestedActions.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1.5 max-w-[95%]">
                {msg.suggestedActions.map((action, aIdx) => (
                  <button
                    key={aIdx}
                    onClick={() => handleSend(action)}
                    className="text-[9px] font-bold bg-white hover:bg-orange-50 text-orange-800 border border-slate-200 hover:border-orange-300 px-2 py-0.5 rounded-full transition-all shadow-2xs hover:scale-105 cursor-pointer uppercase tracking-wider"
                  >
                    ⚡ {action}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Robot Typing Indicator */}
        {isLoading && (
          <div className="flex items-center space-x-2 bg-white border border-slate-200 p-2 rounded-xl w-36 shadow-xs">
            <Cpu className="w-3.5 h-3.5 text-orange-600 animate-spin" />
            <span className="text-[10px] font-bold text-orange-700 animate-pulse">PROCESSING...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-2 bg-white border-t border-slate-200 rounded-b-2xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-1.5"
        >
          <div className="relative flex-1">
            <Terminal className="w-3 h-3 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              id="ai-bot-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Command Cyber Bot..."
              className="w-full bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 text-xs rounded-lg pl-7 pr-3 py-1.5 focus:outline-none focus:border-orange-500 font-mono"
              disabled={isLoading}
            />
          </div>

          <button
            id="ai-bot-send-btn"
            type="submit"
            disabled={!input.trim() || isLoading}
            className="w-7 h-7 bg-orange-600 hover:bg-orange-500 disabled:opacity-30 text-white rounded-lg flex items-center justify-center transition-all font-black shrink-0 shadow-2xs cursor-pointer"
          >
            <Send className="w-3.5 h-3.5 text-white" />
          </button>
        </form>
      </div>
    </div>
  );
};

