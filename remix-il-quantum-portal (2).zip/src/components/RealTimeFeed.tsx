import React, { useState } from 'react';
import { RealTimeLog } from '../types';
import { Radio, DollarSign, UserPlus, Server, AlertTriangle, ShieldCheck, Filter, Trash2 } from 'lucide-react';

interface RealTimeFeedProps {
  logs: RealTimeLog[];
  onClearLogs: () => void;
}

export const RealTimeFeed: React.FC<RealTimeFeedProps> = ({ logs, onClearLogs }) => {
  const [filterType, setFilterType] = useState<string>('all');

  const getLogIcon = (type: RealTimeLog['type']) => {
    switch (type) {
      case 'sale':
        return <DollarSign className="w-4 h-4 text-emerald-400" />;
      case 'signup':
        return <UserPlus className="w-4 h-4 text-cyan-400" />;
      case 'alert':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'deployment':
        return <Server className="w-4 h-4 text-purple-400" />;
      default:
        return <ShieldCheck className="w-4 h-4 text-emerald-400" />;
    }
  };

  const getStatusBadge = (status: RealTimeLog['status']) => {
    switch (status) {
      case 'success':
        return 'bg-emerald-950 text-emerald-300 border-emerald-500 shadow-[0_0_8px_#00ff66]';
      case 'warning':
        return 'bg-amber-950 text-amber-300 border-amber-500 shadow-[0_0_8px_#f59e0b]';
      case 'error':
        return 'bg-rose-950 text-rose-300 border-rose-500 shadow-[0_0_8px_#ff0055]';
      default:
        return 'bg-slate-900 text-slate-300 border-slate-700';
    }
  };

  const filteredLogs = logs.filter((log) => filterType === 'all' || log.type === filterType);

  return (
    <section id="realtime-activity-feed" className="hud-card rounded-2xl p-6 shadow-[0_0_25px_rgba(0,255,102,0.15)] font-mono">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-emerald-500/40 gap-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-emerald-950 rounded-lg text-emerald-400 border border-emerald-500/50 shadow-[0_0_8px_#00ff66]">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-black text-white tracking-tight flex items-center text-glow-emerald uppercase">
              REAL-TIME MATRIX TELEMETRY STREAM
              <span className="ml-2 px-2 py-0.5 text-[10px] font-mono font-bold rounded-md bg-emerald-950 text-emerald-300 border border-emerald-500/50 shadow-[0_0_8px_#00ff66]">
                {logs.length} EVENTS
              </span>
            </h2>
            <p className="text-xs text-emerald-400/80">Live incoming claim transaction logs, neural events, and system alerts</p>
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="flex items-center space-x-2">
          {/* Category Filter */}
          <div className="flex items-center bg-slate-950 p-1.5 rounded-lg border border-emerald-500/40 text-xs">
            <Filter className="w-3.5 h-3.5 text-emerald-400 ml-1 mr-1" />
            <select
              id="log-type-filter"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-slate-950 text-emerald-300 font-mono font-bold focus:outline-none pr-1 cursor-pointer"
            >
              <option value="all">All Events</option>
              <option value="sale">Claim Settlements</option>
              <option value="signup">New Members</option>
              <option value="alert">System Alerts</option>
              <option value="deployment">Deployments</option>
            </select>
          </div>

          <button
            id="clear-logs-btn"
            onClick={onClearLogs}
            className="p-2 text-emerald-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-colors cursor-pointer"
            title="Clear Log Stream"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Logs List Container */}
      <div className="mt-4 space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
        {filteredLogs.length === 0 ? (
          <div className="text-center py-10 text-emerald-600 text-xs">
            NO TELEMETRY EVENTS LOGGED YET FOR THIS FILTER. STREAM UPDATES AUTOMATICALLY IN REAL-TIME.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-slate-950/80 hover:bg-slate-900/90 border border-emerald-500/30 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all shadow-[0_0_10px_rgba(0,255,102,0.05)]"
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-slate-900 border border-emerald-500/40 rounded-lg shrink-0 mt-0.5">
                  {getLogIcon(log.type)}
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xs font-bold text-white font-mono">{log.title}</h3>
                    {log.region && (
                      <span className="text-[10px] font-bold text-cyan-300 bg-slate-900 px-1.5 py-0.5 rounded border border-cyan-500/40 font-mono">
                        {log.region}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-emerald-300/80 mt-0.5 font-mono">{log.detail}</p>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end space-x-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-emerald-500/20">
                {log.value && (
                  <span className="text-xs font-mono font-black text-emerald-400 text-glow-emerald">
                    {log.value}
                  </span>
                )}

                <span className={`px-2 py-0.5 text-[10px] font-mono font-black rounded-md border ${getStatusBadge(log.status)}`}>
                  {log.timestamp}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

    </section>
  );
};
