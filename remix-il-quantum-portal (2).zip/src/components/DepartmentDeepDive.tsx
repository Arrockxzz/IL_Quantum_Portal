import React, { useState } from 'react';
import { DepartmentData } from '../types';
import { Server, Cpu, Layers, ShieldCheck, CheckCircle2, Users, Target, ArrowRight, FileText } from 'lucide-react';

interface DepartmentDeepDiveProps {
  departments: DepartmentData[];
  selectedDeptId: string;
  onSelectDepartment: (id: string) => void;
  onDownloadPdfReport?: () => void;
}

export const DepartmentDeepDive: React.FC<DepartmentDeepDiveProps> = ({
  departments,
  selectedDeptId,
  onSelectDepartment,
  onDownloadPdfReport,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Server':
        return Server;
      case 'Cpu':
        return Cpu;
      case 'Layers':
        return Layers;
      case 'ShieldCheck':
        return ShieldCheck;
      default:
        return Server;
    }
  };

  const selectedDept = departments.find((d) => d.id === selectedDeptId) || departments[0];

  return (
    <section id="department-deep-dive" className="hud-card rounded-2xl p-6 shadow-[0_0_25px_rgba(0,255,102,0.15)] font-mono">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-emerald-500/40 gap-3">
        <div>
          <h2 className="text-lg font-black text-white tracking-tight flex items-center text-glow-emerald uppercase">
            <Layers className="w-5 h-5 mr-2 text-emerald-400" />
            DEPARTMENTAL MATRIX OPERATIONS BREAKDOWN
          </h2>
          <p className="text-xs text-emerald-400/80">
            Select a neural division node to inspect claim metrics, throughput, and active subroutines
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onDownloadPdfReport && (
            <button
              id="dept-download-pdf-btn"
              onClick={onDownloadPdfReport}
              className="flex items-center px-3 py-1.5 text-xs font-black bg-emerald-950 text-emerald-300 rounded-xl border border-emerald-400 shadow-[0_0_10px_#00ff66] hover:bg-emerald-400 hover:text-black transition-all cursor-pointer"
              title="Download Department & KPI PDF Summary Report"
            >
              <FileText className="w-3.5 h-3.5 mr-1.5" />
              DOWNLOAD MATRIX PDF
            </button>
          )}

          {/* Department Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-emerald-500/40 text-xs">
            <button
              onClick={() => onSelectDepartment('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                selectedDeptId === 'all'
                  ? 'bg-cyan-400 text-black shadow-[0_0_10px_#00f0ff]'
                  : 'text-emerald-400 hover:text-white'
              }`}
            >
              All Divisions
            </button>
            {departments.map((dept) => (
              <button
                key={dept.id}
                onClick={() => onSelectDepartment(dept.id)}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  selectedDeptId === dept.id
                    ? 'bg-emerald-400 text-black shadow-[0_0_10px_#00ff66]'
                    : 'text-emerald-400 hover:text-white'
                }`}
              >
                {dept.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Division Detailed Card Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mt-5">
        
        {/* Dept Selector Column */}
        <div className="space-y-2 lg:col-span-1">
          {departments.map((dept) => {
            const Icon = getIcon(dept.iconName);
            const isSelected = selectedDeptId === dept.id;
            const targetPct = Math.min(100, Math.round((dept.revenue / dept.target) * 100));

            return (
              <div
                key={dept.id}
                onClick={() => onSelectDepartment(dept.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-slate-900 border-emerald-400 text-white shadow-[0_0_15px_#00ff66] font-bold'
                    : 'bg-slate-950/80 border-emerald-500/30 text-emerald-300 hover:border-emerald-400 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${isSelected ? 'bg-emerald-400 text-black shadow-[0_0_8px_#00ff66]' : 'bg-slate-900 text-emerald-400 border border-emerald-500/30'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold">{dept.name}</h3>
                    <p className="text-[10px] text-emerald-500">${(dept.revenue / 1000000).toFixed(2)}M / ${(dept.target / 1000000).toFixed(2)}M</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-emerald-400 text-glow-emerald">+{dept.growthYoY}%</span>
                  <div className="w-12 bg-slate-950 border border-emerald-500/30 h-1.5 rounded-full mt-1 overflow-hidden">
                    <div className="bg-emerald-400 h-full rounded-full shadow-[0_0_8px_#00ff66]" style={{ width: `${targetPct}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Division Detail Focus Box */}
        <div className="lg:col-span-3 bg-slate-950/90 border border-emerald-500/40 rounded-xl p-5 flex flex-col justify-between shadow-[0_0_15px_rgba(0,255,102,0.1)]">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-emerald-500/30">
              <div>
                <span className="text-[10px] uppercase tracking-widest font-black text-cyan-400 text-glow-cyan">
                  DIVISION MATRIX NODE
                </span>
                <h3 className="text-lg font-black text-white flex items-center mt-0.5 text-glow-emerald uppercase">
                  {selectedDept.name}
                </h3>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-400 shadow-[0_0_8px_#00ff66]">
                  Health: {selectedDept.healthScore}/100
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-cyan-950 text-cyan-300 border border-cyan-400">
                  Lead: {selectedDept.lead}
                </span>
              </div>
            </div>

            {/* Metrics Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-5">
              <div className="bg-slate-900/90 p-3 rounded-xl border border-emerald-500/40 shadow-inner">
                <span className="text-[10px] text-emerald-400/80 font-bold uppercase">YTD Matrix Claims</span>
                <p className="text-base font-black text-white font-mono mt-0.5 text-glow-emerald">
                  ${(selectedDept.revenue / 1000000).toFixed(2)}M
                </p>
              </div>

              <div className="bg-slate-900/90 p-3 rounded-xl border border-emerald-500/40 shadow-inner">
                <span className="text-[10px] text-emerald-400/80 font-bold uppercase">Annual Target</span>
                <p className="text-base font-black text-white font-mono mt-0.5">
                  ${(selectedDept.target / 1000000).toFixed(2)}M
                </p>
              </div>

              <div className="bg-slate-900/90 p-3 rounded-xl border border-emerald-500/40 shadow-inner">
                <span className="text-[10px] text-emerald-400/80 font-bold uppercase">Active Drones/Agents</span>
                <p className="text-base font-black text-white font-mono mt-0.5 flex items-center">
                  <Users className="w-3.5 h-3.5 mr-1 text-cyan-400" />
                  {selectedDept.headcount} Cyber Staff
                </p>
              </div>

              <div className="bg-slate-900/90 p-3 rounded-xl border border-emerald-500/40 shadow-inner">
                <span className="text-[10px] text-emerald-400/80 font-bold uppercase">Active Initiatives</span>
                <p className="text-base font-black text-white font-mono mt-0.5 flex items-center">
                  <Target className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                  {selectedDept.activeProjects} Subroutines
                </p>
              </div>
            </div>

            {/* Key Milestone Banner */}
            <div className="bg-slate-900 p-4 rounded-xl border border-emerald-500/50 flex items-center justify-between shadow-[0_0_12px_rgba(0,255,102,0.15)]">
              <div className="flex items-center space-x-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 shadow-[0_0_10px_#00ff66]" />
                <div>
                  <p className="text-xs font-black text-white uppercase">
                    PRIMARY MATRIX BENCHMARK
                  </p>
                  <p className="text-xs text-emerald-300">
                    {selectedDept.topMetric}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onSelectDepartment(selectedDept.id)}
                className="hidden sm:flex items-center text-xs font-black text-cyan-400 hover:text-white cursor-pointer"
              >
                ISOLATE TELEMETRY STREAM
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
