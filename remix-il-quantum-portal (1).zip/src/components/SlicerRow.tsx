import React, { useState, useRef, useEffect } from 'react';
import { ClaimRecord, GlobalSlicerFilters } from '../types';
import { Search, Check, X, RefreshCw, BarChart2, Table, Download, Eraser, FileText, ChevronDown, Filter } from 'lucide-react';

interface SlicerRowProps {
  claims: ClaimRecord[];
  filters: GlobalSlicerFilters;
  onUpdateFilters: (newFilters: GlobalSlicerFilters) => void;
  onRefresh: () => void;
  onToggleViewMode: () => void;
  isTableView: boolean;
  onExportCsvGraph: () => void;
  onExportCsvTable: () => void;
  onExportCsvRaw: () => void;
  onExportPptGraph: () => void;
  onExportPptTable: () => void;
  onExportPdfGraph: () => void;
  onExportPdfTable: () => void;
  onToggleFilesPanel: () => void;
  onClearFilters: () => void;
}

export const SlicerRow: React.FC<SlicerRowProps> = ({
  claims,
  filters,
  onUpdateFilters,
  onRefresh,
  onToggleViewMode,
  isTableView,
  onExportCsvGraph,
  onExportCsvTable,
  onExportCsvRaw,
  onExportPptGraph,
  onExportPptTable,
  onExportPdfGraph,
  onExportPdfTable,
  onToggleFilesPanel,
  onClearFilters,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setActiveDropdown(null);
        setIsExportOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Defined slicer fields
  const slicerConfigs: { key: keyof GlobalSlicerFilters; label: string }[] = [
    { key: 'policy_name', label: 'Policy' },
    { key: 'policy_no', label: 'Policy No' },
    { key: 'iltc_tag', label: 'ILTC' },
    { key: 'whether_hospital_networked', label: 'Network Hosp' },
    { key: 'relation_group', label: 'Relation' },
    { key: 'type_of_claim', label: 'Type' },
    { key: 'updated_status', label: 'Status' },
    { key: 'age_band', label: 'Age Band' },
    { key: 'disease_category', label: 'Disease' },
    { key: 'ipd_opd', label: 'IPD/OPD' },
    { key: '__monthYear', label: 'MonthYear' },
  ];

  // Helper to extract distinct options for a key
  const getDistinctValues = (key: keyof GlobalSlicerFilters): string[] => {
    const set = new Set<string>();
    claims.forEach((c) => {
      const val = c[key];
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        set.add(String(val));
      }
    });
    return Array.from(set).sort();
  };

  const handleToggleValue = (key: keyof GlobalSlicerFilters, value: string) => {
    const current = filters[key] || [];
    const updated = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];

    onUpdateFilters({
      ...filters,
      [key]: updated,
    });
    setActiveDropdown(null); // Close after selection as per BRD requirement
  };

  const handleSelectAll = (key: keyof GlobalSlicerFilters, visibleValues: string[]) => {
    onUpdateFilters({
      ...filters,
      [key]: visibleValues,
    });
    setActiveDropdown(null);
  };

  const handleRemoveAll = (key: keyof GlobalSlicerFilters) => {
    onUpdateFilters({
      ...filters,
      [key]: [],
    });
    setActiveDropdown(null);
  };

  return (
    <div id="slicer-row-container" className="bg-white/95 border-b border-slate-200 backdrop-blur-xl py-2 px-3 sm:px-6 z-30 font-mono shadow-2xs text-slate-800" ref={dropdownRef}>
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        
        {/* Slicers Container */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {slicerConfigs.map(({ key, label }) => {
            const options = getDistinctValues(key);
            const selected = filters[key] || [];
            const isOpen = activeDropdown === key;
            const isFiltered = selected.length > 0;

            const filteredOptions = options.filter((opt) =>
              opt.toLowerCase().includes(searchTerm.toLowerCase())
            );

            return (
              <div key={key} className="relative">
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setActiveDropdown(isOpen ? null : key);
                    setIsExportOpen(false);
                  }}
                  className={`flex items-center px-2.5 py-1 rounded-lg border font-bold transition-all text-xs cursor-pointer ${
                    isFiltered
                      ? 'bg-orange-600 text-white border-orange-500 shadow-2xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
                  }`}
                  title={`Filter by ${label}`}
                >
                  <Filter className="w-3 h-3 mr-1 text-slate-500 opacity-80" />
                  <span>{label}</span>
                  {selected.length > 0 && (
                    <span className="ml-1 bg-white text-orange-600 font-extrabold px-1.5 py-0.2 rounded-full text-[10px] border border-orange-200">
                      {selected.length}
                    </span>
                  )}
                  <ChevronDown className="w-3 h-3 ml-1 opacity-70" />
                </button>

                {/* Dropdown Box */}
                {isOpen && (
                  <div className="absolute left-0 mt-1.5 w-64 bg-white border border-slate-200 text-slate-900 rounded-xl shadow-xl z-50 p-2.5 text-xs space-y-2 font-mono">
                    
                    {/* Header Controls: Search & Select All / Remove All */}
                    <div className="flex items-center space-x-1.5">
                      <div className="relative flex-1">
                        <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-slate-400" />
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder={`Filter ${label}...`}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-7 pr-2 py-1 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-orange-500"
                        />
                      </div>
                      <button
                        onClick={() => handleSelectAll(key, filteredOptions)}
                        className="p-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 rounded-lg border border-orange-200 cursor-pointer"
                        title="Select All Visible"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleRemoveAll(key)}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg border border-rose-200 cursor-pointer"
                        title="Remove All Selections"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Checkbox Value List */}
                    <div className="max-h-48 overflow-y-auto space-y-1 pt-1 border-t border-slate-100">
                      {filteredOptions.length === 0 ? (
                        <div className="text-center py-3 text-slate-400 text-[11px]">No matching parameters</div>
                      ) : (
                        filteredOptions.map((val) => {
                          const isChecked = selected.includes(val);
                          return (
                            <label
                              key={val}
                              className={`flex items-center space-x-2 px-2 py-1 rounded cursor-pointer transition-colors ${
                                isChecked ? 'bg-orange-50 text-orange-900 font-bold border-l-2 border-orange-500' : 'hover:bg-slate-100 text-slate-700'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => handleToggleValue(key, val)}
                                className="accent-orange-600 rounded"
                              />
                              <span className="truncate">{val}</span>
                            </label>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Action Icons Row: Refresh, View Toggle, Export, Clear, Uploaded Files */}
        <div className="flex items-center space-x-1 border-l border-slate-200 pl-2">
          
          {/* Refresh Charts Icon [🔄] */}
          <button
            id="slicer-refresh-btn"
            onClick={onRefresh}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg transition-all active:scale-95 cursor-pointer"
            title="Refresh Cyber Telemetry"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-700" />
          </button>

          {/* View Mode Toggle [📊 / 📋] */}
          <button
            id="slicer-view-toggle-btn"
            onClick={onToggleViewMode}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-orange-700 border border-slate-300 rounded-lg transition-all active:scale-95 cursor-pointer"
            title={isTableView ? 'Switch to Neural Visuals' : 'Switch to Data Matrix Table'}
          >
            {isTableView ? <BarChart2 className="w-3.5 h-3.5 text-orange-600" /> : <Table className="w-3.5 h-3.5 text-orange-600" />}
          </button>

          {/* Export Options Popover Trigger [📥] */}
          <div className="relative">
            <button
              id="slicer-export-btn"
              onClick={() => {
                setIsExportOpen(!isExportOpen);
                setActiveDropdown(null);
              }}
              className={`p-1.5 rounded-lg border transition-all active:scale-95 cursor-pointer ${
                isExportOpen
                  ? 'bg-orange-600 text-white border-orange-500 shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
              }`}
              title="Export Telemetry Data"
            >
              <Download className="w-3.5 h-3.5" />
            </button>

            {/* Export Popover Panel */}
            {isExportOpen && (
              <div className="absolute right-0 mt-1.5 w-64 bg-white border border-slate-200 text-slate-900 rounded-xl shadow-xl z-50 p-3 space-y-3 text-xs font-mono">
                <div className="font-bold text-slate-900 border-b border-slate-200 pb-1.5 flex items-center justify-between">
                  <span>EXPORT TELEMETRY</span>
                  <X
                    className="w-3.5 h-3.5 cursor-pointer text-slate-400 hover:text-slate-700"
                    onClick={() => setIsExportOpen(false)}
                  />
                </div>

                {/* CSV Options */}
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-bold text-orange-700">CSV Data Stream</div>
                  <div className="grid grid-cols-3 gap-1">
                    <button
                      onClick={() => {
                        onExportCsvGraph();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-slate-100 hover:bg-orange-50 border border-slate-200 rounded text-slate-800 hover:text-orange-800 font-bold cursor-pointer"
                    >
                      Graph
                    </button>
                    <button
                      onClick={() => {
                        onExportCsvTable();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-slate-100 hover:bg-orange-50 border border-slate-200 rounded text-slate-800 hover:text-orange-800 font-bold cursor-pointer"
                    >
                      Table
                    </button>
                    <button
                      onClick={() => {
                        onExportCsvRaw();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-slate-100 hover:bg-orange-50 border border-slate-200 rounded text-slate-800 hover:text-orange-800 font-bold cursor-pointer"
                    >
                      Raw Data
                    </button>
                  </div>
                </div>

                {/* PPT Options */}
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-bold text-orange-700">PPT Presentation Deck</div>
                  <div className="grid grid-cols-2 gap-1">
                    <button
                      onClick={() => {
                        onExportPptGraph();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-slate-100 hover:bg-orange-50 border border-slate-200 rounded text-slate-800 hover:text-orange-800 font-bold cursor-pointer"
                    >
                      PPT Graph
                    </button>
                    <button
                      onClick={() => {
                        onExportPptTable();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-slate-100 hover:bg-orange-50 border border-slate-200 rounded text-slate-800 hover:text-orange-800 font-bold cursor-pointer"
                    >
                      PPT Table
                    </button>
                  </div>
                </div>

                {/* PDF Options */}
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-bold text-orange-700">PDF Report</div>
                  <div className="grid grid-cols-2 gap-1">
                    <button
                      onClick={() => {
                        onExportPdfGraph();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-orange-600 hover:bg-orange-500 text-white font-black rounded cursor-pointer"
                    >
                      PDF Summary
                    </button>
                    <button
                      onClick={() => {
                        onExportPdfTable();
                        setIsExportOpen(false);
                      }}
                      className="px-2 py-1 bg-orange-600 hover:bg-orange-500 text-white font-black rounded cursor-pointer"
                    >
                      PDF Detail
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Clear Filters Broom Icon [🧹] */}
          <button
            id="slicer-clear-btn"
            onClick={onClearFilters}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-rose-600 border border-slate-300 rounded-lg transition-all active:scale-95 cursor-pointer"
            title="Purge Filters"
          >
            <Eraser className="w-3.5 h-3.5 text-rose-600" />
          </button>

          {/* Uploaded Files Details Toggle Icon [📁] */}
          <button
            id="slicer-files-panel-btn"
            onClick={onToggleFilesPanel}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-lg transition-all active:scale-95 cursor-pointer"
            title="View Ingested File Buffers"
          >
            <FileText className="w-3.5 h-3.5 text-slate-700" />
          </button>

        </div>

      </div>
    </div>
  );
};
