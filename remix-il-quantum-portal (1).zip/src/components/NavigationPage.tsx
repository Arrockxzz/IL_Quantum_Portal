import React, { useState } from 'react';
import { Users, Building2, Layers, ArrowLeft, Home, ArrowRight, ShieldCheck, Cpu, Terminal, Bot, Radio, Volume2, VolumeX } from 'lucide-react';
import { MatrixBackground, MatrixTheme } from './MatrixBackground';

interface NavigationPageProps {
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
}

export const NavigationPage: React.FC<NavigationPageProps> = ({ onSelectModule, onGoHome }) => {
  const [matrixTheme, setMatrixTheme] = useState<MatrixTheme>('amber');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Play sci-fi audio beep if audio is enabled
  const triggerCyberBeep = (freq = 880) => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq / 3, audioCtx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } catch (e) {
      // Fallback silent
    }
  };

  const handleModuleClick = (moduleName: string) => {
    triggerCyberBeep(920);
    onSelectModule(moduleName);
  };

  return (
    <div id="navigation-page" className="relative min-h-screen bg-slate-50 text-slate-800 font-mono flex flex-col justify-between p-4 sm:p-8 select-none overflow-hidden">
      
      {/* Background Matrix Rain Effect */}
      <MatrixBackground theme={matrixTheme} speed={0.9} opacity={0.4} />

      {/* Top Header */}
      <div className="relative z-10 max-w-6xl mx-auto w-full flex flex-col sm:flex-row items-center justify-between border border-slate-200 bg-white p-3.5 sm:p-4 rounded-xl shadow-sm gap-3 sm:gap-0">
        <div className="flex items-center space-x-3 w-full sm:w-auto">
          <div className="w-10 h-10 bg-orange-500 border border-orange-400 rounded-xl flex items-center justify-center text-white shadow-sm shrink-0">
            <Cpu className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-black tracking-wider text-slate-900 leading-tight">
              ICICI LOMBARD // IL QUANTUM
            </h1>
            <p className="text-[11px] sm:text-xs text-orange-600 font-bold flex items-center">
              <Radio className="w-3 h-3 mr-1 text-orange-600 animate-pulse" /> WORKSPACE NAVIGATOR
            </p>
          </div>
        </div>
        
        {/* Right Header Section: Controls & Return to Gate */}
        <div className="flex flex-wrap items-center space-x-2 sm:space-x-3 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs w-full sm:w-auto justify-between sm:justify-end gap-y-2">
          
          {/* Accent Color Controls */}
          <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-700">
            <Radio className="w-3.5 h-3.5 text-orange-600 animate-pulse" />
            <span className="text-[11px] text-slate-600 font-extrabold uppercase mr-1 hidden sm:inline">ACCENT:</span>
            <button
              onClick={() => {
                setMatrixTheme('amber');
                triggerCyberBeep(660);
              }}
              className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                matrixTheme === 'amber' ? 'ring-2 ring-orange-500 bg-orange-600 border-orange-400 scale-110' : 'bg-orange-200 border-orange-300 hover:scale-105'
              }`}
              title="ICICI Amber Accent"
            />
            <button
              onClick={() => {
                setMatrixTheme('emerald');
                triggerCyberBeep(880);
              }}
              className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                matrixTheme === 'emerald' ? 'ring-2 ring-emerald-500 bg-emerald-600 border-emerald-400 scale-110' : 'bg-emerald-200 border-emerald-300 hover:scale-105'
              }`}
              title="Emerald Green Accent"
            />
            <button
              onClick={() => {
                setMatrixTheme('cyan');
                triggerCyberBeep(1100);
              }}
              className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                matrixTheme === 'cyan' ? 'ring-2 ring-sky-500 bg-sky-600 border-sky-400 scale-110' : 'bg-sky-200 border-sky-300 hover:scale-105'
              }`}
              title="Cyber Cyan Accent"
            />
          </div>

          <div className="h-4 w-px bg-slate-300 mx-1 hidden sm:block" />

          {/* Audio Control */}
          <button
            onClick={() => {
              const next = !soundEnabled;
              setSoundEnabled(next);
              if (next) triggerCyberBeep(750);
            }}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg text-[10px] font-black border transition-all cursor-pointer ${
              soundEnabled
                ? 'border-orange-500 text-orange-700 bg-orange-50 hover:bg-orange-100 shadow-2xs'
                : 'border-slate-300 text-slate-500 bg-slate-100 hover:bg-slate-200'
            }`}
            title="Toggle Sci-Fi Audio Synthesizer Feedback"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-orange-600" />
                <span>AUDIO ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                <span>AUDIO OFF</span>
              </>
            )}
          </button>

          <div className="h-4 w-px bg-slate-300 mx-1 hidden sm:block" />

          {/* Return to Gate Button */}
          <button
            onClick={() => {
              triggerCyberBeep(520);
              onGoHome();
            }}
            className="flex items-center space-x-1.5 px-3 py-1 bg-white hover:bg-orange-50 text-slate-700 hover:text-orange-600 text-xs font-bold rounded-lg border border-slate-200 hover:border-orange-300 transition-all cursor-pointer shadow-2xs"
            title="Return to First Gate Portal"
          >
            <Home className="w-3.5 h-3.5 text-orange-600" />
            <span>RETURN TO GATE</span>
          </button>

        </div>
      </div>

      {/* Main Module Cards */}
      <div className="relative z-10 max-w-6xl mx-auto w-full my-auto py-6">
        <div className="text-center mb-8 sm:mb-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-orange-50 border border-orange-200 rounded-full text-xs font-bold text-orange-800 mb-3 shadow-2xs">
            <Terminal className="w-3.5 h-3.5 text-orange-600" />
            <span>NEURAL CORE SELECTION // SELECT WORKSPACE MODULE</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-wider">
            SELECT OPERATIONAL SUITE
          </h2>
          <p className="text-xs text-slate-600 mt-2 font-mono max-w-xl mx-auto font-medium leading-relaxed">
            Choose a health claims analytics workspace to initialize real-time claims data stream, automated AI audit engines, and interactive field slicers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Business Team (Main Route) */}
          <div
            onClick={() => handleModuleClick('Business Team')}
            className="hud-card group relative bg-white border-2 border-orange-500 hover:border-orange-600 rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
          >
            <div className="absolute top-4 right-4 bg-orange-600 text-white font-black text-[10px] uppercase px-2.5 py-0.5 rounded-full shadow-2xs">
              PRIMARY WORKSPACE
            </div>

            <div>
              <div className="w-14 h-14 bg-orange-500 rounded-xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform shadow-md">
                <Bot className="w-8 h-8 text-white animate-robot-eye" />
              </div>
              <h3 className="text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors font-mono">
                BUSINESS TEAM MATRIX
              </h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed font-mono">
                Primary Health Claims Analytics Terminal with Excel/CSV Upload Ingestion, 11-Field Slicer Engine, AI Bot Assistant & Custom Chart Generator.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between text-xs font-bold text-orange-600">
              <span className="flex items-center">
                <Terminal className="w-3.5 h-3.5 mr-1 text-orange-600" /> INITIALIZE WORKSPACE
              </span>
              <ArrowRight className="w-4 h-4 text-orange-600 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: GHI Analytics Suite */}
          <div
            onClick={() => handleModuleClick('GHI Analytics')}
            className="hud-card group relative bg-white border border-slate-200 hover:border-orange-400 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
          >
            <div>
              <div className="w-14 h-14 bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-center text-slate-700 mb-4 group-hover:scale-110 transition-transform">
                <Building2 className="w-7 h-7 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors font-mono">
                GHI CLAIMS MATRIX
              </h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed font-mono">
                Group Health Insurance corporate breakdown, employer loss-ratio metrics, and network hospital matrix utilization.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-slate-700 group-hover:text-orange-600">
              <span>LOAD GHI MODULE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Retail Claims Engine */}
          <div
            onClick={() => handleModuleClick('Retail Claims')}
            className="hud-card group relative bg-white border border-slate-200 hover:border-orange-400 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1 backdrop-blur-md"
          >
            <div>
              <div className="w-14 h-14 bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-center text-slate-700 mb-4 group-hover:scale-110 transition-transform">
                <Layers className="w-7 h-7 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 group-hover:text-orange-600 transition-colors font-mono">
                RETAIL CLAIMS MATRIX
              </h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed font-mono">
                Individual and Super Top-Up policy claims, age-band distribution vectors, and loss-ratio deep-dive analysis.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-slate-700 group-hover:text-orange-600">
              <span>LOAD RETAIL MODULE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Control Bar */}
      <div className="relative z-10 max-w-6xl mx-auto w-full flex flex-wrap items-center justify-between border border-slate-200 pt-3 pb-3 text-xs text-slate-600 bg-white/95 p-4 rounded-xl shadow-sm gap-4">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-slate-800 font-bold">HEALTH CLAIMS LINK // ACTIVE</span>
        </div>

        <div className="flex items-center space-x-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
          <button
            onClick={() => {
              triggerCyberBeep(500);
              onGoHome();
            }}
            className="flex items-center space-x-1 px-3 py-1.5 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer font-bold"
            title="Back to Landing Gate"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>BACK</span>
          </button>
          <button
            onClick={() => {
              triggerCyberBeep(520);
              onGoHome();
            }}
            className="flex items-center space-x-1 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-black rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="Home"
          >
            <Home className="w-3.5 h-3.5" />
            <span>HOME</span>
          </button>
          <button
            onClick={() => handleModuleClick('Business Team')}
            className="flex items-center space-x-1 px-3 py-1.5 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors cursor-pointer font-bold"
            title="Next to Dashboard"
          >
            <span>NEXT</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </div>
  );
};


