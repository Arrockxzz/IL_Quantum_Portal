import React, { useState } from 'react';
import { PortalSettings } from '../types';
import { Settings, X, RotateCcw, Check, Sun, Moon, Sliders, Palette } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PortalSettings;
  onUpdateSettings: (newSettings: PortalSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [localSettings, setLocalSettings] = useState<PortalSettings>(settings);

  if (!isOpen) return null;

  const handleApply = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const handleReset = () => {
    const defaultSettings: PortalSettings = {
      themePreset: 'il-orange',
      colorScheme: 'default',
      darkMode: false,
      fontSize: 'medium',
      topNLimit: 10,
      maxFileSizeMb: 25,
    };
    setLocalSettings(defaultSettings);
  };

  return (
    <div id="settings-modal-backdrop" className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 font-mono">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden space-y-4 text-slate-800">
        
        {/* Header */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-4 text-slate-900 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-orange-600" />
            <h3 className="text-base font-black uppercase">PORTAL CONFIGURATION</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4 text-xs font-mono text-slate-700">
          
          {/* Theme Preset */}
          <div>
            <label className="block font-black text-slate-900 uppercase mb-1.5 flex items-center gap-1">
              <Palette className="w-3.5 h-3.5 text-orange-600" /> COLOR ACCENT
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'il-orange', name: 'ICICI Orange', color: 'bg-orange-500' },
                { id: 'corporate-blue', name: 'Corporate Blue', color: 'bg-blue-600' },
                { id: 'slate-dark', name: 'Emerald Slate', color: 'bg-emerald-600' },
                { id: 'emerald', name: 'Minimal Gray', color: 'bg-slate-700' },
              ].map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setLocalSettings((prev) => ({ ...prev, themePreset: preset.id as any }))}
                  className={`flex items-center space-x-2 p-2 rounded-xl border font-bold transition-all cursor-pointer ${
                    localSettings.themePreset === preset.id
                      ? 'border-orange-500 bg-orange-50 text-orange-900 shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full ${preset.color} shrink-0`} />
                  <span className="truncate">{preset.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Dark Mode Toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <div className="font-black text-slate-900 flex items-center gap-1.5 uppercase">
                {localSettings.darkMode ? <Moon className="w-3.5 h-3.5 text-orange-600" /> : <Sun className="w-3.5 h-3.5 text-orange-600" />}
                Scanline Visual Effects
              </div>
              <p className="text-[10px] text-slate-500">Toggle retro grid matrix overlay</p>
            </div>
            <button
              onClick={() => setLocalSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }))}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer border border-slate-300 ${
                localSettings.darkMode ? 'bg-orange-600 justify-end' : 'bg-slate-200 justify-start'
              }`}
            >
              <span className="w-4 h-4 bg-white rounded-full shadow-2xs" />
            </button>
          </div>

          {/* Font Size & Top N Limits */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-900 mb-1 uppercase text-[10px]">Text Scale</label>
              <select
                value={localSettings.fontSize}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, fontSize: e.target.value as any }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono font-bold text-slate-800 focus:outline-none focus:border-orange-500 cursor-pointer"
              >
                <option value="small">Compact (Small)</option>
                <option value="medium">Default (Medium)</option>
                <option value="large">High-Def (Large)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-900 mb-1 uppercase text-[10px]">Top N Limit</label>
              <select
                value={localSettings.topNLimit}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, topNLimit: Number(e.target.value) }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono font-bold text-slate-800 focus:outline-none focus:border-orange-500 cursor-pointer"
              >
                <option value={5}>Top 5</option>
                <option value={10}>Top 10</option>
                <option value={15}>Top 15</option>
                <option value={25}>Top 25</option>
              </select>
            </div>
          </div>

          {/* Max Upload File Size */}
          <div>
            <label className="block font-bold text-slate-900 mb-1 uppercase text-[10px]">Max Data Buffer Size (MB)</label>
            <input
              type="number"
              value={localSettings.maxFileSizeMb}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, maxFileSizeMb: Number(e.target.value) }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono font-bold text-slate-800 focus:outline-none focus:border-orange-500"
              min={5}
              max={100}
            />
          </div>

        </div>

        {/* Footer Buttons */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between text-xs font-mono">
          <button
            onClick={handleReset}
            className="flex items-center space-x-1 text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET DEFAULTS</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-slate-700 hover:text-slate-900 border border-slate-300 rounded-lg font-bold bg-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center space-x-1 px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-black rounded-lg shadow-2xs cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>APPLY CONFIG</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
