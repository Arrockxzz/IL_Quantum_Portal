import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Users, DollarSign, Activity, ShieldCheck, Heart, Minus, Clock, Info } from 'lucide-react';
import { MetricKpis } from '../types';
import { INITIAL_KPIS } from '../data/initialData';

interface KpiGridProps {
  kpis: MetricKpis;
  sessionStartKpis?: MetricKpis;
  activeFilterKey?: string;
  onSelectKpiFilter?: (key: string) => void;
}

export const KpiGrid: React.FC<KpiGridProps> = ({
  kpis,
  sessionStartKpis = INITIAL_KPIS,
  activeFilterKey,
  onSelectKpiFilter,
}) => {
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>('');

  useEffect(() => {
    setLastUpdatedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  }, [kpis]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Helper to construct comparison metrics with upward/downward variance indicators
  const createCardData = (
    id: string,
    title: string,
    value: string,
    currentNum: number,
    baselineNum: number,
    subtext: string,
    changeBenchmark: string,
    icon: any,
    color: string,
    progressVal: number,
    isLowerBetter: boolean = false,
    unit: string = ''
  ) => {
    const rawVariance = currentNum - baselineNum;
    const pctChange = baselineNum ? ((currentNum - baselineNum) / baselineNum) * 100 : 0;
    
    // Determine trend direction
    const isUp = rawVariance > 0;
    const isDown = rawVariance < 0;
    const isNeutral = rawVariance === 0;

    // Determine if favorable or unfavorable change
    let isGood = false;
    let isBad = false;

    if (isLowerBetter) {
      isGood = isDown;
      isBad = isUp;
    } else {
      isGood = isUp;
      isBad = isDown;
    }

    // Calculate Projected EOD based on current trend velocity
    let projectedVal = currentNum;
    if (rawVariance !== 0) {
      projectedVal = currentNum + rawVariance * 2.2;
    } else {
      if (id === 'arr') projectedVal = currentNum * 1.0015;
      else if (id === 'mrr') projectedVal = currentNum * 1.002;
      else if (id === 'users') projectedVal = currentNum + 185;
      else if (id === 'latency') projectedVal = Math.max(20, currentNum - 1);
      else if (id === 'uptime') projectedVal = 99.99;
      else if (id === 'nps') projectedVal = Math.min(100, currentNum + 1);
    }

    // Apply logical constraints/clamps
    if (id === 'uptime') projectedVal = Math.min(100, Math.max(98.5, projectedVal));
    if (id === 'nps') projectedVal = Math.min(100, Math.max(0, Math.round(projectedVal)));
    if (id === 'latency') projectedVal = Math.max(12, Math.round(projectedVal));

    // Format projected EOD string
    let projectedEodStr = '';
    if (unit === '$') {
      if (projectedVal >= 1000000) {
        projectedEodStr = `$${(projectedVal / 1000000).toFixed(2)}M`;
      } else if (projectedVal >= 1000) {
        projectedEodStr = `$${(projectedVal / 1000).toFixed(1)}k`;
      } else {
        projectedEodStr = `$${Math.round(projectedVal).toLocaleString()}`;
      }
    } else if (unit === 'ms') {
      projectedEodStr = `${Math.round(projectedVal)} ms`;
    } else if (unit === '%') {
      projectedEodStr = `${projectedVal.toFixed(2)}%`;
    } else if (unit === 'pts') {
      projectedEodStr = `${Math.round(projectedVal)} / 100`;
    } else {
      projectedEodStr = Math.round(projectedVal).toLocaleString();
    }

    // Format raw variance and baseline for hover tooltip
    let formattedRawVariance = '';
    let formattedBaseline = '';
    if (unit === '$') {
      formattedRawVariance = `${rawVariance >= 0 ? '+' : '-'}$${Math.abs(rawVariance).toLocaleString()}`;
      formattedBaseline = formatCurrency(baselineNum);
    } else if (unit === 'ms') {
      formattedRawVariance = `${rawVariance > 0 ? '+' : ''}${rawVariance} ms`;
      formattedBaseline = `${baselineNum} ms`;
    } else if (unit === '%') {
      formattedRawVariance = `${rawVariance > 0 ? '+' : ''}${rawVariance.toFixed(2)}%`;
      formattedBaseline = `${baselineNum}%`;
    } else if (unit === 'pts') {
      formattedRawVariance = `${rawVariance > 0 ? '+' : ''}${rawVariance} pts`;
      formattedBaseline = `${baselineNum} / 100`;
    } else {
      formattedRawVariance = `${rawVariance > 0 ? '+' : ''}${rawVariance.toLocaleString()}`;
      formattedBaseline = baselineNum.toLocaleString();
    }

    // Format variance display text
    let varianceStr = '';
    if (unit === '$') {
      const absVal = Math.abs(rawVariance);
      const formattedAbs = absVal >= 1000000 
        ? `$${(absVal / 1000000).toFixed(2)}M` 
        : absVal >= 1000 
        ? `$${(absVal / 1000).toFixed(1)}k` 
        : `$${absVal.toLocaleString()}`;
      varianceStr = `${rawVariance > 0 ? '+' : rawVariance < 0 ? '-' : ''}${formattedAbs}`;
    } else if (unit === 'ms') {
      varianceStr = `${rawVariance > 0 ? '+' : ''}${rawVariance} ms`;
    } else if (unit === '%') {
      varianceStr = `${rawVariance > 0 ? '+' : ''}${rawVariance.toFixed(1)}%`;
    } else if (unit === 'pts') {
      varianceStr = `${rawVariance > 0 ? '+' : ''}${rawVariance} pts`;
    } else {
      varianceStr = `${pctChange > 0 ? '+' : ''}${pctChange.toFixed(1)}%`;
    }

    return {
      id,
      title,
      value,
      projectedEodStr,
      rawVariance,
      formattedRawVariance,
      formattedBaseline,
      pctChange,
      varianceStr,
      isUp,
      isDown,
      isNeutral,
      isGood,
      isBad,
      subtext,
      changeBenchmark,
      icon,
      color,
      progressVal,
    };
  };

  const cards = [
    createCardData(
      'arr',
      'ARR (Annual Recurring)',
      formatCurrency(kpis.arr),
      kpis.arr,
      sessionStartKpis.arr,
      `+$${((kpis.arr * 0.001) / 1000).toFixed(1)}k today`,
      `+${kpis.arrGrowthYoY}% YoY`,
      DollarSign,
      'bg-orange-50 text-orange-600 border-orange-100 dark:bg-slate-800 dark:text-orange-400 dark:border-slate-700',
      82,
      false,
      '$'
    ),
    createCardData(
      'mrr',
      'MRR (Monthly Run Rate)',
      formatCurrency(kpis.mrr),
      kpis.mrr,
      sessionStartKpis.mrr,
      'Target: $1.25M',
      '+2.8% MoM',
      TrendingUp,
      'bg-orange-50 text-orange-600 border-orange-100 dark:bg-slate-800 dark:text-orange-400 dark:border-slate-700',
      90,
      false,
      '$'
    ),
    createCardData(
      'users',
      'Active Subscribers',
      kpis.activeUsers.toLocaleString(),
      kpis.activeUsers,
      sessionStartKpis.activeUsers,
      `+${kpis.activeUsersTodayDelta} active today`,
      '+14.2% MoM',
      Users,
      'bg-orange-50 text-orange-600 border-orange-100 dark:bg-slate-800 dark:text-orange-400 dark:border-slate-700',
      75,
      false,
      ''
    ),
    createCardData(
      'latency',
      'System Latency (P95)',
      `${kpis.latencyMs} ms`,
      kpis.latencyMs,
      sessionStartKpis.latencyMs,
      'Peak: 64ms | SLA < 50ms',
      kpis.latencyMs < 45 ? '-4ms Optimal' : '+8ms High',
      Activity,
      kpis.latencyMs < 45 
        ? 'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-slate-800 dark:text-emerald-400 dark:border-slate-700' 
        : 'bg-amber-50 text-amber-600 border-amber-100 dark:bg-slate-800 dark:text-amber-400 dark:border-slate-700',
      Math.max(10, 100 - kpis.latencyMs),
      true, // isLowerBetter
      'ms'
    ),
    createCardData(
      'uptime',
      'System SLA Uptime',
      `${kpis.uptimePercent}%`,
      kpis.uptimePercent,
      sessionStartKpis.uptimePercent,
      '0 downtime incidents in 30d',
      '100% Target',
      ShieldCheck,
      'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-slate-800 dark:text-emerald-400 dark:border-slate-700',
      99,
      false,
      '%'
    ),
    createCardData(
      'nps',
      'Net Promoter Score',
      `${kpis.npsScore} / 100`,
      kpis.npsScore,
      sessionStartKpis.npsScore,
      'Based on 4,200 surveys',
      'Top 5% SaaS',
      Heart,
      'bg-rose-50 text-rose-600 border-rose-100 dark:bg-slate-800 dark:text-rose-400 dark:border-slate-700',
      kpis.npsScore,
      false,
      'pts'
    ),
  ];

  return (
    <section id="kpi-cards-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 font-mono">
      {cards.map((card) => {
        const Icon = card.icon;
        const isSelected = activeFilterKey === card.id;

        return (
          <div
            key={card.id}
            id={`kpi-card-${card.id}`}
            onClick={() => onSelectKpiFilter && onSelectKpiFilter(card.id)}
            className={`hud-card rounded-2xl p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 cursor-pointer group hover:scale-[1.02] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative ${
              isSelected ? 'ring-2 ring-orange-500 border-orange-500 shadow-md' : ''
            }`}
          >
            {/* Interactive Hover Tooltip Popover */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none scale-95 group-hover:scale-100 w-56 sm:w-60 bg-slate-900 text-white border border-slate-700/80 rounded-xl p-3 shadow-2xl font-mono text-[11px]">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2">
                <span className="font-extrabold text-orange-400 uppercase text-[10px] tracking-wider truncate max-w-[140px]">
                  {card.title}
                </span>
                <span className="text-[9px] text-slate-400 flex items-center gap-1 font-semibold shrink-0">
                  <Clock className="w-2.5 h-2.5 text-slate-400" />
                  {lastUpdatedTime || 'Just now'}
                </span>
              </div>
              
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Exact % Change:</span>
                  <span className={`font-black ${card.pctChange > 0 ? 'text-emerald-400' : card.pctChange < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                    {card.pctChange > 0 ? '+' : ''}{card.pctChange.toFixed(2)}%
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Raw Variance:</span>
                  <span className={`font-black ${card.isGood ? 'text-emerald-400' : card.isBad ? 'text-rose-400' : 'text-slate-200'}`}>
                    {card.formattedRawVariance}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px]">
                  <span className="text-slate-400">Start Baseline:</span>
                  <span className="text-slate-200 font-bold">{card.formattedBaseline}</span>
                </div>
              </div>

              {/* Pointer Caret */}
              <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px border-4 border-transparent border-t-slate-900" />
            </div>

            {/* Top Row: Title + Icon */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 dark:text-slate-400 text-[11px] font-bold uppercase tracking-wider truncate">
                  {card.title}
                </span>
                <div className={`p-1.5 rounded-lg border shrink-0 ml-1 ${card.color}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Main Value & Trend Indicator Badge */}
              <div className="flex items-baseline justify-between mt-1 gap-1">
                <div className="flex flex-col min-w-0">
                  <div className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight truncate font-mono">
                    {card.value}
                  </div>
                  <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1 font-mono">
                    <span className="text-slate-400 dark:text-slate-500 font-semibold uppercase text-[9px] tracking-tight">Proj. EOD:</span>
                    <span className="text-orange-600 dark:text-orange-400 font-bold">{card.projectedEodStr}</span>
                  </div>
                </div>

                {/* Session Variance Badge with Upward / Downward Trend Indicator */}
                <div className="flex flex-col items-end shrink-0 ml-1">
                  <div
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-extrabold border transition-colors ${
                      card.isGood
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/80 dark:text-emerald-300 dark:border-emerald-700/60'
                        : card.isBad
                        ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/80 dark:text-rose-300 dark:border-rose-700/60'
                        : 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                    }`}
                    title={`Variance from session start: ${card.varianceStr} (${card.pctChange.toFixed(2)}%)`}
                  >
                    {card.isUp ? (
                      <TrendingUp className={`w-3.5 h-3.5 mr-1 shrink-0 ${card.isGood ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`} />
                    ) : card.isDown ? (
                      <TrendingDown className={`w-3.5 h-3.5 mr-1 shrink-0 ${card.isGood ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`} />
                    ) : (
                      <Minus className="w-3.5 h-3.5 mr-1 shrink-0 text-slate-400" />
                    )}
                    <span>{card.varianceStr}</span>
                  </div>
                  <span className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold tracking-tight mt-0.5 uppercase">
                    vs session start
                  </span>
                </div>
              </div>
            </div>

            {/* Subtext, Benchmark, and Progress Bar */}
            <div className="mt-3">
              <div className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-orange-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${card.progressVal}%` }}
                />
              </div>
              <div className="flex items-center justify-between mt-2 text-[10px] text-slate-500 dark:text-slate-400 font-semibold">
                <span className="truncate">{card.subtext}</span>
                <span className="text-[9px] text-orange-600 dark:text-orange-400 font-bold shrink-0 ml-1">
                  {card.changeBenchmark}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </section>
  );
};


