import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock, Bot, Terminal, Cpu, Radio, Sparkles } from 'lucide-react';
import { MatrixBackground, MatrixTheme } from './MatrixBackground';

interface HomepageProps {
  onEnterPortal: () => void;
}

export const Homepage: React.FC<HomepageProps> = ({ onEnterPortal }) => {
  const [isOpening, setIsOpening] = useState(false);
  const [matrixTheme, setMatrixTheme] = useState<MatrixTheme>('emerald');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Play sci-fi audio beep if audio context is available
  const triggerCyberBeep = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(220, audioCtx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      // Audio fallback silent
    }
  };

  const handleDoorClick = () => {
    if (isOpening) return;
    triggerCyberBeep();
    setIsOpening(true);
    setTimeout(() => {
      onEnterPortal();
    }, 1100);
  };

  return (
    <div
      id="homepage-container"
      onClick={handleDoorClick}
      className="relative w-full h-screen bg-slate-50 overflow-hidden flex flex-col items-center justify-center font-mono text-slate-900 select-none cursor-pointer"
    >
      
      {/* Dynamic Matrix Canvas Background */}
      <MatrixBackground theme={matrixTheme} speed={1.2} opacity={0.5} />

      {/* Double Cyber Vault Door Overlay */}
      <div className="absolute inset-0 flex z-20 pointer-events-none">
        {/* Left Vault Door */}
        <div
          className={`w-1/2 h-full bg-white/95 border-r-2 border-orange-400/50 shadow-xl flex items-center justify-end pr-8 transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? '-translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-right space-y-2 opacity-80">
            <div className="text-xs font-mono text-orange-600 tracking-widest uppercase flex items-center justify-end space-x-1">
              <Cpu className="w-3.5 h-3.5 mr-1 text-orange-600 animate-pulse" />
              <span>ICICI PORTAL GATE // 01</span>
            </div>
            <div className="w-24 h-1 bg-orange-500 rounded-full ml-auto shadow-sm" />
            <div className="text-[10px] text-slate-400">SECURE HEALTH CLAIMS ENGINE</div>
          </div>
        </div>

        {/* Right Vault Door */}
        <div
          className={`w-1/2 h-full bg-white/95 border-l-2 border-orange-400/50 shadow-xl flex items-center justify-start pl-8 transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? 'translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-left space-y-2 opacity-80">
            <div className="text-xs font-mono text-orange-600 tracking-widest uppercase flex items-center space-x-1">
              <span>QUANTUM ANALYTICS</span>
              <Terminal className="w-3.5 h-3.5 ml-1 text-orange-600 animate-pulse" />
            </div>
            <div className="w-24 h-1 bg-orange-500 rounded-full shadow-sm" />
            <div className="text-[10px] text-slate-400">STATUS: READY_FOR_SESSION</div>
          </div>
        </div>
      </div>

      {/* Theme Accent Controls (Top Left) */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute top-4 left-4 z-30 flex items-center space-x-2 bg-white border border-slate-200 p-2 rounded-xl text-[11px] shadow-sm cursor-default"
      >
        <span className="text-slate-700 font-bold flex items-center">
          <Radio className="w-3.5 h-3.5 mr-1 text-orange-600 animate-pulse" /> ACCENT:
        </span>
        <button
          onClick={() => setMatrixTheme('amber')}
          className={`w-5 h-5 rounded-full border border-orange-500 ${matrixTheme === 'amber' ? 'ring-2 ring-orange-500 bg-orange-600' : 'bg-orange-100'}`}
          title="ICICI Orange"
        />
        <button
          onClick={() => setMatrixTheme('emerald')}
          className={`w-5 h-5 rounded-full border border-emerald-500 ${matrixTheme === 'emerald' ? 'ring-2 ring-emerald-500 bg-emerald-600' : 'bg-emerald-100'}`}
          title="Emerald Green"
        />
        <button
          onClick={() => setMatrixTheme('cyan')}
          className={`w-5 h-5 rounded-full border border-sky-500 ${matrixTheme === 'cyan' ? 'ring-2 ring-sky-500 bg-sky-600' : 'bg-sky-100'}`}
          title="Cyber Blue"
        />
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`ml-2 px-2 py-0.5 rounded text-[10px] font-bold border ${soundEnabled ? 'border-orange-500 text-orange-700 bg-orange-50' : 'border-slate-300 text-slate-500'}`}
        >
          {soundEnabled ? '🔊 AUDIO ON' : '🔇 AUDIO OFF'}
        </button>
      </div>

      {/* Main Content Card Container */}
      <div className="relative z-10 flex flex-col items-center max-w-xl mx-auto text-center px-4">
        
        {/* Emblem */}
        <div className="mb-6 p-4 bg-white rounded-2xl border border-slate-200 shadow-xl relative group">
          <div className="relative w-20 h-20 bg-orange-500 rounded-xl flex items-center justify-center border border-orange-400 shadow-md">
            <Bot className="w-12 h-12 text-white animate-robot-eye drop-shadow-md" />
            <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white animate-ping" />
          </div>
        </div>

        {/* Subtitle Tag */}
        <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-orange-50 border border-orange-200 text-orange-800 text-xs font-mono mb-4 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-orange-600 animate-spin" />
          <span className="tracking-wider font-bold">ICICI LOMBARD // HEALTH CLAIMS MATRIX v4.0</span>
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-wider text-slate-900 mb-2 font-mono">
          IL QUANTUM
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 font-mono tracking-widest uppercase mb-8 font-bold">
          AI-POWERED HEALTH CLAIMS ANALYTICS PORTAL
        </p>

        {/* Clickable Entry Button */}
        <button
          id="enter-portal-btn"
          onClick={handleDoorClick}
          disabled={isOpening}
          className={`group relative inline-flex items-center justify-center px-10 py-5 text-base font-bold text-white bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 active:scale-95 cursor-pointer overflow-hidden border border-orange-400 ${
            !isOpening ? 'animate-breathe' : ''
          }`}
        >
          {/* Top-Right Live Status Indicator Pill */}
          <div
            className={`absolute top-1.5 right-2.5 flex items-center space-x-1.5 text-[9px] font-mono font-bold bg-white/90 backdrop-blur-md px-2 py-0.5 rounded-full border transition-all duration-300 pointer-events-none ${
              isOpening
                ? 'border-amber-400 text-amber-700'
                : 'border-emerald-500 text-emerald-700'
            }`}
          >
            {isOpening ? (
              <>
                <Lock className="w-2.5 h-2.5 text-amber-600 animate-pulse-then-stop shrink-0" />
                <span className="uppercase tracking-wider">DECRYPTING...</span>
              </>
            ) : (
              <>
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                <span className="uppercase tracking-wider">ONLINE</span>
                <span className="text-slate-400">•</span>
                <span className="text-orange-600">0.4ms</span>
              </>
            )}
          </div>

          <span className="relative flex items-center space-x-3 text-white font-black uppercase tracking-widest text-sm sm:text-base">
            <Cpu className="w-5 h-5 text-white animate-pulse" />
            <span>ENTER MATRIX PORTAL</span>
            <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
          </span>
        </button>

        {/* Footer */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 font-mono">
          <div className="flex items-center space-x-1.5 bg-white px-3 py-1 rounded-lg border border-slate-200 shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="text-slate-700 font-bold">QUANTUM ENCRYPTED</span>
          </div>
          <span className="text-slate-300">•</span>
          <div className="bg-white px-3 py-1 rounded-lg border border-slate-200 text-slate-700 font-bold shadow-2xs">
            SYS_NODE: HEALTH-08
          </div>
          <span className="text-slate-300">•</span>
          <div className="text-slate-500 font-bold">v2026.WHITE.IL</div>
        </div>

      </div>
    </div>
  );
};

