import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Terminal,
  X,
  Search,
  Trash2,
  Download,
  Copy,
  Check,
  Filter,
  AlertTriangle,
  Info,
  CheckCircle2,
  XCircle,
  Clock,
  Globe,
  Tag,
  ChevronRight,
  ChevronDown,
  Play,
  ArrowUpDown,
  Code2,
  Server,
  Layers,
  Sparkles,
} from 'lucide-react';
import { RealTimeLog } from '../types';

interface SystemLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: RealTimeLog[];
  onClearLogs: () => void;
  onAddLog?: (log: RealTimeLog) => void;
}

export const SystemLogsModal: React.FC<SystemLogsModalProps> = ({
  isOpen,
  onClose,
  logs,
  onClearLogs,
  onAddLog,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [copiedLogId, setCopiedLogId] = useState<string | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new logs arrive if autoScroll is enabled
  useEffect(() => {
    if (autoScroll && isOpen && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs.length, autoScroll, isOpen]);

  // Escape key to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Derived filter calculations
  const filteredLogs = useMemo(() => {
    let result = [...logs];

    // Filter by Search Query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (log) =>
          log.title.toLowerCase().includes(query) ||
          log.detail.toLowerCase().includes(query) ||
          log.id.toLowerCase().includes(query) ||
          (log.value && log.value.toLowerCase().includes(query)) ||
          (log.region && log.region.toLowerCase().includes(query)) ||
          log.type.toLowerCase().includes(query)
      );
    }

    // Filter by Status
    if (selectedStatus !== 'all') {
      result = result.filter((log) => log.status === selectedStatus);
    }

    // Filter by Event Type
    if (selectedType !== 'all') {
      result = result.filter((log) => log.type === selectedType);
    }

    // Filter by Region
    if (selectedRegion !== 'all') {
      result = result.filter((log) => log.region === selectedRegion);
    }

    // Sorting
    if (sortOrder === 'oldest') {
      result.reverse();
    }

    return result;
  }, [logs, searchQuery, selectedStatus, selectedType, selectedRegion, sortOrder]);

  // Summary Counters
  const counts = useMemo(() => {
    return {
      total: logs.length,
      success: logs.filter((l) => l.status === 'success').length,
      info: logs.filter((l) => l.status === 'info').length,
      warning: logs.filter((l) => l.status === 'warning').length,
      error: logs.filter((l) => l.status === 'error').length,
    };
  }, [logs]);

  if (!isOpen) return null;

  // Handle Export to JSON file
  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(filteredLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `system_logs_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Handle Export to CSV file
  const handleExportCsv = () => {
    const headers = ['ID', 'Timestamp', 'Type', 'Status', 'Title', 'Detail', 'Value', 'Region'];
    const csvRows = [
      headers.join(','),
      ...filteredLogs.map((log) =>
        [
          `"${log.id}"`,
          `"${log.timestamp}"`,
          `"${log.type}"`,
          `"${log.status}"`,
          `"${log.title.replace(/"/g, '""')}"`,
          `"${log.detail.replace(/"/g, '""')}"`,
          `"${log.value || ''}"`,
          `"${log.region || ''}"`,
        ].join(',')
      ),
    ];

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `system_logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Copy All JSON
  const handleCopyAll = () => {
    navigator.clipboard.writeText(JSON.stringify(filteredLogs, null, 2));
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  // Handle Copy single log
  const handleCopyLog = (log: RealTimeLog, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(JSON.stringify(log, null, 2));
    setCopiedLogId(log.id);
    setTimeout(() => setCopiedLogId(null), 2000);
  };

  // Inject a quick test dev event log
  const handleInjectTestLog = () => {
    if (!onAddLog) return;
    const testTypes: RealTimeLog['type'][] = ['system', 'deployment', 'alert', 'sale', 'signup'];
    const testStatuses: RealTimeLog['status'][] = ['info', 'success', 'warning', 'error'];
    const regions = ['AMER', 'EMEA', 'APAC', 'LATAM'];
    
    const randomType = testTypes[Math.floor(Math.random() * testTypes.length)];
    const randomStatus = testStatuses[Math.floor(Math.random() * testStatuses.length)];
    const randomRegion = regions[Math.floor(Math.random() * regions.length)];
    
    const newLog: RealTimeLog = {
      id: `log-dev-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      type: randomType,
      status: randomStatus,
      title: `Developer Simulation Event [${randomType.toUpperCase()}]`,
      detail: `Diagnostic trace emitted at ${new Date().toISOString()} for regional cluster ${randomRegion}`,
      value: randomType === 'sale' ? '+$12,500' : 'Lat: 24ms',
      region: randomRegion,
    };

    onAddLog(newLog);
  };

  const getStatusIcon = (status: RealTimeLog['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'info':
        return <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case 'error':
        return <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      default:
        return <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />;
    }
  };

  const getStatusBadge = (status: RealTimeLog['status']) => {
    switch (status) {
      case 'success':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30';
      case 'info':
        return 'bg-sky-950/80 text-sky-300 border-sky-500/30';
      case 'warning':
        return 'bg-amber-950/80 text-amber-300 border-amber-500/30';
      case 'error':
        return 'bg-rose-950/80 text-rose-300 border-rose-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  const getTypeColor = (type: RealTimeLog['type']) => {
    switch (type) {
      case 'sale':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'signup':
        return 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20';
      case 'deployment':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/20';
      case 'alert':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'system':
      default:
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-6xl h-[92vh] max-h-[900px] shadow-2xl flex flex-col overflow-hidden text-slate-100 font-sans">
        
        {/* Top Developer Terminal Header Bar */}
        <div className="bg-slate-950 border-b border-slate-800 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-cyan-600 to-blue-700 rounded-xl text-white shadow-lg shadow-cyan-900/30">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <span>System Events & Developer Log History</span>
                  <span className="px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-[10px] font-mono font-semibold uppercase">
                    PROD DIAGNOSTICS
                  </span>
                </h2>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Full-stack audit trail, API telemetry & real-time execution logs
              </p>
            </div>
          </div>

          {/* Action Tools Header Controls */}
          <div className="flex items-center space-x-2">
            {onAddLog && (
              <button
                onClick={handleInjectTestLog}
                className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 hover:border-cyan-400 text-xs font-semibold rounded-lg transition-all flex items-center space-x-1.5 cursor-pointer active:scale-95"
                title="Inject a test developer event log into real-time history"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">+ Inject Event</span>
              </button>
            )}

            <button
              onClick={handleCopyAll}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-lg transition-colors flex items-center space-x-1.5 cursor-pointer active:scale-95"
              title="Copy filtered logs as JSON"
            >
              {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copiedAll ? 'Copied!' : 'Copy JSON'}</span>
            </button>

            <div className="flex items-center space-x-1 border-l border-slate-800 pl-2">
              <button
                onClick={handleExportJson}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-medium rounded-lg transition-colors flex items-center space-x-1 cursor-pointer"
                title="Export filtered logs as JSON"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span className="text-[11px] hidden md:inline">JSON</span>
              </button>
              <button
                onClick={handleExportCsv}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-medium rounded-lg transition-colors flex items-center space-x-1 cursor-pointer"
                title="Export filtered logs as CSV"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="text-[11px] hidden md:inline">CSV</span>
              </button>
            </div>

            <button
              onClick={onClearLogs}
              className="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/50 text-xs font-medium rounded-lg transition-colors flex items-center space-x-1 cursor-pointer ml-1"
              title="Clear all log history"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Clear</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Summary Bar */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex flex-wrap items-center gap-2 sm:gap-4 font-mono">
            <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-slate-950 rounded-lg border border-slate-800">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-slate-400">Total:</span>
              <strong className="text-white">{counts.total}</strong>
            </div>

            <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-emerald-950/40 rounded-lg border border-emerald-800/40">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300">Success:</span>
              <strong className="text-emerald-200">{counts.success}</strong>
            </div>

            <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-sky-950/40 rounded-lg border border-sky-800/40">
              <Info className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-sky-300">Info:</span>
              <strong className="text-sky-200">{counts.info}</strong>
            </div>

            <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-amber-950/40 rounded-lg border border-amber-800/40">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-amber-300">Warnings:</span>
              <strong className="text-amber-200">{counts.warning}</strong>
            </div>

            <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-rose-950/40 rounded-lg border border-rose-800/40">
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              <span className="text-rose-300">Errors:</span>
              <strong className="text-rose-200">{counts.error}</strong>
            </div>
          </div>

          <div className="flex items-center space-x-3 text-slate-400 font-mono text-[11px]">
            <label className="flex items-center space-x-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={autoScroll}
                onChange={(e) => setAutoScroll(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
              />
              <span>Live Auto-scroll</span>
              {autoScroll && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
            </label>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="bg-slate-950/60 border-b border-slate-800 px-5 py-3 flex flex-wrap items-center gap-3 shrink-0">
          
          {/* Keyword Search Input */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by keyword, title, ID, detail, or value..."
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-8 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Select */}
          <div className="flex items-center space-x-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Statuses</option>
              <option value="success">Success</option>
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
            </select>
          </div>

          {/* Event Type Select */}
          <div className="flex items-center space-x-1.5 text-xs">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Types</option>
              <option value="system">System</option>
              <option value="deployment">Deployment</option>
              <option value="sale">Sale</option>
              <option value="signup">Signup</option>
              <option value="alert">Alert</option>
            </select>
          </div>

          {/* Region Select */}
          <div className="flex items-center space-x-1.5 text-xs">
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Regions</option>
              <option value="AMER">AMER</option>
              <option value="EMEA">EMEA</option>
              <option value="APAC">APAC</option>
              <option value="LATAM">LATAM</option>
            </select>
          </div>

          {/* Sort Order Toggle */}
          <button
            onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
            className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-lg text-xs font-mono flex items-center space-x-1 transition-colors cursor-pointer"
            title="Toggle Sort Order"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
            <span className="capitalize">{sortOrder}</span>
          </button>
        </div>

        {/* Scrollable Logs History Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 font-mono text-xs custom-scrollbar bg-slate-950">
          {filteredLogs.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-8 border border-dashed border-slate-800 rounded-xl my-4">
              <Terminal className="w-10 h-10 text-slate-600 mb-3" />
              <h3 className="text-sm font-bold text-slate-300">No Matching System Events</h3>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                No logs match your current search query or filter selection. Try adjusting your filters or trigger a new event.
              </p>
              {(searchQuery || selectedStatus !== 'all' || selectedType !== 'all' || selectedRegion !== 'all') && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedStatus('all');
                    setSelectedType('all');
                    setSelectedRegion('all');
                  }}
                  className="mt-4 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-sans transition-colors cursor-pointer"
                >
                  Reset Active Filters
                </button>
              )}
            </div>
          ) : (
            filteredLogs.map((log) => {
              const isExpanded = expandedLogId === log.id;
              return (
                <div
                  key={log.id}
                  onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                  className={`border rounded-xl p-3 sm:p-3.5 transition-all cursor-pointer group ${
                    isExpanded
                      ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-950/30'
                      : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/90 hover:border-slate-700'
                  }`}
                >
                  {/* Primary Row Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <button className="text-slate-500 group-hover:text-slate-300 transition-colors">
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-cyan-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>

                      {getStatusIcon(log.status)}

                      {/* Status Tag */}
                      <span
                        className={`px-2 py-0.5 rounded border text-[10px] uppercase font-bold tracking-wider ${getStatusBadge(
                          log.status
                        )}`}
                      >
                        {log.status}
                      </span>

                      {/* Type Tag */}
                      <span
                        className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase ${getTypeColor(
                          log.type
                        )}`}
                      >
                        {log.type}
                      </span>

                      {/* Log Title */}
                      <span className="font-bold text-slate-100 truncate group-hover:text-cyan-200 transition-colors">
                        {log.title}
                      </span>
                    </div>

                    {/* Meta info right side */}
                    <div className="flex items-center space-x-2.5 text-[11px] text-slate-400 shrink-0">
                      {log.region && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
                          <Globe className="w-3 h-3 text-cyan-400" />
                          {log.region}
                        </span>
                      )}

                      {log.value && (
                        <span className="font-bold text-amber-300 bg-amber-950/40 border border-amber-800/40 px-1.5 py-0.5 rounded">
                          {log.value}
                        </span>
                      )}

                      <span className="flex items-center space-x-1 text-slate-500 font-mono">
                        <Clock className="w-3 h-3" />
                        <span>{log.timestamp}</span>
                      </span>

                      <button
                        onClick={(e) => handleCopyLog(log, e)}
                        className="p-1 text-slate-500 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                        title="Copy log payload"
                      >
                        {copiedLogId === log.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Detail preview string */}
                  <div className="mt-2 text-slate-300 text-xs pl-6 sm:pl-7 leading-relaxed font-sans">
                    {log.detail}
                  </div>

                  {/* Expanded Developer Inspector Section */}
                  {isExpanded && (
                    <div
                      className="mt-3 pt-3 border-t border-slate-800 pl-6 sm:pl-7 space-y-2 animate-in fade-in duration-150"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="font-bold text-cyan-400 flex items-center gap-1.5">
                          <Code2 className="w-3.5 h-3.5" />
                          RAW EVENT OBJECT PAYLOAD (JSON)
                        </span>
                        <span className="text-slate-500">ID: {log.id}</span>
                      </div>

                      <pre className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-emerald-400 font-mono text-[11px] overflow-x-auto selection:bg-cyan-900">
                        {JSON.stringify(log, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })
          )}
          <div ref={logsEndRef} />
        </div>

        {/* Footer Info Strip */}
        <div className="bg-slate-950 border-t border-slate-800 px-5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 shrink-0 font-mono">
          <div className="flex items-center space-x-3">
            <span className="flex items-center text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-pulse" />
              Showing <strong className="text-white mx-1">{filteredLogs.length}</strong> of{' '}
              <strong className="text-slate-300 ml-1">{logs.length}</strong> system entries
            </span>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <span className="text-slate-500">Press <kbd className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded border border-slate-700">ESC</kbd> to exit</span>
            <button
              onClick={onClose}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-sans font-semibold transition-colors cursor-pointer"
            >
              Close History
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
