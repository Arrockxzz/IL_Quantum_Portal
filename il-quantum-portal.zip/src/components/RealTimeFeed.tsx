import React, { useState } from 'react';
import { RealTimeLog } from '../types';
import { Radio, DollarSign, UserPlus, Server, AlertTriangle, ShieldCheck, Filter, Trash2 } from 'lucide-react';

interface RealTimeFeedProps {
  logs: RealTimeLog[];
  onClearLogs: () => void;
}

export const RealTimeFeed: React.FC<RealTimeFeedProps> = ({ logs, onClearLogs }) => {
  const [filterType, setFilterType] = useState<string>('all');

  const getLogIcon = (type: RealTimeLog['type']) => {
    switch (type) {
      case 'sale':
        return <DollarSign className="w-4 h-4 text-emerald-600" />;
      case 'signup':
        return <UserPlus className="w-4 h-4 text-indigo-600" />;
      case 'alert':
        return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      case 'deployment':
        return <Server className="w-4 h-4 text-purple-600" />;
      default:
        return <ShieldCheck className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusBadge = (status: RealTimeLog['status']) => {
    switch (status) {
      case 'success':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'warning':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'error':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const filteredLogs = logs.filter((log) => filterType === 'all' || log.type === filterType);

  return (
    <section id="realtime-activity-feed" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-800 tracking-tight flex items-center">
              Real-Time Event Stream
              <span className="ml-2 px-2 py-0.5 text-[10px] font-mono font-semibold rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                {logs.length} events
              </span>
            </h2>
            <p className="text-xs text-slate-500">Live incoming transaction logs, telemetry, and system alerts</p>
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="flex items-center space-x-2">
          {/* Category Filter */}
          <div className="flex items-center bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-1" />
            <select
              id="log-type-filter"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-transparent text-slate-700 font-medium focus:outline-none pr-1"
            >
              <option value="all">All Events</option>
              <option value="sale">Sales & Upgrades</option>
              <option value="signup">User Signups</option>
              <option value="alert">System Alerts</option>
              <option value="deployment">Deployments</option>
            </select>
          </div>

          <button
            id="clear-logs-btn"
            onClick={onClearLogs}
            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
            title="Clear Log Stream"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Logs List Container */}
      <div className="mt-4 space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
        {filteredLogs.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">
            No events logged yet for this category. New events arrive automatically as data ticks!
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-slate-50/80 hover:bg-slate-100/90 border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-white border border-slate-200 rounded-lg shrink-0 mt-0.5 shadow-xs">
                  {getLogIcon(log.type)}
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xs font-bold text-slate-900">{log.title}</h3>
                    {log.region && (
                      <span className="text-[10px] font-semibold text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        {log.region}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">{log.detail}</p>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end space-x-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                {log.value && (
                  <span className="text-xs font-mono font-bold text-emerald-600">
                    {log.value}
                  </span>
                )}

                <span className={`px-2 py-0.5 text-[11px] font-semibold rounded-md border ${getStatusBadge(log.status)}`}>
                  {log.timestamp}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

    </section>
  );
};
