import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock, Sparkles, Building2 } from 'lucide-react';

interface HomepageProps {
  onEnterPortal: () => void;
}

export const Homepage: React.FC<HomepageProps> = ({ onEnterPortal }) => {
  const [isOpening, setIsOpening] = useState(false);

  const handleDoorClick = () => {
    if (isOpening) return;
    setIsOpening(true);
    setTimeout(() => {
      onEnterPortal();
    }, 1100);
  };

  return (
    <div id="homepage-container" className="relative w-full h-screen bg-slate-950 overflow-hidden flex flex-col items-center justify-center font-sans text-white select-none">
      
      {/* Background Animated Particles Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-orange-950/30 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#f97316_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      {/* Double Door Visual Overlay */}
      <div className="absolute inset-0 flex z-20 pointer-events-none">
        {/* Left Door */}
        <div
          className={`w-1/2 h-full bg-slate-900 border-r border-orange-500/30 shadow-2xl flex items-center justify-end pr-8 transition-transform duration-1000 ease-in-out ${
            isOpening ? '-translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-right space-y-2 opacity-40">
            <div className="text-xs font-mono text-orange-400 tracking-widest uppercase">ICICI LOMBARD</div>
            <div className="w-16 h-1 bg-orange-500/50 rounded-full ml-auto" />
          </div>
        </div>

        {/* Right Door */}
        <div
          className={`w-1/2 h-full bg-slate-900 border-l border-orange-500/30 shadow-2xl flex items-center justify-start pl-8 transition-transform duration-1000 ease-in-out ${
            isOpening ? 'translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-left space-y-2 opacity-40">
            <div className="text-xs font-mono text-orange-400 tracking-widest uppercase">IL QUANTUM PORTAL</div>
            <div className="w-16 h-1 bg-orange-500/50 rounded-full" />
          </div>
        </div>
      </div>

      {/* Main Content Card Container */}
      <div className="relative z-10 flex flex-col items-center max-w-lg mx-auto text-center px-4">
        
        {/* Company / Brand Emblem */}
        <div className="mb-6 p-3 bg-gradient-to-b from-orange-500/20 to-orange-600/5 rounded-2xl border border-orange-500/30 shadow-lg shadow-orange-500/10 backdrop-blur-md">
          <div className="w-16 h-16 bg-gradient-to-tr from-orange-600 to-rose-600 rounded-xl flex items-center justify-center shadow-inner">
            <Building2 className="w-9 h-9 text-white" />
          </div>
        </div>

        {/* Brand Subtitle Tag */}
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-mono mb-4">
          <Sparkles className="w-3.5 h-3.5" />
          <span>ICICI LOMBARD ENTERPRISE DATA PORTAL</span>
        </div>

        {/* Brand Title */}
        <h1 className="text-4xl sm:text-5xl font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-orange-200 bg-clip-text text-transparent mb-8 font-sans">
          IL QUANTUM
        </h1>

        {/* Clickable Entry Door Button */}
        <button
          id="enter-portal-btn"
          onClick={handleDoorClick}
          disabled={isOpening}
          className={`group relative inline-flex items-center justify-center px-8 pt-6 pb-4 text-base font-bold text-white bg-gradient-to-r from-orange-600 via-red-600 to-rose-600 rounded-2xl shadow-xl hover:shadow-orange-500/25 transition-all duration-300 active:scale-95 cursor-pointer overflow-hidden border border-orange-400/30 ${
            !isOpening ? 'animate-breathe' : ''
          }`}
        >
          {/* Top-Right Live Status Indicator Pill */}
          <div
            className={`absolute top-1.5 right-2.5 flex items-center space-x-1.5 text-[9px] font-mono font-semibold bg-black/40 backdrop-blur-xs px-2 py-0.5 rounded-full border transition-all duration-300 pointer-events-none ${
              isOpening
                ? 'border-amber-400/60 bg-amber-950/80 text-amber-300 shadow-md'
                : 'border-white/20 text-emerald-300'
            }`}
          >
            {isOpening ? (
              <>
                <Lock className="w-2.5 h-2.5 text-amber-300 animate-pulse-then-stop shrink-0" />
                <span className="uppercase tracking-wider text-amber-300">LOCKED & VERIFYING</span>
              </>
            ) : (
              <>
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                <span className="uppercase tracking-wider">Online</span>
                <span className="text-white/40">•</span>
                <span className="text-amber-300">12ms</span>
              </>
            )}
          </div>

          {/* Glowing Shimmer */}
          <span className="absolute top-0 right-0 w-8 h-full bg-white/20 transform skew-x-12 -translate-x-32 group-hover:translate-x-48 transition-transform duration-1000 ease-out" />
          
          <span className="relative flex items-center space-x-3">
            <span>ENTER PORTAL</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </span>
        </button>

        {/* Security & System Info Footer */}
        <div className="mt-12 flex items-center space-x-6 text-xs text-slate-500 font-mono">
          <div className="flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>256-Bit Encrypted</span>
          </div>
          <span>•</span>
          <div>v2026.1.0-IL</div>
        </div>

      </div>
    </div>
  );
};
