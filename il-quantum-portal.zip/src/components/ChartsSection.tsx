import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { DepartmentData, RegionalMetric, TimeSeriesPoint } from '../types';
import { TrendingUp, BarChart3, Globe, Cpu, Layers } from 'lucide-react';

interface ChartsSectionProps {
  timeSeries: TimeSeriesPoint[];
  departments: DepartmentData[];
  regions: RegionalMetric[];
  timeRange: '24h' | '7d' | '30d' | 'YTD';
  setTimeRange: (tr: '24h' | '7d' | '30d' | 'YTD') => void;
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({
  timeSeries,
  departments,
  regions,
  timeRange,
  setTimeRange,
}) => {
  const [activeTab, setActiveTab] = useState<'revenue' | 'departments' | 'regions' | 'system'>('revenue');

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}k`;
    return `$${val}`;
  };

  return (
    <section id="charts-main-section" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            id="chart-tab-revenue"
            onClick={() => setActiveTab('revenue')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all ${
              activeTab === 'revenue'
                ? 'bg-indigo-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <TrendingUp className="w-4 h-4 mr-1.5" />
            Revenue Growth
          </button>

          <button
            id="chart-tab-departments"
            onClick={() => setActiveTab('departments')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all ${
              activeTab === 'departments'
                ? 'bg-indigo-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <BarChart3 className="w-4 h-4 mr-1.5" />
            Department Targets
          </button>

          <button
            id="chart-tab-regions"
            onClick={() => setActiveTab('regions')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all ${
              activeTab === 'regions'
                ? 'bg-indigo-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Globe className="w-4 h-4 mr-1.5" />
            Global Markets
          </button>

          <button
            id="chart-tab-system"
            onClick={() => setActiveTab('system')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all ${
              activeTab === 'system'
                ? 'bg-indigo-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Cpu className="w-4 h-4 mr-1.5" />
            Real-Time Health
          </button>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-medium border border-slate-200">
          {(['24h', '7d', '30d', 'YTD'] as const).map((tr) => (
            <button
              key={tr}
              id={`time-range-${tr}`}
              onClick={() => setTimeRange(tr)}
              className={`px-3 py-1.5 rounded-md transition-all ${
                timeRange === tr
                  ? 'bg-white text-indigo-600 font-bold shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tr}
            </button>
          ))}
        </div>

      </div>

      {/* Chart Body Container */}
      <div className="mt-5 h-[340px] w-full relative">
        
        {/* Tab 1: Revenue Stream */}
        {activeTab === 'revenue' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timeSeries} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorCloud" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorAi" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorSaas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} />
              <YAxis
                stroke="#64748b"
                fontSize={12}
                tickFormatter={formatCurrency}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '1rem',
                  color: '#0f172a',
                  fontSize: '12px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#475569' }} />
              <Area
                type="monotone"
                dataKey="cloudRevenue"
                name="Cloud Infra"
                stroke="#4f46e5"
                fillOpacity={1}
                fill="url(#colorCloud)"
                strokeWidth={2.5}
              />
              <Area
                type="monotone"
                dataKey="aiRevenue"
                name="AI & Data"
                stroke="#8b5cf6"
                fillOpacity={1}
                fill="url(#colorAi)"
                strokeWidth={2.5}
              />
              <Area
                type="monotone"
                dataKey="saasRevenue"
                name="SaaS Suite"
                stroke="#10b981"
                fillOpacity={1}
                fill="url(#colorSaas)"
                strokeWidth={2.5}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {/* Tab 2: Department Breakdown */}
        {activeTab === 'departments' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={departments} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis
                stroke="#64748b"
                fontSize={12}
                tickFormatter={formatCurrency}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '1rem',
                  color: '#0f172a',
                  fontSize: '12px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Value']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#475569' }} />
              <Bar dataKey="revenue" name="Actual Revenue ($)" fill="#4f46e5" radius={[6, 6, 0, 0]} />
              <Bar dataKey="target" name="Target ($)" fill="#cbd5e1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}

        {/* Tab 3: Regional Markets */}
        {activeTab === 'regions' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              layout="vertical"
              data={regions}
              margin={{ top: 10, right: 20, left: 20, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis type="number" stroke="#64748b" fontSize={12} tickFormatter={formatCurrency} />
              <YAxis
                dataKey="code"
                type="category"
                stroke="#64748b"
                fontSize={12}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '1rem',
                  color: '#0f172a',
                  fontSize: '12px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
              />
              <Bar dataKey="revenue" name="Regional Revenue" fill="#6366f1" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}

        {/* Tab 4: System Health & Throughput */}
        {activeTab === 'system' && (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timeSeries} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} />
              <YAxis
                yAxisId="left"
                stroke="#4f46e5"
                fontSize={12}
                unit=" ms"
                tickLine={false}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#10b981"
                fontSize={12}
                unit=" req/s"
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '1rem',
                  color: '#0f172a',
                  fontSize: '12px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#475569' }} />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="latencyMs"
                name="Avg Latency (ms)"
                stroke="#4f46e5"
                strokeWidth={3}
                dot={{ r: 4, fill: '#4f46e5' }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="requestsPerSec"
                name="Throughput (Req/Sec)"
                stroke="#10b981"
                strokeWidth={2.5}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        )}

      </div>

    </section>
  );
};
