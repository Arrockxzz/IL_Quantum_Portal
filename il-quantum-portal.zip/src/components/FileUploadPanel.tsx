import React from 'react';
import { UploadedFileMeta } from '../types';
import { FileSpreadsheet, CheckCircle2, AlertCircle, Clock, X, RefreshCw } from 'lucide-react';

interface FileUploadPanelProps {
  files: UploadedFileMeta[];
  isOpen: boolean;
  onClose: () => void;
  onRemoveFile: (fileId: string) => void;
  onOpenFilePicker: () => void;
}

export const FileUploadPanel: React.FC<FileUploadPanelProps> = ({
  files,
  isOpen,
  onClose,
  onRemoveFile,
  onOpenFilePicker,
}) => {
  if (!isOpen) return null;

  return (
    <div id="file-upload-panel" className="bg-slate-900 border-b border-slate-800 text-white p-4 shadow-xl z-30 transition-all">
      <div className="max-w-7xl mx-auto space-y-3">
        
        {/* Panel Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Parsed Claim Datasets</h3>
            <span className="bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded-full font-mono">
              {files.length} file{files.length !== 1 ? 's' : ''}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenFilePicker}
              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              + Upload File
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* File Queue List */}
        {files.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            No files uploaded yet. Click "Upload File" or the Excel icon in the header to import CSV/XLSX claim files.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-56 overflow-y-auto pr-1">
            {files.map((file) => (
              <div
                key={file.id}
                className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 flex flex-col justify-between space-y-2 text-xs"
              >
                <div className="flex items-start justify-between">
                  <div className="truncate pr-2">
                    <div className="font-bold text-slate-200 truncate" title={file.name}>
                      {file.name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {file.rawSize} • {file.rowCount.toLocaleString()} rows
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveFile(file.id)}
                    className="text-slate-500 hover:text-rose-400 p-0.5 rounded hover:bg-slate-700"
                    title="Remove Dataset"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Status Badge & Progress */}
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1 font-semibold">
                    <span className="flex items-center">
                      {file.status === 'Uploaded' && <CheckCircle2 className="w-3 h-3 text-emerald-400 mr-1" />}
                      {file.status === 'Processing' && <RefreshCw className="w-3 h-3 text-amber-400 animate-spin mr-1" />}
                      {file.status === 'Queued' && <Clock className="w-3 h-3 text-blue-400 mr-1" />}
                      {file.status === 'Error' && <AlertCircle className="w-3 h-3 text-rose-400 mr-1" />}
                      <span
                        className={
                          file.status === 'Uploaded'
                            ? 'text-emerald-400'
                            : file.status === 'Processing'
                            ? 'text-amber-400'
                            : file.status === 'Error'
                            ? 'text-rose-400'
                            : 'text-blue-400'
                        }
                      >
                        {file.status}
                      </span>
                    </span>
                    <span className="text-slate-400 font-mono">{file.progress}%</span>
                  </div>

                  <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        file.status === 'Uploaded'
                          ? 'bg-emerald-500'
                          : file.status === 'Error'
                          ? 'bg-rose-500'
                          : 'bg-amber-500'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
