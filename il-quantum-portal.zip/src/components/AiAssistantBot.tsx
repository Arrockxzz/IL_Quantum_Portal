import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, X, Minimize2, Maximize2, RefreshCw, Copy, Check, MessageSquare, ChevronUp } from 'lucide-react';
import { ChatMessage, MetricKpis, DepartmentData, RegionalMetric } from '../types';

interface AiAssistantBotProps {
  kpis: MetricKpis;
  departments: DepartmentData[];
  regions: RegionalMetric[];
  isOpen?: boolean;
  onClose?: () => void;
}

export const AiAssistantBot: React.FC<AiAssistantBotProps> = ({
  kpis,
  departments,
  regions,
  isOpen: externalIsOpen,
  onClose: externalOnClose,
}) => {
  const [internalIsOpen, setInternalIsOpen] = useState<boolean>(false);
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;

  const handleClose = () => {
    if (externalOnClose) {
      externalOnClose();
    } else {
      setInternalIsOpen(false);
    }
  };

  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      content: `👋 Hello! I am **Nova AI**, your real-time company data intelligence companion.\n\nI have live telemetry on your ARR ($${(kpis.arr / 1000000).toFixed(2)}M), system latency (${kpis.latencyMs}ms), and departmental performance. Ask me anything about your metrics!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedActions: [
        'Summarize today\'s performance',
        'Which region has highest growth?',
        'Forecast Q3 ARR',
      ],
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          dashboardState: {
            kpis,
            departments,
            regions,
            timestamp: new Date().toISOString(),
          },
          chatHistory: messages.map((m) => ({ role: m.sender, content: m.content })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        content: data.reply || 'I analyzed the metrics, but could not produce a response.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: data.suggestedActions || ['Analyze latency', 'Department breakdown'],
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('Error fetching AI response:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        content: `⚠️ Unable to reach AI Service. Please ensure your backend is active or check network settings.\n\n*Error details: ${err.message || String(err)}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Render markdown line formatting simply
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      // Headers
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-sm font-bold text-indigo-700 mt-2 mb-1">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={idx} className="text-sm font-extrabold text-slate-900 mt-2.5 mb-1">{line.replace('## ', '')}</h3>;
      }
      // Bullets
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        return (
          <li key={idx} className="ml-4 list-disc text-xs text-slate-700 my-0.5">
            {formatInlineBold(line.trim().substring(2))}
          </li>
        );
      }
      if (line.trim() === '') {
        return <div key={idx} className="h-1.5" />;
      }
      return (
        <p key={idx} className="text-xs text-slate-700 leading-relaxed my-0.5">
          {formatInlineBold(line)}
        </p>
      );
    });
  };

  const formatInlineBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div
      id="ai-bot-panel"
      className={`fixed bottom-4 right-4 z-50 transition-all duration-300 ${
        isMinimized ? 'w-80 h-14' : 'w-full max-w-sm sm:max-w-md h-[580px]'
      } bg-white border border-slate-200 rounded-2xl shadow-2xl flex flex-col backdrop-blur-xl text-slate-900 overflow-hidden animate-in fade-in slide-in-from-bottom-3 duration-200`}
    >
      {/* Bot Panel Header */}
      <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white px-4 py-3 rounded-t-2xl border-b border-indigo-900/40 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-inner">
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                <span>Nova AI</span>
                <span className="text-[10px] font-mono bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-400/30 uppercase">Search</span>
              </h3>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <p className="text-[10px] text-indigo-200 font-mono">Gemini 3.6 Real-Time Search Intelligence</p>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <button
            id="minimize-ai-bot-btn"
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1.5 text-indigo-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            title={isMinimized ? 'Expand Search' : 'Minimize'}
          >
            {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            id="close-ai-bot-btn"
            onClick={handleClose}
            className="p-1.5 text-indigo-200 hover:text-rose-300 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            title="Close Nova AI Search"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expanded Content Area */}
      {!isMinimized && (
        <>
          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/50">
            {messages.map((msg, index) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[88%] p-3 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-2xl rounded-tr-none shadow-xs'
                      : msg.isError
                      ? 'bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl rounded-tl-none'
                      : 'bg-slate-100 border border-slate-200/80 text-slate-800 rounded-2xl rounded-tl-none shadow-xs'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className={`text-[10px] font-semibold tracking-wide uppercase ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-500'}`}>
                      {msg.sender === 'user' ? 'You' : 'Nova AI'}
                    </span>
                    <div className="flex items-center space-x-1">
                      <span className={`text-[9px] ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>{msg.timestamp}</span>
                      {msg.sender === 'ai' && (
                        <button
                          onClick={() => handleCopy(msg.content, index)}
                          className="text-slate-400 hover:text-slate-700 p-0.5"
                          title="Copy message"
                        >
                          {copiedIndex === index ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        </button>
                      )}
                    </div>
                  </div>

                  <div>{renderFormattedContent(msg.content)}</div>
                </div>

                {/* Suggested Follow-up Actions */}
                {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2 max-w-[90%]">
                    {msg.suggestedActions.map((action, aIdx) => (
                      <button
                        key={aIdx}
                        onClick={() => handleSend(action)}
                        className="text-[10px] font-medium bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border border-indigo-100 px-2.5 py-1 rounded-full transition-all shadow-xs hover:scale-[1.02]"
                      >
                        ✨ {action}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isLoading && (
              <div className="flex items-center space-x-2 bg-white border border-slate-200 p-2.5 rounded-2xl w-32 shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
                <span className="text-[11px] font-medium text-slate-600">Analyzing...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-slate-50 border-t border-slate-100 rounded-b-2xl">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center space-x-2"
            >
              <input
                id="ai-bot-input"
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask Nova AI anything..."
                className="flex-1 bg-white border border-slate-200 text-slate-900 placeholder-slate-400 text-xs rounded-full px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-inner"
                disabled={isLoading}
              />
              <button
                id="ai-bot-send-btn"
                type="submit"
                disabled={!input.trim() || isLoading}
                className="w-8 h-8 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-full flex items-center justify-center transition-all font-bold shrink-0 shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </>
      )}
    </div>
  );
};
