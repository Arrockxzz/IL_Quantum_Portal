import React from 'react';
import { ClaimRecord } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import { Activity, Table, BarChart2, DollarSign, ShieldAlert, FileSpreadsheet } from 'lucide-react';

interface ClaimsSummaryGridProps {
  claims: ClaimRecord[];
  isTableView: boolean;
}

export const ClaimsSummaryGrid: React.FC<ClaimsSummaryGridProps> = ({ claims, isTableView }) => {
  const COLORS = ['#ea580c', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#f59e0b', '#06b6d4', '#64748b'];

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Helper to build group metrics for any dimension
  const buildGroupMetrics = (key: keyof ClaimRecord, topN: number = 8) => {
    const map = new Map<string, {
      name: string;
      count: number;
      claimed: number;
      approved: number;
      paid: number;
      disallowed: number;
    }>();

    claims.forEach((c) => {
      const name = String(c[key] || 'Unspecified');
      const existing = map.get(name) || {
        name,
        count: 0,
        claimed: 0,
        approved: 0,
        paid: 0,
        disallowed: 0,
      };

      existing.count += 1;
      existing.claimed += Number(c.claimed_amount || 0);
      existing.approved += Number(c.net_sanct_amt || 0);
      existing.paid += Number(c.payment_amount || 0);
      existing.disallowed += Number(c.disallowed_amount || 0);

      map.set(name, existing);
    });

    const totalApproved = claims.reduce((acc, c) => acc + Number(c.net_sanct_amt || 0), 0) || 1;

    return Array.from(map.values())
      .map((item) => ({
        ...item,
        acs: item.count ? item.approved / item.count : 0, // Average Claim Size
        sharePct: (item.approved / totalApproved) * 100,
      }))
      .sort((a, b) => b.approved - a.approved)
      .slice(0, topN);
  };

  const statusMetrics = buildGroupMetrics('updated_status');
  const ipdOpdMetrics = buildGroupMetrics('ipd_opd');
  const typeMetrics = buildGroupMetrics('type_of_claim');
  const relationMetrics = buildGroupMetrics('relation_group');
  const ageBandMetrics = buildGroupMetrics('age_band');
  const diseaseMetrics = buildGroupMetrics('disease_category', 6);
  const cityMetrics = buildGroupMetrics('hospital_city', 6);
  const hospitalMetrics = buildGroupMetrics('hospital_name', 6);

  // Helper renderer for a standard section card
  const renderCard = (title: string, subtitle: string, data: any[], xKey: string = 'name') => {
    return (
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex flex-col justify-between space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <div>
            <h4 className="text-sm font-bold text-slate-800">{title}</h4>
            <p className="text-[11px] text-slate-500">{subtitle}</p>
          </div>
          <span className="text-[10px] font-mono bg-orange-50 text-orange-700 px-2 py-0.5 rounded-full font-bold">
            {data.length} Groups
          </span>
        </div>

        {/* Content View: Table or Chart */}
        <div className="min-h-[200px] text-xs">
          {isTableView ? (
            <div className="overflow-x-auto max-h-52">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] uppercase text-slate-500 font-bold border-b border-slate-200">
                    <th className="py-1.5 px-2">Category</th>
                    <th className="py-1.5 px-2 text-right">Claims</th>
                    <th className="py-1.5 px-2 text-right">Approved Amt</th>
                    <th className="py-1.5 px-2 text-right">ACS</th>
                    <th className="py-1.5 px-2 text-right">Share %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[11px]">
                  {data.map((row) => (
                    <tr key={row.name} className="hover:bg-slate-50">
                      <td className="py-1.5 px-2 font-medium text-slate-800 truncate max-w-[120px]">{row.name}</td>
                      <td className="py-1.5 px-2 text-right font-mono">{row.count}</td>
                      <td className="py-1.5 px-2 text-right font-mono font-bold text-slate-900">{formatCurrency(row.approved)}</td>
                      <td className="py-1.5 px-2 text-right font-mono text-slate-600">{formatCurrency(row.acs)}</td>
                      <td className="py-1.5 px-2 text-right font-mono text-orange-600 font-bold">{row.sharePct.toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="h-52 w-full pt-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey={xKey} stroke="#64748b" fontSize={10} angle={-15} textAnchor="end" />
                  <YAxis stroke="#64748b" fontSize={10} tickFormatter={(v) => `₹${v >= 100000 ? (v / 100000).toFixed(1) + 'L' : (v / 1000).toFixed(0) + 'k'}`} />
                  <Tooltip formatter={(value: any) => [formatCurrency(Number(value)), 'Approved Amount']} />
                  <Bar dataKey="approved" fill="#ea580c" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div id="claims-summary-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 my-6">
      {renderCard('Claim Status Breakdown', 'Distribution by settled, process, & rejected status', statusMetrics)}
      {renderCard('IPD / OPD Utilization', 'Inpatient vs Outpatient Hospitalization metrics', ipdOpdMetrics)}
      {renderCard('Type of Claim', 'Cashless vs Reimbursement comparison', typeMetrics)}
      {renderCard('Relation Wise Distribution', 'Self, Spouse, Children, and Parents breakdown', relationMetrics)}
      {renderCard('Age Band Segmentation', 'Claim volume & sanction by age bracket', ageBandMetrics)}
      {renderCard('Disease Category Summary', 'Top medical conditions & treatment categories', diseaseMetrics)}
      {renderCard('Top Hospital Cities', 'Metropolitan distribution of hospital claims', cityMetrics)}
      {renderCard('Top Provider Network Hospitals', 'Primary healthcare institutions & claim volumes', hospitalMetrics)}

      {/* Deduction & Disallowance Card */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex flex-col justify-between space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <div>
            <h4 className="text-sm font-bold text-slate-800">Deductions & Disallowance Analysis</h4>
            <p className="text-[11px] text-slate-500">Non-medical charges & co-pay clause impacts</p>
          </div>
          <ShieldAlert className="w-4 h-4 text-rose-500" />
        </div>

        <div className="space-y-2 text-xs py-1">
          <div className="bg-rose-50 border border-rose-100 p-3 rounded-xl flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold text-rose-700 uppercase">Total Disallowed Amount</div>
              <div className="text-lg font-black text-rose-900 mt-0.5">
                {formatCurrency(claims.reduce((acc, c) => acc + Number(c.disallowed_amount || 0), 0))}
              </div>
            </div>
            <div className="text-right text-[11px] text-rose-600 font-semibold">
              Non-payable charges
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5">
            <div className="flex items-center justify-between text-slate-600 font-medium">
              <span>Total Claimed:</span>
              <span className="font-mono font-bold text-slate-900">
                {formatCurrency(claims.reduce((acc, c) => acc + Number(c.claimed_amount || 0), 0))}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600 font-medium">
              <span>Net Sanctioned:</span>
              <span className="font-mono font-bold text-emerald-600">
                {formatCurrency(claims.reduce((acc, c) => acc + Number(c.net_sanct_amt || 0), 0))}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600 font-medium">
              <span>Copayment Deductions:</span>
              <span className="font-mono font-bold text-amber-600">
                {formatCurrency(claims.reduce((acc, c) => acc + Number(c.copayment_amt || 0), 0))}
              </span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
