import React from 'react';
import { TrendingUp, Users, DollarSign, Activity, ShieldCheck, Heart, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { MetricKpis } from '../types';
import { INITIAL_KPIS } from '../data/initialData';

interface KpiGridProps {
  kpis: MetricKpis;
  sessionStartKpis?: MetricKpis;
  activeFilterKey?: string;
  onSelectKpiFilter?: (key: string) => void;
}

export const KpiGrid: React.FC<KpiGridProps> = ({
  kpis,
  sessionStartKpis = INITIAL_KPIS,
  activeFilterKey,
  onSelectKpiFilter,
}) => {
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const getPercentChange = (current: number, baseline: number) => {
    if (!baseline) return 0;
    return ((current - baseline) / baseline) * 100;
  };

  // Helper to construct comparison metrics
  const createCardData = (
    id: string,
    title: string,
    value: string,
    currentNum: number,
    baselineNum: number,
    subtext: string,
    changeBenchmark: string,
    icon: any,
    color: string,
    progressVal: number,
    isLowerBetter: boolean = false
  ) => {
    const pctChange = getPercentChange(currentNum, baselineNum);
    const sessionPercentStr = `${pctChange > 0 ? '+' : ''}${pctChange.toFixed(2)}%`;
    
    // Determine if favorable or unfavorable change
    let sessionIsGood = false;
    let sessionIsBad = false;

    if (isLowerBetter) {
      sessionIsGood = pctChange < 0;
      sessionIsBad = pctChange > 0;
    } else {
      sessionIsGood = pctChange > 0;
      sessionIsBad = pctChange < 0;
    }

    return {
      id,
      title,
      value,
      pctChange,
      sessionPercentStr,
      sessionIsGood,
      sessionIsBad,
      subtext,
      changeBenchmark,
      icon,
      color,
      progressVal,
    };
  };

  const cards = [
    createCardData(
      'arr',
      'ARR (Annual Recurring)',
      formatCurrency(kpis.arr),
      kpis.arr,
      sessionStartKpis.arr,
      `+$${((kpis.arr * 0.001) / 1000).toFixed(1)}k today`,
      `+${kpis.arrGrowthYoY}% YoY`,
      DollarSign,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      82
    ),
    createCardData(
      'mrr',
      'MRR (Monthly Run Rate)',
      formatCurrency(kpis.mrr),
      kpis.mrr,
      sessionStartKpis.mrr,
      'Target: $1.25M',
      '+2.8% MoM',
      TrendingUp,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      90
    ),
    createCardData(
      'users',
      'Active Subscribers',
      kpis.activeUsers.toLocaleString(),
      kpis.activeUsers,
      sessionStartKpis.activeUsers,
      `+${kpis.activeUsersTodayDelta} active today`,
      '+14.2% MoM',
      Users,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      75
    ),
    createCardData(
      'latency',
      'System Latency (P95)',
      `${kpis.latencyMs} ms`,
      kpis.latencyMs,
      sessionStartKpis.latencyMs,
      'Peak: 64ms | SLA < 50ms',
      kpis.latencyMs < 45 ? '-4ms Optimal' : '+8ms High',
      Activity,
      kpis.latencyMs < 45 ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-amber-50 text-amber-600 border-amber-100',
      Math.max(10, 100 - kpis.latencyMs),
      true // isLowerBetter
    ),
    createCardData(
      'uptime',
      'System SLA Uptime',
      `${kpis.uptimePercent}%`,
      kpis.uptimePercent,
      sessionStartKpis.uptimePercent,
      '0 downtime incidents in 30d',
      '100% Target',
      ShieldCheck,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      99
    ),
    createCardData(
      'nps',
      'Net Promoter Score',
      `${kpis.npsScore} / 100`,
      kpis.npsScore,
      sessionStartKpis.npsScore,
      'Based on 4,200 surveys',
      'Top 5% SaaS',
      Heart,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      kpis.npsScore
    ),
  ];

  return (
    <section id="kpi-cards-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {cards.map((card) => {
        const Icon = card.icon;
        const isSelected = activeFilterKey === card.id;

        return (
          <div
            key={card.id}
            id={`kpi-card-${card.id}`}
            onClick={() => onSelectKpiFilter && onSelectKpiFilter(card.id)}
            className={`bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 flex flex-col justify-between transition-all duration-200 cursor-pointer group hover:shadow-md ${
              isSelected ? 'ring-2 ring-indigo-600 border-indigo-600 bg-indigo-50/20' : ''
            }`}
          >
            {/* Top Row: Title + Icon */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-500 text-[11px] font-bold uppercase tracking-wider truncate">
                  {card.title}
                </span>
                <div className={`p-1.5 rounded-lg border ${card.color} shrink-0 ml-1`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Main Value & Visual Comparison Indicator */}
              <div className="flex items-baseline justify-between mt-1 gap-1">
                <div className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight truncate">
                  {card.value}
                </div>

                {/* Session Comparison Badge with Arrow Indicator */}
                <div className="flex flex-col items-end shrink-0 ml-1">
                  <div
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border transition-colors ${
                      card.sessionIsGood
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : card.sessionIsBad
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                    title={`Session change: ${card.sessionPercentStr} since start`}
                  >
                    {card.pctChange > 0 ? (
                      <ArrowUpRight className={`w-3.5 h-3.5 mr-0.5 shrink-0 ${card.sessionIsGood ? 'text-emerald-600' : 'text-rose-600'}`} />
                    ) : card.pctChange < 0 ? (
                      <ArrowDownRight className={`w-3.5 h-3.5 mr-0.5 shrink-0 ${card.sessionIsGood ? 'text-emerald-600' : 'text-rose-600'}`} />
                    ) : (
                      <Minus className="w-3.5 h-3.5 mr-0.5 shrink-0 text-slate-400" />
                    )}
                    <span>{card.sessionPercentStr}</span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-medium tracking-tight mt-0.5">
                    vs session start
                  </span>
                </div>
              </div>
            </div>

            {/* Subtext, Benchmark, and Progress Bar */}
            <div className="mt-3">
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${card.progressVal}%` }}
                />
              </div>
              <div className="flex items-center justify-between mt-2 text-[11px] text-slate-500 font-medium">
                <span className="truncate">{card.subtext}</span>
                <span className="text-[10px] text-slate-400 font-semibold shrink-0 ml-1">
                  {card.changeBenchmark}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </section>
  );
};

