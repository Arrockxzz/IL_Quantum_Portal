import React, { useState } from 'react';
import { DepartmentData } from '../types';
import { Server, Cpu, Layers, ShieldCheck, CheckCircle2, Users, Target, ArrowRight, FileText } from 'lucide-react';

interface DepartmentDeepDiveProps {
  departments: DepartmentData[];
  selectedDeptId: string;
  onSelectDepartment: (id: string) => void;
  onDownloadPdfReport?: () => void;
}

export const DepartmentDeepDive: React.FC<DepartmentDeepDiveProps> = ({
  departments,
  selectedDeptId,
  onSelectDepartment,
  onDownloadPdfReport,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Server':
        return Server;
      case 'Cpu':
        return Cpu;
      case 'Layers':
        return Layers;
      case 'ShieldCheck':
        return ShieldCheck;
      default:
        return Server;
    }
  };

  const selectedDept = departments.find((d) => d.id === selectedDeptId) || departments[0];

  return (
    <section id="department-deep-dive" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight flex items-center">
            <Layers className="w-5 h-5 mr-2 text-indigo-600" />
            Departmental Operations Breakdown
          </h2>
          <p className="text-xs text-slate-500">
            Select a division to inspect revenue targets, team capacity, and active initiatives
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onDownloadPdfReport && (
            <button
              id="dept-download-pdf-btn"
              onClick={onDownloadPdfReport}
              className="flex items-center px-3 py-1.5 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-xl border border-indigo-200 transition-all shadow-2xs"
              title="Download Department & KPI PDF Summary Report"
            >
              <FileText className="w-3.5 h-3.5 mr-1.5" />
              Download PDF Report
            </button>
          )}

          {/* Department Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              onClick={() => onSelectDepartment('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                selectedDeptId === 'all'
                  ? 'bg-white text-indigo-600 font-bold shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Divisions
            </button>
            {departments.map((dept) => (
              <button
                key={dept.id}
                onClick={() => onSelectDepartment(dept.id)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                  selectedDeptId === dept.id
                    ? 'bg-indigo-600 text-white font-bold shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {dept.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Division Detailed Card Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mt-5">
        
        {/* Dept Selector Column */}
        <div className="space-y-2 lg:col-span-1">
          {departments.map((dept) => {
            const Icon = getIcon(dept.iconName);
            const isSelected = selectedDeptId === dept.id;
            const targetPct = Math.min(100, Math.round((dept.revenue / dept.target) * 100));

            return (
              <div
                key={dept.id}
                onClick={() => onSelectDepartment(dept.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-indigo-50/80 border-indigo-600 text-slate-900 shadow-sm font-semibold'
                    : 'bg-slate-50/60 border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-100/60'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-semibold">{dept.name}</h3>
                    <p className="text-[11px] text-slate-500">${(dept.revenue / 1000000).toFixed(2)}M / ${(dept.target / 1000000).toFixed(2)}M</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-emerald-600">+{dept.growthYoY}%</span>
                  <div className="w-12 bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${targetPct}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Division Detail Focus Box */}
        <div className="lg:col-span-3 bg-slate-50/80 border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="text-[11px] uppercase tracking-wider font-bold text-indigo-600">
                  Division Focus
                </span>
                <h3 className="text-lg font-bold text-slate-900 flex items-center mt-0.5">
                  {selectedDept.name}
                </h3>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Health: {selectedDept.healthScore}/100
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">
                  Lead: {selectedDept.lead}
                </span>
              </div>
            </div>

            {/* Metrics Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-5">
              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-[11px] text-slate-500 font-medium">YTD Revenue</span>
                <p className="text-base font-bold text-slate-900 font-mono mt-0.5">
                  ${(selectedDept.revenue / 1000000).toFixed(2)}M
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-[11px] text-slate-500 font-medium">Annual Target</span>
                <p className="text-base font-bold text-slate-900 font-mono mt-0.5">
                  ${(selectedDept.target / 1000000).toFixed(2)}M
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-[11px] text-slate-500 font-medium">Team Headcount</span>
                <p className="text-base font-bold text-slate-900 font-mono mt-0.5 flex items-center">
                  <Users className="w-3.5 h-3.5 mr-1 text-slate-500" />
                  {selectedDept.headcount} Engineers
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-[11px] text-slate-500 font-medium">Active Sprint Initiatives</span>
                <p className="text-base font-bold text-slate-900 font-mono mt-0.5 flex items-center">
                  <Target className="w-3.5 h-3.5 mr-1 text-indigo-600" />
                  {selectedDept.activeProjects} Projects
                </p>
              </div>
            </div>

            {/* Key Milestone Banner */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-800">
                    Primary Operational Benchmark
                  </p>
                  <p className="text-xs text-slate-600">
                    {selectedDept.topMetric}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onSelectDepartment(selectedDept.id)}
                className="hidden sm:flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-800"
              >
                Isolate Log Stream
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
