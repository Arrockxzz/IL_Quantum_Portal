import React, { useState, useMemo } from 'react';
import { ClaimRecord, CustomChartConfig } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { Sliders, BarChart2, PieChart as PieIcon, TrendingUp, Layers } from 'lucide-react';

interface CustomChartBuilderProps {
  claims: ClaimRecord[];
}

export const CustomChartBuilder: React.FC<CustomChartBuilderProps> = ({ claims }) => {
  const [config, setConfig] = useState<CustomChartConfig>({
    chartType: 'bar',
    xAxis: 'disease_category',
    yAxis: 'net_sanct_amt',
    groupDimension: 'none',
    topN: 8,
  });

  const dimensions = [
    { key: 'disease_category', label: 'Disease Category' },
    { key: 'updated_status', label: 'Claim Status' },
    { key: 'type_of_claim', label: 'Type of Claim' },
    { key: 'relation_group', label: 'Relation Group' },
    { key: 'age_band', label: 'Age Band' },
    { key: 'ipd_opd', label: 'IPD / OPD' },
    { key: 'hospital_city', label: 'Hospital City' },
    { key: 'hospital_state', label: 'Hospital State' },
    { key: 'policy_name', label: 'Policy Name' },
    { key: 'whether_hospital_networked', label: 'Network Hospital' },
    { key: '__monthYear', label: 'Month Year' },
  ];

  const metrics = [
    { key: 'net_sanct_amt', label: 'Approved Amount ($)' },
    { key: 'claimed_amount', label: 'Claimed Amount ($)' },
    { key: 'payment_amount', label: 'Paid Amount ($)' },
    { key: 'disallowed_amount', label: 'Disallowed Amount ($)' },
    { key: 'claim_count', label: 'Total Claim Count' },
  ];

  const COLORS = ['#ea580c', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#f59e0b', '#06b6d4', '#64748b'];

  // Aggregate data according to X-Axis and Y-Axis selections
  const chartData = useMemo(() => {
    const map = new Map<string, { xVal: string; yVal: number; count: number }>();

    claims.forEach((claim) => {
      const xVal = String(claim[config.xAxis] || 'Unspecified');
      const existing = map.get(xVal) || { xVal, yVal: 0, count: 0 };

      if (config.yAxis === 'claim_count') {
        existing.yVal += 1;
      } else {
        existing.yVal += Number(claim[config.yAxis] || 0);
      }
      existing.count += 1;
      map.set(xVal, existing);
    });

    const sorted = Array.from(map.values()).sort((a, b) => b.yVal - a.yVal);
    return sorted.slice(0, config.topN);
  }, [claims, config]);

  const formatYValue = (val: number) => {
    if (config.yAxis === 'claim_count') return val.toLocaleString();
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div id="custom-chart-builder" className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-4 my-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-3 gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-orange-50 text-orange-600 rounded-xl border border-orange-100">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">Custom Chart Builder</h3>
            <p className="text-xs text-slate-500">Configure interactive chart visualizers from uploaded claims dataset</p>
          </div>
        </div>

        {/* Chart Type Selector */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'bar' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-semibold transition-all ${
              config.chartType === 'bar' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 mr-1" />
            Bar
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'horizontalBar' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-semibold transition-all ${
              config.chartType === 'horizontalBar' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5 mr-1" />
            Horizontal
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'pie' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-semibold transition-all ${
              config.chartType === 'pie' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PieIcon className="w-3.5 h-3.5 mr-1" />
            Pie
          </button>
          <button
            onClick={() => setConfig((prev) => ({ ...prev, chartType: 'line' }))}
            className={`flex items-center px-2.5 py-1 rounded-lg font-semibold transition-all ${
              config.chartType === 'line' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1" />
            Line
          </button>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
        
        {/* X Axis Selector */}
        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">X-Axis Dimension</label>
          <select
            value={config.xAxis}
            onChange={(e) => setConfig((prev) => ({ ...prev, xAxis: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:outline-none focus:border-orange-500"
          >
            {dimensions.map((d) => (
              <option key={d.key} value={d.key}>
                {d.label}
              </option>
            ))}
          </select>
        </div>

        {/* Y Axis Selector */}
        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">Y-Axis Metric</label>
          <select
            value={config.yAxis}
            onChange={(e) => setConfig((prev) => ({ ...prev, yAxis: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:outline-none focus:border-orange-500"
          >
            {metrics.map((m) => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>
        </div>

        {/* Top N Limit */}
        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">Top N Categories</label>
          <select
            value={config.topN}
            onChange={(e) => setConfig((prev) => ({ ...prev, topN: Number(e.target.value) }))}
            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:outline-none focus:border-orange-500"
          >
            <option value={5}>Top 5</option>
            <option value={8}>Top 8</option>
            <option value={12}>Top 12</option>
            <option value={20}>Top 20</option>
          </select>
        </div>

      </div>

      {/* Chart Canvas */}
      <div className="h-72 w-full pt-2">
        {chartData.length === 0 ? (
          <div className="h-full flex items-center justify-center text-slate-400 text-xs">
            No data available for selected custom configuration.
          </div>
        ) : config.chartType === 'bar' ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="xVal" stroke="#64748b" fontSize={11} angle={-15} textAnchor="end" />
              <YAxis stroke="#64748b" fontSize={11} tickFormatter={(val) => `$${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`} />
              <Tooltip formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']} labelStyle={{ color: '#0f172a', fontWeight: 'bold' }} />
              <Bar dataKey="yVal" fill="#ea580c" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : config.chartType === 'horizontalBar' ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 10, right: 20, left: 50, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
              <XAxis type="number" stroke="#64748b" fontSize={11} tickFormatter={(val) => `$${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`} />
              <YAxis dataKey="xVal" type="category" stroke="#64748b" fontSize={11} width={100} />
              <Tooltip formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']} />
              <Bar dataKey="yVal" fill="#f97316" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : config.chartType === 'pie' ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                dataKey="yVal"
                nameKey="xVal"
                cx="50%"
                cy="50%"
                outerRadius={95}
                label={({ xVal, percent }) => `${xVal} (${(percent * 100).toFixed(0)}%)`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: any) => [formatYValue(Number(value)), 'Value']} />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="xVal" stroke="#64748b" fontSize={11} angle={-15} textAnchor="end" />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip formatter={(value: any) => [formatYValue(Number(value)), 'Metric Value']} />
              <Line type="monotone" dataKey="yVal" stroke="#ea580c" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

    </div>
  );
};
