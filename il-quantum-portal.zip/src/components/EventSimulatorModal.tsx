import React, { useState } from 'react';
import { Zap, X, AlertTriangle, TrendingUp, Radio, Rocket, DollarSign } from 'lucide-react';

interface EventSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerPreset: (eventType: string) => void;
  onTriggerCustom: (title: string, detail: string, value: string, impactType: 'growth' | 'anomaly' | 'deployment') => void;
}

export const EventSimulatorModal: React.FC<EventSimulatorModalProps> = ({
  isOpen,
  onClose,
  onTriggerPreset,
  onTriggerCustom,
}) => {
  const [customTitle, setCustomTitle] = useState('');
  const [customDetail, setCustomDetail] = useState('');
  const [customValue, setCustomValue] = useState('');
  const [impactType, setImpactType] = useState<'growth' | 'anomaly' | 'deployment'>('growth');

  if (!isOpen) return null;

  const presets = [
    {
      id: 'enterprise_contract',
      title: '🚀 Global Enterprise Contract Closed',
      description: 'Sign Fortune 500 company on 3-year Titan Cloud Tier ($120,000/yr MRR boost)',
      badge: '+$120k/yr ARR',
      icon: DollarSign,
      color: 'border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 text-emerald-700',
    },
    {
      id: 'viral_launch',
      title: '⚡ Product Hunt #1 Viral Launch',
      description: 'Surge of 2,400 new subscriber signups within 10 minutes & 3x throughput spike',
      badge: '+2,400 Users',
      icon: Rocket,
      color: 'border-slate-200 hover:border-indigo-500 hover:bg-indigo-50/50 text-indigo-700',
    },
    {
      id: 'latency_spike',
      title: '⚠️ APAC Edge Network Latency Spike',
      description: 'Simulate regional fiber degradation causing 95ms latency surge to test AI alerts',
      badge: '95ms Anomaly',
      icon: AlertTriangle,
      color: 'border-slate-200 hover:border-amber-500 hover:bg-amber-50/50 text-amber-700',
    },
    {
      id: 'cluster_autoscale',
      title: '🛡️ Automated Infra Self-Healing',
      description: 'Provision 12 new GPU cluster nodes & auto-reroute European traffic',
      badge: 'Uptime 99.99%',
      icon: Radio,
      color: 'border-slate-200 hover:border-purple-500 hover:bg-purple-50/50 text-purple-700',
    },
  ];

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;
    onTriggerCustom(customTitle, customDetail || 'Custom simulated event triggered by administrator', customValue || 'Impact Live', impactType);
    setCustomTitle('');
    setCustomDetail('');
    setCustomValue('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl p-6 shadow-2xl relative text-slate-900 animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-xs">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight text-slate-900">Real-Time Event Injector</h2>
              <p className="text-xs text-slate-500">Simulate market surges, server load spikes, or enterprise deals</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preset Presets List */}
        <div className="my-5 space-y-3">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Quick One-Click Simulations
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {presets.map((preset) => (
              <button
                key={preset.id}
                onClick={() => {
                  onTriggerPreset(preset.id);
                  onClose();
                }}
                className={`p-3.5 rounded-xl border bg-slate-50/80 transition-all text-left flex flex-col justify-between hover:scale-[1.01] active:scale-95 ${preset.color}`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{preset.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-normal">{preset.description}</p>
                </div>
                <span className="mt-2 text-[10px] font-mono font-bold text-indigo-600 bg-white px-2 py-0.5 rounded w-fit border border-slate-200 shadow-2xs">
                  {preset.badge}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Event Builder */}
        <form onSubmit={handleCustomSubmit} className="pt-4 border-t border-slate-100 space-y-3">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Custom Event Generator
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Event Title (e.g. Q4 Regional Sale)"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              required
            />
            <input
              type="text"
              placeholder="Value / Delta (e.g. +$45,000)"
              value={customValue}
              onChange={(e) => setCustomValue(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          <textarea
            placeholder="Event Detail Description..."
            value={customDetail}
            onChange={(e) => setCustomDetail(e.target.value)}
            rows={2}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2 text-xs text-slate-500">
              <span>Impact:</span>
              <select
                value={impactType}
                onChange={(e) => setImpactType(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 text-slate-900 rounded-lg px-2 py-1 text-xs focus:outline-none"
              >
                <option value="growth">📈 Revenue Surge</option>
                <option value="anomaly">⚠️ Latency Anomaly</option>
                <option value="deployment">🚀 Infra Deployment</option>
              </select>
            </div>

            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition-all shadow-sm"
            >
              Inject Event Stream
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
