import React, { useState, useRef } from 'react';
import { ChevronLeft, Home, ChevronRight, Menu, FileSpreadsheet, User, Settings, LogOut, Search, X, Activity, ShieldCheck, ChevronDown, Sparkles, Bot } from 'lucide-react';

interface DashboardRibbonProps {
  currentModule: string;
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
  onNavigateBack: () => void;
  onNavigateNext: () => void;
  onOpenFilePicker: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  onOpenAiBot?: () => void;
}

export const DashboardRibbon: React.FC<DashboardRibbonProps> = ({
  currentModule,
  onSelectModule,
  onGoHome,
  onNavigateBack,
  onNavigateNext,
  onOpenFilePicker,
  onOpenSettings,
  onLogout,
  onOpenAiBot,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [menuSearch, setMenuSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Health Claim');

  const menuTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMenuMouseEnter = () => {
    if (menuTimeoutRef.current) clearTimeout(menuTimeoutRef.current);
    setIsMenuOpen(true);
  };

  const handleMenuMouseLeave = () => {
    menuTimeoutRef.current = setTimeout(() => {
      setIsMenuOpen(false);
    }, 200);
  };

  const menuCategories = [
    {
      id: 'Health Claim',
      name: 'Health Claim',
      submodules: ['GHI Summary', 'Retail Health', 'Claim Rejections', 'OPD Tracker'],
    },
    {
      id: 'Muse Data',
      name: 'Muse Data',
      submodules: ['Policy Ingestion', 'Loss Ratio Summary', 'Underwriting Data'],
    },
    {
      id: 'HCU',
      name: 'HCU (Health Care Unit)',
      submodules: ['Network Hospitals', 'Tariff Master', 'Pre-Auth Audit'],
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-orange-600 via-red-600 to-rose-700 text-white shadow-md border-b border-orange-500/30">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-[52px] flex items-center justify-between">
        
        {/* Left Section: Logo & Brand Name */}
        <div className="flex items-center space-x-3 shrink-0">
          <div
            onClick={onGoHome}
            className="w-8 h-8 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center cursor-pointer transition-colors border border-white/20"
            title="ICICI Lombard IL QUANTUM Portal Home"
          >
            <Activity className="w-4 h-4 text-amber-300 animate-pulse" />
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-sm font-black tracking-tight text-white uppercase font-sans">
              ICICI Lombard
            </span>
            <span className="hidden sm:inline-block text-xs font-semibold text-orange-200 border-l border-white/20 pl-2">
              IL QUANTUM PORTAL
            </span>
          </div>
        </div>

        {/* Center/Right Section: Controls & Navigation */}
        <div className="flex items-center space-x-1.5 sm:space-x-2">
          
          {/* Home Compact Controller [‹ 🏠 ›] */}
          <div className="flex items-center bg-black/20 rounded-lg p-0.5 border border-white/15 text-xs">
            <button
              onClick={onNavigateBack}
              className="p-1 hover:bg-white/20 rounded transition-colors text-white/80 hover:text-white"
              title="Previous Page"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onGoHome}
              className="px-2 py-1 hover:bg-white/20 rounded transition-colors text-white font-medium flex items-center gap-1"
              title="Home Landing"
            >
              <Home className="w-3.5 h-3.5 text-amber-300" />
            </button>
            <button
              onClick={onNavigateNext}
              className="p-1 hover:bg-white/20 rounded transition-colors text-white/80 hover:text-white"
              title="Next Page"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Module Menu Hover Dropdown */}
          <div
            className="relative"
            onMouseEnter={handleMenuMouseEnter}
            onMouseLeave={handleMenuMouseLeave}
          >
            <button
              id="dashboard-menu-btn"
              className={`flex items-center px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                isMenuOpen
                  ? 'bg-white text-orange-700 border-white shadow-sm'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
            >
              <Menu className="w-4 h-4 mr-1.5" />
              <span className="hidden md:inline">Menu</span>
            </button>

            {/* Menu Panel with Transparent Hover Bridge */}
            {isMenuOpen && (
              <div
                className="absolute left-0 mt-1 w-72 bg-slate-900 border border-slate-700 text-slate-100 rounded-xl shadow-2xl z-50 p-3 space-y-2 text-xs"
                onMouseEnter={handleMenuMouseEnter}
                onMouseLeave={handleMenuMouseLeave}
              >
                {/* Search Menu Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={menuSearch}
                    onChange={(e) => setMenuSearch(e.target.value)}
                    placeholder="Search menu..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-7 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-orange-500"
                  />
                  {menuSearch && (
                    <button
                      onClick={() => setMenuSearch('')}
                      className="absolute right-2 top-2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Categories & Submodules */}
                <div className="space-y-1 pt-1 max-h-64 overflow-y-auto">
                  {menuCategories
                    .filter(
                      (cat) =>
                        cat.name.toLowerCase().includes(menuSearch.toLowerCase()) ||
                        cat.submodules.some((s) => s.toLowerCase().includes(menuSearch.toLowerCase()))
                    )
                    .map((cat) => (
                      <div key={cat.id} className="space-y-1">
                        <button
                          onClick={() => setActiveCategory(cat.id)}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg font-bold text-left transition-colors ${
                            activeCategory === cat.id
                              ? 'bg-orange-600 text-white'
                              : 'text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <span>{cat.name}</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>

                        {/* Submodules list */}
                        {activeCategory === cat.id && (
                          <div className="pl-3 space-y-1 border-l-2 border-orange-500/40 my-1">
                            {cat.submodules.map((sub) => (
                              <button
                                key={sub}
                                onClick={() => {
                                  onSelectModule(`${cat.name} > ${sub}`);
                                  setIsMenuOpen(false);
                                }}
                                className={`w-full text-left px-2 py-1 rounded text-[11px] transition-colors ${
                                  currentModule.includes(sub)
                                    ? 'bg-orange-500/20 text-orange-300 font-semibold'
                                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                                }`}
                              >
                                • {sub}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Excel File Upload Trigger Icon [📊 Excel] */}
          <button
            id="excel-upload-trigger-btn"
            onClick={onOpenFilePicker}
            className="flex items-center px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400/40 shadow-sm transition-all active:scale-95"
            title="Upload CSV / XLSX Claim Files"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5" />
            <span className="hidden md:inline">Excel Upload</span>
          </button>

          {/* User Profile & Nova AI Container */}
          <div className="flex items-center space-x-1.5">
            {/* Nova AI Small Tiny Icon Button beside User Name */}
            <button
              id="nova-ai-header-btn"
              onClick={onOpenAiBot}
              className="flex items-center space-x-1 bg-indigo-950/70 hover:bg-indigo-900 border border-indigo-400/40 px-2 py-1.5 rounded-lg text-xs font-bold text-white transition-all hover:scale-105 active:scale-95 shadow-sm cursor-pointer group"
              title="Open Nova AI Intelligence & Search (Click to open)"
            >
              <div className="p-0.5 bg-indigo-600 rounded-md text-amber-300 group-hover:bg-indigo-500 transition-colors">
                <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
              </div>
              <span className="text-[11px] font-bold text-indigo-100 tracking-wide">Nova AI</span>
            </button>

            {/* User Profile Dropdown */}
            <div className="relative">
              <button
                id="user-profile-btn"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center space-x-1.5 bg-black/20 hover:bg-black/30 border border-white/20 px-2.5 py-1.5 rounded-lg text-xs font-medium text-white transition-all"
                title="User Profile & Settings"
              >
                <div className="w-5 h-5 bg-orange-400 text-slate-950 font-black rounded-full flex items-center justify-center text-[10px]">
                  AS
                </div>
                <span className="hidden sm:inline-block font-semibold">Ankit Sharma</span>
                <ChevronDown className="w-3 h-3 text-orange-200" />
              </button>

              {/* Profile Popup Overlay */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-1 w-60 bg-slate-900 border border-slate-700 text-slate-100 rounded-xl shadow-2xl z-50 p-3 space-y-3 text-xs">
                  
                  {/* User Header with Settings Icon & Nova AI badge beside Name */}
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-white text-sm">Ankit Sharma</span>
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            if (onOpenAiBot) onOpenAiBot();
                          }}
                          className="px-1.5 py-0.5 bg-indigo-950 border border-indigo-500/40 text-indigo-300 hover:text-white rounded text-[10px] font-bold flex items-center gap-1 hover:bg-indigo-900 cursor-pointer"
                          title="Open Nova AI Search"
                        >
                          <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                          Nova AI
                        </button>
                      </div>
                      <div className="text-[10px] text-orange-400 font-medium">Business Team • Health Analytics</div>
                    </div>
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onOpenSettings();
                      }}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
                      title="Dashboard Settings"
                    >
                      <Settings className="w-4 h-4 text-orange-400" />
                    </button>
                  </div>

                  {/* Profile Actions */}
                  <div className="space-y-1">
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        if (onOpenAiBot) onOpenAiBot();
                      }}
                      className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-indigo-300 hover:text-white hover:bg-indigo-950/50 transition-colors font-medium"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      <span>Open Nova AI Search</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onOpenSettings();
                      }}
                      className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      <Settings className="w-3.5 h-3.5 text-orange-400" />
                      <span>Portal Settings</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onLogout();
                      }}
                      className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 transition-colors font-medium"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Logout to Homepage</span>
                    </button>
                  </div>

                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};
