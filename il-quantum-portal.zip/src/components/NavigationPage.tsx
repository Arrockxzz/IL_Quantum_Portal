import React from 'react';
import { Users, Building2, Layers, ArrowLeft, Home, ArrowRight, ShieldCheck, Activity } from 'lucide-react';

interface NavigationPageProps {
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
}

export const NavigationPage: React.FC<NavigationPageProps> = ({ onSelectModule, onGoHome }) => {
  return (
    <div id="navigation-page" className="min-h-screen bg-slate-900 text-white font-sans flex flex-col justify-between p-6 sm:p-10">
      
      {/* Top Header */}
      <div className="max-w-6xl mx-auto w-full flex items-center justify-between border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-orange-600 to-red-600 rounded-xl flex items-center justify-center text-white shadow-md">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-white">ICICI Lombard | IL QUANTUM</h1>
            <p className="text-xs text-slate-400">Internal Business Team Portal Navigator</p>
          </div>
        </div>
        <button
          onClick={onGoHome}
          className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
        >
          <Home className="w-4 h-4 text-orange-400" />
          <span>Home Landing</span>
        </button>
      </div>

      {/* Main Module Cards */}
      <div className="max-w-6xl mx-auto w-full my-auto py-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">Select Business Workspace</h2>
          <p className="text-sm text-slate-400 mt-2">Choose an operational team workspace to access real-time claims analytics</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Business Team (Main Route) */}
          <div
            onClick={() => onSelectModule('Business Team')}
            className="group relative bg-gradient-to-b from-slate-800 to-slate-900 border border-orange-500/40 hover:border-orange-500 rounded-2xl p-6 shadow-xl hover:shadow-orange-500/20 transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
          >
            <div className="absolute top-4 right-4 bg-orange-500 text-slate-950 font-bold text-[10px] uppercase px-2.5 py-0.5 rounded-full">
              PRIMARY
            </div>

            <div>
              <div className="w-12 h-12 bg-orange-500/10 border border-orange-500/30 rounded-xl flex items-center justify-center text-orange-400 mb-4 group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-orange-300 transition-colors">
                Business Team
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Complete Claims Management Dashboard with Excel/CSV Uploads, Slicers, KPI grids, and Custom Chart Builder.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-orange-400">
              <span>Open Dashboard</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: GHI Analytics Suite */}
          <div
            onClick={() => onSelectModule('GHI Analytics')}
            className="group bg-slate-800/60 border border-slate-700/80 hover:border-slate-500 rounded-2xl p-6 shadow-lg hover:shadow-slate-700/20 transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
          >
            <div>
              <div className="w-12 h-12 bg-slate-700/40 border border-slate-600/40 rounded-xl flex items-center justify-center text-slate-300 mb-4 group-hover:scale-110 transition-transform">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-orange-200 transition-colors">
                GHI Claims Suite
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Group Health Insurance deep dive analytics, employer policy breakdown, and network utilization.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-300 group-hover:text-orange-300">
              <span>Open Module</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Retail Claims Engine */}
          <div
            onClick={() => onSelectModule('Retail Claims')}
            className="group bg-slate-800/60 border border-slate-700/80 hover:border-slate-500 rounded-2xl p-6 shadow-lg hover:shadow-slate-700/20 transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
          >
            <div>
              <div className="w-12 h-12 bg-slate-700/40 border border-slate-600/40 rounded-xl flex items-center justify-center text-slate-300 mb-4 group-hover:scale-110 transition-transform">
                <Layers className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-orange-200 transition-colors">
                Retail Claims Engine
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Individual and Super Top-Up policy claims, age-band distribution, and loss ratio analysis.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-300 group-hover:text-orange-300">
              <span>Open Module</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Control Pill Bar */}
      <div className="max-w-6xl mx-auto w-full flex items-center justify-between border-t border-slate-800 pt-6 text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Internal Access Verified</span>
        </div>

        <div className="flex items-center space-x-2 bg-slate-800 p-1.5 rounded-xl border border-slate-700">
          <button
            onClick={onGoHome}
            className="flex items-center space-x-1 px-3 py-1 hover:bg-slate-700 rounded-lg text-slate-300 transition-colors"
            title="Back to Landing Door"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
          <button
            onClick={onGoHome}
            className="flex items-center space-x-1 px-3 py-1 bg-orange-600 hover:bg-orange-500 text-white font-semibold rounded-lg transition-colors"
            title="Home"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
          <button
            onClick={() => onSelectModule('Business Team')}
            className="flex items-center space-x-1 px-3 py-1 hover:bg-slate-700 rounded-lg text-slate-300 transition-colors"
            title="Next to Dashboard"
          >
            <span>Next</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </div>
  );
};
