import React, { useState } from 'react';
import { PortalSettings } from '../types';
import { Settings, X, RotateCcw, Check, Sliders, Palette } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PortalSettings;
  onUpdateSettings: (newSettings: PortalSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [localSettings, setLocalSettings] = useState<PortalSettings>(settings);

  if (!isOpen) return null;

  const handleApply = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const handleReset = () => {
    const defaultSettings: PortalSettings = {
      themePreset: 'il-orange',
      colorScheme: 'default',
      fontSize: 'medium',
      topNLimit: 10,
      maxFileSizeMb: 25,
    };
    setLocalSettings(defaultSettings);
  };

  return (
    <div id="settings-modal-backdrop" className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden space-y-4">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-red-600 px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-amber-300" />
            <h3 className="text-base font-bold">Portal Settings & Theme</h3>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4 text-xs font-sans text-slate-700">
          
          {/* Theme Preset */}
          <div>
            <label className="block font-bold text-slate-900 mb-1.5 flex items-center gap-1">
              <Palette className="w-3.5 h-3.5 text-orange-600" /> Theme Preset
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'il-orange', name: 'ICICI Lombard Orange', color: 'bg-orange-500' },
                { id: 'corporate-blue', name: 'Corporate Blue', color: 'bg-blue-600' },
                { id: 'emerald', name: 'Emerald Teal', color: 'bg-emerald-600' },
              ].map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setLocalSettings((prev) => ({ ...prev, themePreset: preset.id as any }))}
                  className={`flex items-center space-x-2 p-2 rounded-xl border font-semibold transition-all ${
                    localSettings.themePreset === preset.id
                      ? 'border-orange-500 bg-orange-50/50 text-orange-950 ring-1 ring-orange-500'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full ${preset.color} shrink-0`} />
                  <span className="truncate">{preset.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Font Size & Top N Limits */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-800 mb-1">Font Scale</label>
              <select
                value={localSettings.fontSize}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, fontSize: e.target.value as any }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium focus:outline-none focus:border-orange-500"
              >
                <option value="small">Compact (Small)</option>
                <option value="medium">Default (Medium)</option>
                <option value="large">Accessible (Large)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">Default Top N Limit</label>
              <select
                value={localSettings.topNLimit}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, topNLimit: Number(e.target.value) }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium focus:outline-none focus:border-orange-500"
              >
                <option value={5}>Top 5</option>
                <option value={10}>Top 10</option>
                <option value={15}>Top 15</option>
                <option value={25}>Top 25</option>
              </select>
            </div>
          </div>

          {/* Max Upload File Size */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">Max Upload Size Limit (MB)</label>
            <input
              type="number"
              value={localSettings.maxFileSizeMb}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, maxFileSizeMb: Number(e.target.value) }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium focus:outline-none focus:border-orange-500"
              min={5}
              max={100}
            />
          </div>

        </div>

        {/* Footer Buttons */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-100 flex items-center justify-between text-xs">
          <button
            onClick={handleReset}
            className="flex items-center space-x-1 text-slate-500 hover:text-slate-800 font-medium"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg font-semibold bg-white"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center space-x-1 px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg shadow-sm"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Settings</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
