import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini lazily
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// AI Assistant endpoint for live dashboard data insights
app.post('/api/ai-assist', async (req, res) => {
  try {
    const { prompt, dashboardState, chatHistory } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'A prompt string is required.' });
      return;
    }

    const ai = getGenAI();

    if (!ai) {
      // Fallback helpful response when API key is not set
      res.json({
        reply: `[Demo Mode - Gemini API Key Notice]\n\nI can see your live metrics! Currently:\n- **ARR**: $${dashboardState?.kpis?.arr?.toLocaleString() || '12,450,000'}\n- **Active Subscriptions**: ${dashboardState?.kpis?.activeUsers?.toLocaleString() || '84,200'}\n- **System Uptime**: ${dashboardState?.kpis?.uptime || '99.98%'}\n- **Avg Latency**: ${dashboardState?.kpis?.latency || '42'} ms\n\nTo enable full interactive Gemini AI responses, please add your **GEMINI_API_KEY** in **Settings > Secrets** in AI Studio!`,
        suggestedActions: [
          'Summarize top performers',
          'Forecast Q3 growth',
          'Check system status',
        ],
      });
      return;
    }

    const systemInstruction = `
You are "Nova AI", an expert Executive Data Analyst and Operations Companion for NovaTech Enterprise's Real-Time Intelligence Dashboard.
You have live access to the current dashboard state provided in JSON format.

Your primary duties:
1. Answer user questions concisely, accurately, and with executive clarity based on the real-time company metrics.
2. Highlight anomalies, revenue growth drivers, departmental bottlenecks, server health status, or regional trends when relevant.
3. Use clean markdown formatting (bold metrics, bullet points, headers) for high readability.
4. Keep answers professional yet conversational, concise, and focused on business value.

Current Real-Time Dashboard Snapshot:
${JSON.stringify(dashboardState || {}, null, 2)}
`;

    // Construct message history or prompt
    let formattedPrompt = prompt;
    if (chatHistory && Array.isArray(chatHistory) && chatHistory.length > 0) {
      const historyContext = chatHistory
        .slice(-4)
        .map((m: { role: string; content: string }) => `${m.role.toUpperCase()}: ${m.content}`)
        .join('\n');
      formattedPrompt = `Recent Conversation Context:\n${historyContext}\n\nUser Question: ${prompt}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: formattedPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'I analyzed the live metrics but could not generate a response. Please try rephrasing your question.';

    // Generate quick contextual follow-up chips
    const suggestedActions = [
      'Analyse revenue forecast',
      'Check system latency bottlenecks',
      'Department growth breakdown',
    ];

    res.json({
      reply: replyText,
      suggestedActions,
    });
  } catch (error: any) {
    console.error('Error in /api/ai-assist:', error);
    res.status(500).json({
      error: 'Failed to generate AI insights',
      details: error.message || String(error),
    });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
