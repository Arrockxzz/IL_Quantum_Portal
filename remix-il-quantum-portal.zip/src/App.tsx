import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  INITIAL_KPIS,
  INITIAL_DEPARTMENTS,
  INITIAL_REGIONS,
  INITIAL_TIME_SERIES,
  INITIAL_LOGS,
  INITIAL_CLAIMS,
} from './data/initialData';
import {
  ClaimRecord,
  DepartmentData,
  FilterState,
  GlobalSlicerFilters,
  MetricKpis,
  PageStep,
  PortalSettings,
  RealTimeLog,
  RegionalMetric,
  TimeSeriesPoint,
  UploadedFileMeta,
} from './types';
import { Homepage } from './components/Homepage';
import { NavigationPage } from './components/NavigationPage';
import { DashboardRibbon } from './components/DashboardRibbon';
import { SlicerRow } from './components/SlicerRow';
import { FileUploadPanel } from './components/FileUploadPanel';
import { KpiGrid } from './components/KpiGrid';
import { ChartsSection } from './components/ChartsSection';
import { CustomChartBuilder } from './components/CustomChartBuilder';
import { ClaimsSummaryGrid } from './components/ClaimsSummaryGrid';
import { DepartmentDeepDive } from './components/DepartmentDeepDive';
import { RealTimeFeed } from './components/RealTimeFeed';
import { AiAssistantBot } from './components/AiAssistantBot';
import { EventSimulatorModal } from './components/EventSimulatorModal';
import { SettingsModal } from './components/SettingsModal';
import { generateDashboardPdfReport } from './utils/pdfGenerator';
import { parseCsvFile, parseExcelFile, formatFileSize } from './utils/fileParser';
import { ShieldCheck, Activity, Database, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  // Page Navigation Step: HOMEPAGE | NAVIGATION | DASHBOARD
  const [pageStep, setPageStep] = useState<PageStep>('HOMEPAGE');
  const [currentModule, setCurrentModule] = useState<string>('Business Team');

  // Claims Dataset & Parsed File Metadata
  const [claims, setClaims] = useState<ClaimRecord[]>(INITIAL_CLAIMS);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFileMeta[]>([]);
  const [isFilesPanelOpen, setIsFilesPanelOpen] = useState<boolean>(false);

  // Global Slicer Filters (11 Slicers)
  const [globalFilters, setGlobalFilters] = useState<GlobalSlicerFilters>({
    policy_name: [],
    policy_no: [],
    iltc_tag: [],
    whether_hospital_networked: [],
    relation_group: [],
    type_of_claim: [],
    updated_status: [],
    age_band: [],
    disease_category: [],
    ipd_opd: [],
    __monthYear: [],
  });

  // Table/Chart View Mode Toggle
  const [isTableView, setIsTableView] = useState<boolean>(false);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [portalSettings, setPortalSettings] = useState<PortalSettings>({
    themePreset: 'il-orange',
    colorScheme: 'default',
    darkMode: false,
    fontSize: 'medium',
    topNLimit: 10,
    maxFileSizeMb: 25,
  });

  // Core Real-Time Dashboard KPI State
  const [kpis, setKpis] = useState<MetricKpis>(INITIAL_KPIS);
  const [sessionStartKpis, setSessionStartKpis] = useState<MetricKpis>(INITIAL_KPIS);
  const [departments, setDepartments] = useState<DepartmentData[]>(INITIAL_DEPARTMENTS);
  const [regions, setRegions] = useState<RegionalMetric[]>(INITIAL_REGIONS);
  const [timeSeries, setTimeSeries] = useState<TimeSeriesPoint[]>(INITIAL_TIME_SERIES);
  const [logs, setLogs] = useState<RealTimeLog[]>(INITIAL_LOGS);

  const [filterState, setFilterState] = useState<FilterState>({
    department: 'all',
    region: 'all',
    timeRange: '24h',
    simulationSpeedMs: 2000,
    isPaused: false,
  });

  const [selectedDeptId, setSelectedDeptId] = useState<string>('all');
  const [activeKpiFilter, setActiveKpiFilter] = useState<string>('arr');
  const [isSimulatorOpen, setIsSimulatorOpen] = useState<boolean>(false);

  // Hidden File Input Ref for Excel/CSV upload
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter Claims based on Global Slicer Selections
  const filteredClaims = useMemo(() => {
    return claims.filter((claim) => {
      for (const key of Object.keys(globalFilters) as (keyof GlobalSlicerFilters)[]) {
        const selectedValues = globalFilters[key] || [];
        if (selectedValues.length > 0) {
          const claimValue = String(claim[key] || '');
          if (!selectedValues.includes(claimValue)) {
            return false;
          }
        }
      }
      return true;
    });
  }, [claims, globalFilters]);

  // Recalculate KPIs whenever filtered claims change
  useEffect(() => {
    if (filteredClaims.length === 0) return;

    const totalClaimed = filteredClaims.reduce((acc, c) => acc + Number(c.claimed_amount || 0), 0);
    const totalApproved = filteredClaims.reduce((acc, c) => acc + Number(c.net_sanct_amt || 0), 0);
    const totalPaid = filteredClaims.reduce((acc, c) => acc + Number(c.payment_amount || 0), 0);
    const settledCount = filteredClaims.filter((c) => c.updated_status === 'Claim Settled').length;

    setKpis((prev) => ({
      ...prev,
      arr: totalClaimed > 0 ? totalClaimed : prev.arr,
      mrr: totalApproved > 0 ? totalApproved : prev.mrr,
      activeUsers: settledCount > 0 ? settledCount : prev.activeUsers,
    }));
  }, [filteredClaims]);

  // File Upload Handler
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const fileList: File[] = Array.from(files);
    setIsFilesPanelOpen(true);

    for (const file of fileList) {
      const fileId = `FILE-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const meta: UploadedFileMeta = {
        id: fileId,
        name: file.name,
        type: file.name.split('.').pop() || '',
        size: file.size,
        rawSize: formatFileSize(file.size),
        monthYear: '',
        rowCount: 0,
        status: 'Processing',
        progress: 30,
      };

      setUploadedFiles((prev) => [meta, ...prev]);

      try {
        let parsed: ClaimRecord[] = [];
        if (file.name.endsWith('.csv')) {
          parsed = await parseCsvFile(file);
        } else if (file.name.endsWith('.xls') || file.name.endsWith('.xlsx')) {
          parsed = await parseExcelFile(file);
        }

        setClaims((prev) => [...parsed, ...prev]);

        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === fileId
              ? { ...f, status: 'Uploaded', progress: 100, rowCount: parsed.length }
              : f
          )
        );
      } catch (err) {
        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.id === fileId ? { ...f, status: 'Error', progress: 0 } : f
          )
        );
      }
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveFile = (fileId: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== fileId));
  };

  // Export Functions
  const handleExportCsvRaw = () => {
    const headers = Object.keys(claims[0] || {}).join(',');
    const rows = filteredClaims.map((c) => Object.values(c).join(','));
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `IL_QUANTUM_Raw_Claims_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportCsvTable = () => {
    handleExportCsvRaw();
  };

  const handleExportCsvGraph = () => {
    handleExportCsvRaw();
  };

  const handleExportPdfReport = () => {
    generateDashboardPdfReport(kpis, departments, regions);
  };

  // Real-Time Ticker
  const handleDataTick = useCallback(() => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const arrDelta = Math.floor(Math.random() * 4500) + 1200;
    const mrrDelta = Math.floor(arrDelta / 12);
    const userDelta = Math.floor(Math.random() * 4) + 1;
    const latencyFluc = Math.floor(Math.random() * 7) - 3;
    const reqFluc = Math.floor(Math.random() * 120) - 60;

    setKpis((prev) => ({
      ...prev,
      arr: prev.arr + arrDelta,
      mrr: prev.mrr + mrrDelta,
      activeUsers: prev.activeUsers + userDelta,
      activeUsersTodayDelta: prev.activeUsersTodayDelta + userDelta,
      latencyMs: Math.max(28, Math.min(85, prev.latencyMs + latencyFluc)),
      requestsPerSec: Math.max(2000, prev.requestsPerSec + reqFluc),
    }));

    setTimeSeries((prev) => {
      const lastPoint = prev[prev.length - 1];
      const newPoint: TimeSeriesPoint = {
        time: timeStr,
        arr: (lastPoint?.arr || 14280000) + arrDelta,
        mrr: (lastPoint?.mrr || 1190000) + mrrDelta,
        cloudRevenue: (lastPoint?.cloudRevenue || 5600) + Math.floor(arrDelta * 0.4),
        aiRevenue: (lastPoint?.aiRevenue || 4200) + Math.floor(arrDelta * 0.35),
        saasRevenue: (lastPoint?.saasRevenue || 3000) + Math.floor(arrDelta * 0.25),
        latencyMs: Math.max(28, Math.min(85, (lastPoint?.latencyMs || 38) + latencyFluc)),
        requestsPerSec: Math.max(2000, (lastPoint?.requestsPerSec || 4200) + reqFluc),
      };

      const updated = [...prev, newPoint];
      return updated.length > 15 ? updated.slice(updated.length - 15) : updated;
    });
  }, []);

  useEffect(() => {
    if (filterState.isPaused || filterState.simulationSpeedMs === 0) return;
    const interval = setInterval(() => handleDataTick(), filterState.simulationSpeedMs);
    return () => clearInterval(interval);
  }, [filterState.isPaused, filterState.simulationSpeedMs, handleDataTick]);

  // Handle Page Step 1: HOMEPAGE
  if (pageStep === 'HOMEPAGE') {
    return <Homepage onEnterPortal={() => setPageStep('NAVIGATION')} />;
  }

  // Handle Page Step 2: NAVIGATION
  if (pageStep === 'NAVIGATION') {
    return (
      <NavigationPage
        onSelectModule={(module) => {
          setCurrentModule(module);
          setPageStep('DASHBOARD');
        }}
        onGoHome={() => setPageStep('HOMEPAGE')}
      />
    );
  }

  // Handle Page Step 3: DASHBOARD
  return (
    <div className={`min-h-screen font-sans pb-24 ${portalSettings.darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Hidden File Picker Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        multiple
        accept=".csv,.xls,.xlsx"
        className="hidden"
      />

      {/* Ribbon Header */}
      <DashboardRibbon
        currentModule={currentModule}
        onSelectModule={(m) => setCurrentModule(m)}
        onGoHome={() => setPageStep('HOMEPAGE')}
        onNavigateBack={() => setPageStep('NAVIGATION')}
        onNavigateNext={() => setPageStep('DASHBOARD')}
        onOpenFilePicker={() => fileInputRef.current?.click()}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onLogout={() => setPageStep('HOMEPAGE')}
      />

      {/* Module Title Strip (Wireframe 3 & 5) */}
      <div className="bg-slate-900 border-b border-slate-800 text-xs py-2 px-4 sm:px-8 flex items-center justify-between text-slate-300 shadow-inner">
        <div className="flex items-center space-x-2 font-medium">
          <span className="text-orange-400 font-bold">📍</span>
          <span className="font-semibold text-white tracking-wide">{currentModule || 'Default Dashboard'}</span>
        </div>
        <div className="text-[11px] text-slate-400 font-mono hidden sm:flex items-center space-x-3">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>ICICI Lombard Health Analytics System</span>
        </div>
      </div>

      {/* Slicer Row (Rendered after file upload) */}
      {uploadedFiles.length > 0 && (
        <SlicerRow
          claims={claims}
          filters={globalFilters}
          onUpdateFilters={(newFilters) => setGlobalFilters(newFilters)}
          onRefresh={() => handleDataTick()}
          onToggleViewMode={() => setIsTableView(!isTableView)}
          isTableView={isTableView}
          onExportCsvGraph={handleExportCsvGraph}
          onExportCsvTable={handleExportCsvTable}
          onExportCsvRaw={handleExportCsvRaw}
          onExportPptGraph={handleExportCsvRaw}
          onExportPptTable={handleExportCsvRaw}
          onExportPdfGraph={handleExportPdfReport}
          onExportPdfTable={handleExportPdfReport}
          onToggleFilesPanel={() => setIsFilesPanelOpen(!isFilesPanelOpen)}
          onClearFilters={() =>
            setGlobalFilters({
              policy_name: [],
              policy_no: [],
              iltc_tag: [],
              whether_hospital_networked: [],
              relation_group: [],
              type_of_claim: [],
              updated_status: [],
              age_band: [],
              disease_category: [],
              ipd_opd: [],
              __monthYear: [],
            })
          }
        />
      )}

      {/* File Upload / Parsing Panel */}
      <FileUploadPanel
        files={uploadedFiles}
        isOpen={isFilesPanelOpen}
        onClose={() => setIsFilesPanelOpen(false)}
        onRemoveFile={handleRemoveFile}
        onOpenFilePicker={() => fileInputRef.current?.click()}
      />

      {/* Dashboard Body Container */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-5 space-y-6">
        {uploadedFiles.length === 0 ? (
          /* Wireframe 3: Centered Landing Logo / Body Area Before Upload */
          <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl my-6">
            {/* Centered 25 Years / IL Visual Emblem */}
            <div className="relative mb-6 group">
              <div className="absolute -inset-4 bg-gradient-to-r from-orange-500 to-red-600 rounded-full blur-lg opacity-25 group-hover:opacity-40 transition duration-500"></div>
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 bg-gradient-to-br from-orange-600 via-red-600 to-rose-700 rounded-full flex flex-col items-center justify-center text-white shadow-2xl border-4 border-white/20">
                <span className="text-3xl sm:text-4xl font-black tracking-tighter">25</span>
                <span className="text-[10px] sm:text-xs font-extrabold uppercase tracking-widest text-amber-200">YEARS</span>
                <span className="text-[9px] font-semibold text-white/80 mt-0.5">ICICI LOMBARD</span>
              </div>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-2 font-sans">
              ICICI Lombard • IL QUANTUM PORTAL
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-md mb-8">
              Upload your Health Claims dataset (.XLSX or .CSV) to activate real-time analytics, 11-field interactive slicers, and custom chart builders.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-3.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white font-bold rounded-xl shadow-lg hover:shadow-orange-500/25 transition-all duration-200 active:scale-95 flex items-center space-x-2 cursor-pointer"
              >
                <Database className="w-5 h-5 text-amber-200" />
                <span>Upload Claims File (.xlsx / .csv)</span>
              </button>

              <button
                onClick={() =>
                  setUploadedFiles([
                    {
                      id: 'DEMO-DATASET-2026',
                      name: 'ICICI_Lombard_Sample_Claims.xlsx',
                      type: 'xlsx',
                      size: 1048576,
                      rawSize: '1.0 MB',
                      monthYear: '2026-07',
                      rowCount: claims.length,
                      status: 'Uploaded',
                      progress: 100,
                    },
                  ])
                }
                className="px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold rounded-xl border border-slate-700 transition-all active:scale-95 flex items-center space-x-2 cursor-pointer text-xs sm:text-sm"
              >
                <RefreshCw className="w-4 h-4 text-orange-400" />
                <span>Explore Demo Dashboard</span>
              </button>
            </div>
          </div>
        ) : (
          /* Wireframe 5: Dashboard After Upload with Slicers, Charts & Builder */
          <>
            {/* KPI Grid */}
            <KpiGrid
              kpis={kpis}
              sessionStartKpis={sessionStartKpis}
              activeFilterKey={activeKpiFilter}
              onSelectKpiFilter={(key) => setActiveKpiFilter(key)}
            />

            {/* Charts Section */}
            <ChartsSection
              timeSeries={timeSeries}
              departments={departments}
              regions={regions}
              timeRange={filterState.timeRange}
              setTimeRange={(tr) => setFilterState((prev) => ({ ...prev, timeRange: tr }))}
            />

            {/* Custom Interactive Chart Builder */}
            <CustomChartBuilder claims={filteredClaims} />

            {/* Detailed Claims Section Cards */}
            <ClaimsSummaryGrid claims={filteredClaims} isTableView={isTableView} />

            {/* Two-Column Department & Real-Time Feed */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DepartmentDeepDive
                departments={departments}
                selectedDeptId={selectedDeptId}
                onSelectDepartment={(id) => setSelectedDeptId(id)}
                onDownloadPdfReport={handleExportPdfReport}
              />

              <RealTimeFeed
                logs={logs}
                onClearLogs={() => setLogs([])}
              />
            </div>
          </>
        )}
      </main>

      {/* AI Assistant Bot */}
      <AiAssistantBot
        kpis={kpis}
        departments={departments}
        regions={regions}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={portalSettings}
        onUpdateSettings={(newS) => setPortalSettings(newS)}
      />

      {/* Event Simulator Modal */}
      <EventSimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onTriggerPreset={() => {}}
        onTriggerCustom={() => {}}
      />

      {/* Footer Status Bar */}
      <footer className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 text-xs text-slate-400 py-2 px-4 backdrop-blur-md z-20 flex flex-wrap items-center justify-between gap-2 shadow-lg">
        <div className="flex items-center space-x-3">
          <span className="flex items-center text-orange-400 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-400" />
            ICICI Lombard | IL QUANTUM Portal v3.0
          </span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center text-slate-300 font-medium">
            <Activity className="w-3.5 h-3.5 mr-1 text-orange-500" />
            Active Module: <strong className="ml-1 text-white">{currentModule}</strong>
          </span>
        </div>

        <div className="flex items-center space-x-3 text-[11px]">
          <span>Filtered Records: <strong className="text-amber-400 font-mono">{filteredClaims.length}</strong> / {claims.length}</span>
          <span className="text-slate-700">|</span>
          <button
            onClick={() => setIsSimulatorOpen(true)}
            className="text-orange-400 hover:text-orange-300 font-semibold"
          >
            ⚡ Event Injector
          </button>
        </div>
      </footer>

    </div>
  );
}
