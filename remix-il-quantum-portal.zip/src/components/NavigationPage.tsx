import React from 'react';
import { Users, Building2, Layers, ArrowLeft, Home, ArrowRight, ShieldCheck, Cpu, Terminal, Bot, Radio } from 'lucide-react';
import { MatrixBackground } from './MatrixBackground';

interface NavigationPageProps {
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
}

export const NavigationPage: React.FC<NavigationPageProps> = ({ onSelectModule, onGoHome }) => {
  return (
    <div id="navigation-page" className="relative min-h-screen bg-black text-emerald-400 font-mono flex flex-col justify-between p-6 sm:p-10 select-none overflow-hidden">
      
      {/* Background Matrix Rain Effect */}
      <MatrixBackground theme="emerald" speed={0.9} opacity={0.5} />

      {/* Top Cyber HUD Header */}
      <div className="relative z-10 max-w-6xl mx-auto w-full flex items-center justify-between border-b border-emerald-500/40 pb-6 bg-slate-950/80 p-4 rounded-xl backdrop-blur-md shadow-[0_0_20px_rgba(0,255,102,0.15)]">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-emerald-950 to-slate-900 border border-emerald-400/60 rounded-xl flex items-center justify-center text-emerald-400 shadow-[0_0_15px_#00ff66]">
            <Cpu className="w-5 h-5 text-emerald-300 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-wider text-white text-glow-emerald">ICICI LOMBARD // IL QUANTUM</h1>
            <p className="text-xs text-emerald-400/80 flex items-center">
              <Radio className="w-3 h-3 mr-1 text-cyan-400 animate-pulse" /> MATRIX NEURAL WORKSPACE NAVIGATOR
            </p>
          </div>
        </div>
        
        <button
          onClick={onGoHome}
          className="flex items-center space-x-2 px-4 py-2 text-xs font-bold text-emerald-300 hover:text-white bg-emerald-950/80 hover:bg-emerald-900/90 rounded-lg border border-emerald-500/50 transition-all shadow-[0_0_10px_rgba(0,255,102,0.2)] active:scale-95 cursor-pointer"
        >
          <Home className="w-4 h-4 text-cyan-400" />
          <span>RETURN TO MATRIX GATE</span>
        </button>
      </div>

      {/* Main Module Cards */}
      <div className="relative z-10 max-w-6xl mx-auto w-full my-auto py-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-950/90 border border-emerald-500/40 rounded-full text-xs font-bold text-cyan-300 mb-3">
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>NEURAL CORE SELECTION // SELECT WORKSPACE MATRIX</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-wider text-glow-emerald">
            SELECT OPERATIONAL NEURAL SUITE
          </h2>
          <p className="text-xs text-emerald-400/70 mt-2 font-mono max-w-xl mx-auto">
            Choose a quantum claims processing module to initialize real-time matrix analytics, automated robot audit streams, and slicer engines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Business Team (Main Route) */}
          <div
            onClick={() => onSelectModule('Business Team')}
            className="hud-card group relative bg-slate-950/90 border-2 border-emerald-400 hover:border-cyan-300 rounded-2xl p-6 shadow-[0_0_25px_rgba(0,255,102,0.25)] hover:shadow-[0_0_40px_rgba(0,240,255,0.4)] transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1 backdrop-blur-md"
          >
            <div className="absolute top-4 right-4 bg-emerald-400 text-black font-black text-[10px] uppercase px-2.5 py-0.5 rounded-full shadow-[0_0_10px_#00ff66]">
              CORE MATRIX
            </div>

            <div>
              <div className="w-14 h-14 bg-emerald-950/80 border border-emerald-400 rounded-xl flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(0,255,102,0.3)]">
                <Bot className="w-8 h-8 text-emerald-300 animate-robot-eye" />
              </div>
              <h3 className="text-xl font-black text-white group-hover:text-cyan-300 transition-colors font-mono">
                BUSINESS TEAM MATRIX
              </h3>
              <p className="text-xs text-emerald-400/80 mt-2 leading-relaxed font-mono">
                Primary Claims Analytics Terminal with Excel/CSV Upload Ingestion, 11-Field Slicer Engine, AI Bot Assistant & Custom Chart Generator.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-emerald-500/30 flex items-center justify-between text-xs font-bold text-cyan-300">
              <span className="flex items-center">
                <Terminal className="w-3.5 h-3.5 mr-1 text-emerald-400" /> INITIALIZE WORKSPACE
              </span>
              <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: GHI Analytics Suite */}
          <div
            onClick={() => onSelectModule('GHI Analytics')}
            className="hud-card group relative bg-slate-950/90 border border-emerald-500/40 hover:border-emerald-400 rounded-2xl p-6 shadow-lg hover:shadow-[0_0_30px_rgba(0,255,102,0.3)] transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1 backdrop-blur-md"
          >
            <div>
              <div className="w-14 h-14 bg-slate-900 border border-emerald-500/40 rounded-xl flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
                <Building2 className="w-7 h-7 text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors font-mono">
                GHI CLAIMS MATRIX
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed font-mono">
                Group Health Insurance corporate breakdown, employer loss-ratio metrics, and network hospital matrix utilization.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-bold text-emerald-400 group-hover:text-cyan-300">
              <span>LOAD GHI MODULE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Retail Claims Engine */}
          <div
            onClick={() => onSelectModule('Retail Claims')}
            className="hud-card group relative bg-slate-950/90 border border-emerald-500/40 hover:border-emerald-400 rounded-2xl p-6 shadow-lg hover:shadow-[0_0_30px_rgba(0,255,102,0.3)] transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1 backdrop-blur-md"
          >
            <div>
              <div className="w-14 h-14 bg-slate-900 border border-emerald-500/40 rounded-xl flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
                <Layers className="w-7 h-7 text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors font-mono">
                RETAIL CLAIMS MATRIX
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed font-mono">
                Individual and Super Top-Up policy claims, age-band distribution vectors, and loss-ratio deep-dive analysis.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-bold text-emerald-400 group-hover:text-cyan-300">
              <span>LOAD RETAIL MODULE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Control Pill Bar */}
      <div className="relative z-10 max-w-6xl mx-auto w-full flex flex-wrap items-center justify-between border-t border-emerald-500/30 pt-6 text-xs text-slate-400 bg-slate-950/80 p-4 rounded-xl backdrop-blur-md gap-4">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="text-emerald-300 font-bold">MATRIX NEURAL LINK // ACTIVE</span>
        </div>

        <div className="flex items-center space-x-2 bg-slate-900 p-1.5 rounded-xl border border-emerald-500/40">
          <button
            onClick={onGoHome}
            className="flex items-center space-x-1 px-3 py-1.5 hover:bg-emerald-950 rounded-lg text-emerald-300 transition-colors cursor-pointer"
            title="Back to Landing Gate"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>BACK</span>
          </button>
          <button
            onClick={onGoHome}
            className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-lg transition-colors cursor-pointer shadow-[0_0_10px_#00ff66]"
            title="Home"
          >
            <Home className="w-3.5 h-3.5" />
            <span>HOME</span>
          </button>
          <button
            onClick={() => onSelectModule('Business Team')}
            className="flex items-center space-x-1 px-3 py-1.5 hover:bg-emerald-950 rounded-lg text-emerald-300 transition-colors cursor-pointer"
            title="Next to Dashboard"
          >
            <span>NEXT</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </div>
  );
};

