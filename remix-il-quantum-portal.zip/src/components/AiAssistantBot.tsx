import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, X, Minimize2, Maximize2, Copy, Check, Cpu, Terminal, Radio, Volume2, VolumeX } from 'lucide-react';
import { ChatMessage, MetricKpis, DepartmentData, RegionalMetric } from '../types';

interface AiAssistantBotProps {
  kpis: MetricKpis;
  departments: DepartmentData[];
  regions: RegionalMetric[];
}

export const AiAssistantBot: React.FC<AiAssistantBotProps> = ({ kpis, departments, regions }) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [soundOn, setSoundOn] = useState<boolean>(true);
  const [eyeState, setEyeState] = useState<'happy' | 'analyzing' | 'normal'>('normal');

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      content: `🤖 **CYBER QUANTUM BOT v4.0 ONLINE**\n\nI am your **AI Matrix Data Companion**. Real-time telemetry connection established.\n\n- **Claims Revenue Matrix**: $${(kpis.arr / 1000000).toFixed(2)}M\n- **Neural Latency**: ${kpis.latencyMs}ms\n- **Active Audited Claims**: ${kpis.activeUsers}\n\nAsk me to analyze claims, detect fraud anomalies, or forecast loss ratios!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedActions: [
        'ANALYZE MATRIX CLAIMS',
        'DETECT LOSS RATIO ANOMALIES',
        'FORECAST Q3 CLAIMS',
      ],
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const triggerRobotSynthSound = () => {
    if (!soundOn) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      osc.frequency.setValueAtTime(1200, audioCtx.currentTime + 0.08);
      osc.frequency.setValueAtTime(900, audioCtx.currentTime + 0.16);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } catch (e) {
      // audio fallback
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    triggerRobotSynthSound();
    setEyeState('analyzing');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          dashboardState: {
            kpis,
            departments,
            regions,
            timestamp: new Date().toISOString(),
          },
          chatHistory: messages.map((m) => ({ role: m.sender, content: m.content })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      setEyeState('happy');
      triggerRobotSynthSound();

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        content: data.reply || 'Matrix neural core processed data successfully.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: data.suggestedActions || ['Audit Rejections', 'Hospital Network Analysis'],
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('Error fetching AI response:', err);
      setEyeState('normal');
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        content: `⚠️ **MATRIX NEURAL BUS ERROR**\n\nUnable to reach Gemini 3.6 Flash endpoint.\n\n*Details: ${err.message || String(err)}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
      setTimeout(() => setEyeState('normal'), 2000);
    }
  };

  const handleCopy = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Format markdown text with cyber styling
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-xs font-bold text-cyan-300 mt-2 mb-1">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={idx} className="text-xs font-black text-emerald-300 mt-2 mb-1 text-glow-emerald">{line.replace('## ', '')}</h3>;
      }
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        return (
          <li key={idx} className="ml-3 list-disc text-[11px] text-emerald-300/90 my-0.5 font-mono">
            {formatInlineBold(line.trim().substring(2))}
          </li>
        );
      }
      if (line.trim() === '') {
        return <div key={idx} className="h-1" />;
      }
      return (
        <p key={idx} className="text-[11px] text-emerald-300/90 leading-relaxed my-0.5 font-mono">
          {formatInlineBold(line)}
        </p>
      );
    });
  };

  const formatInlineBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-white text-glow-emerald">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  if (!isOpen) {
    return (
      <button
        id="reopen-ai-bot-btn"
        onClick={() => {
          setIsOpen(true);
          triggerRobotSynthSound();
        }}
        className="fixed bottom-12 right-5 z-40 bg-slate-950 border-2 border-emerald-400 hover:border-cyan-300 text-emerald-400 p-3.5 rounded-2xl shadow-[0_0_25px_rgba(0,255,102,0.4)] hover:shadow-[0_0_40px_rgba(0,240,255,0.6)] flex items-center space-x-2 transition-all hover:scale-105 active:scale-95 cursor-pointer font-mono"
      >
        <Bot className="w-6 h-6 text-emerald-300 animate-robot-eye drop-shadow-[0_0_8px_#00ff66]" />
        <span className="text-xs font-black tracking-widest text-white uppercase">CYBER BOT v4.0</span>
      </button>
    );
  }

  return (
    <div
      id="ai-bot-panel"
      className={`fixed bottom-12 right-4 z-40 transition-all duration-300 ${
        isMinimized ? 'w-80 h-14' : 'w-full max-w-sm sm:max-w-md h-[580px]'
      } bg-slate-950/95 border-2 border-emerald-400/80 rounded-2xl shadow-[0_0_35px_rgba(0,255,102,0.3)] flex flex-col backdrop-blur-xl text-slate-100 font-mono`}
    >
      {/* Robot Panel Header */}
      <div className="bg-slate-900/90 px-4 py-3 rounded-t-2xl border-b border-emerald-500/40 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-3">
          
          {/* Expressive Robot Avatar Eye Box */}
          <div className="relative w-8 h-8 rounded-xl bg-slate-950 border border-emerald-400 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_#00ff66]">
            <Bot className={`w-5 h-5 ${eyeState === 'analyzing' ? 'animate-spin text-cyan-300' : 'animate-robot-eye'}`} />
            <span className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full ${eyeState === 'happy' ? 'bg-cyan-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`} />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-xs font-black text-white text-glow-emerald tracking-wider uppercase">CYBER BOT v4.0</h3>
              <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded font-bold">GEMINI 3.6</span>
            </div>
            <p className="text-[10px] text-emerald-400/80 flex items-center">
              <Radio className="w-3 h-3 mr-1 text-cyan-400 animate-pulse" /> NEURAL LINK ACTIVE
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={() => setSoundOn(!soundOn)}
            className="p-1.5 text-emerald-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title={soundOn ? 'Sound FX On' : 'Sound FX Muted'}
          >
            {soundOn ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
          </button>

          <button
            id="minimize-ai-bot-btn"
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1.5 text-emerald-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title={isMinimized ? 'Expand' : 'Minimize'}
          >
            {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            id="close-ai-bot-btn"
            onClick={() => setIsOpen(false)}
            className="p-1.5 text-emerald-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close Robot Assistant"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expanded Content Area */}
      {!isMinimized && (
        <>
          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-950/80">
            {messages.map((msg, index) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[90%] p-3 text-xs leading-relaxed border ${
                    msg.sender === 'user'
                      ? 'bg-emerald-950/90 border-emerald-400 text-emerald-200 rounded-2xl rounded-tr-none shadow-[0_0_15px_rgba(0,255,102,0.2)]'
                      : msg.isError
                      ? 'bg-rose-950/90 border-rose-500 text-rose-300 rounded-2xl rounded-tl-none'
                      : 'bg-slate-900/90 border-emerald-500/40 text-slate-200 rounded-2xl rounded-tl-none shadow-[0_0_15px_rgba(0,255,102,0.1)]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-emerald-500/20">
                    <span className={`text-[10px] font-bold tracking-widest uppercase flex items-center ${msg.sender === 'user' ? 'text-cyan-300' : 'text-emerald-400'}`}>
                      {msg.sender === 'user' ? (
                        'OPERATOR'
                      ) : (
                        <>
                          <Bot className="w-3 h-3 mr-1 text-emerald-300 animate-robot-eye" />
                          CYBER BOT
                        </>
                      )}
                    </span>
                    <div className="flex items-center space-x-1">
                      <span className="text-[9px] text-emerald-500">{msg.timestamp}</span>
                      {msg.sender === 'ai' && (
                        <button
                          onClick={() => handleCopy(msg.content, index)}
                          className="text-emerald-400 hover:text-white p-0.5 cursor-pointer"
                          title="Copy Matrix Log"
                        >
                          {copiedIndex === index ? <Check className="w-3 h-3 text-cyan-300" /> : <Copy className="w-3 h-3" />}
                        </button>
                      )}
                    </div>
                  </div>

                  <div>{renderFormattedContent(msg.content)}</div>
                </div>

                {/* Suggested Matrix Actions */}
                {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2 max-w-[95%]">
                    {msg.suggestedActions.map((action, aIdx) => (
                      <button
                        key={aIdx}
                        onClick={() => handleSend(action)}
                        className="text-[10px] font-bold bg-slate-900 hover:bg-emerald-950 text-cyan-300 border border-cyan-500/40 hover:border-emerald-400 px-2.5 py-1 rounded-full transition-all shadow-[0_0_8px_rgba(0,240,255,0.2)] hover:scale-105 cursor-pointer uppercase tracking-wider"
                      >
                        ⚡ {action}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {/* Robot Typing / Analyzing Indicator */}
            {isLoading && (
              <div className="flex items-center space-x-2 bg-slate-900 border border-emerald-400/60 p-2.5 rounded-2xl w-44 shadow-[0_0_15px_#00ff66]">
                <Cpu className="w-4 h-4 text-emerald-300 animate-spin" />
                <span className="text-[11px] font-bold text-emerald-300 animate-pulse">NEURAL PROCESSING...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-slate-900/90 border-t border-emerald-500/40 rounded-b-2xl">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center space-x-2"
            >
              <div className="relative flex-1">
                <Terminal className="w-3.5 h-3.5 absolute left-3 top-3 text-emerald-400" />
                <input
                  id="ai-bot-input"
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Command Cyber Bot..."
                  className="w-full bg-slate-950 border border-emerald-500/50 text-emerald-300 placeholder-emerald-600 text-xs rounded-xl pl-8 pr-4 py-2.5 focus:outline-none focus:border-emerald-300 font-mono shadow-inner"
                  disabled={isLoading}
                />
              </div>

              <button
                id="ai-bot-send-btn"
                type="submit"
                disabled={!input.trim() || isLoading}
                className="w-9 h-9 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-30 text-black rounded-xl flex items-center justify-center transition-all font-black shrink-0 shadow-[0_0_12px_#00ff66] cursor-pointer"
              >
                <Send className="w-4 h-4 text-black" />
              </button>
            </form>
          </div>
        </>
      )}
    </div>
  );
};

