import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock, Bot, Terminal, Cpu, Radio, Sparkles } from 'lucide-react';
import { MatrixBackground, MatrixTheme } from './MatrixBackground';

interface HomepageProps {
  onEnterPortal: () => void;
}

export const Homepage: React.FC<HomepageProps> = ({ onEnterPortal }) => {
  const [isOpening, setIsOpening] = useState(false);
  const [matrixTheme, setMatrixTheme] = useState<MatrixTheme>('emerald');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Play sci-fi audio beep if audio context is available
  const triggerCyberBeep = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(220, audioCtx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      // Audio fallback silent
    }
  };

  const handleDoorClick = () => {
    if (isOpening) return;
    triggerCyberBeep();
    setIsOpening(true);
    setTimeout(() => {
      onEnterPortal();
    }, 1100);
  };

  return (
    <div id="homepage-container" className="relative w-full h-screen bg-black overflow-hidden flex flex-col items-center justify-center font-mono text-white select-none">
      
      {/* Dynamic Matrix Rain Canvas Background */}
      <MatrixBackground theme={matrixTheme} speed={1.2} opacity={0.7} />

      {/* Double Cyber Vault Door Overlay */}
      <div className="absolute inset-0 flex z-20 pointer-events-none">
        {/* Left Cyber Vault Door */}
        <div
          className={`w-1/2 h-full bg-slate-950/95 border-r-2 border-emerald-500/50 shadow-[0_0_30px_rgba(0,255,102,0.2)] flex items-center justify-end pr-8 transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? '-translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-right space-y-2 opacity-60">
            <div className="text-xs font-mono text-emerald-400 tracking-widest uppercase flex items-center justify-end space-x-1">
              <Cpu className="w-3.5 h-3.5 mr-1 text-emerald-400 animate-pulse" />
              <span>MATRIX GATE // 01</span>
            </div>
            <div className="w-24 h-1 bg-emerald-500/60 rounded-full ml-auto shadow-[0_0_10px_#00ff66]" />
            <div className="text-[10px] text-slate-500">SYS_ENCRYPTION: 4096-QUANTUM</div>
          </div>
        </div>

        {/* Right Cyber Vault Door */}
        <div
          className={`w-1/2 h-full bg-slate-950/95 border-l-2 border-emerald-500/50 shadow-[0_0_30px_rgba(0,255,102,0.2)] flex items-center justify-start pl-8 transition-transform duration-1000 cubic-bezier(0.87,0,0.13,1) ${
            isOpening ? 'translate-x-full' : 'translate-x-0'
          }`}
        >
          <div className="text-left space-y-2 opacity-60">
            <div className="text-xs font-mono text-emerald-400 tracking-widest uppercase flex items-center space-x-1">
              <span>IL QUANTUM PROTOCOL</span>
              <Terminal className="w-3.5 h-3.5 ml-1 text-emerald-400 animate-pulse" />
            </div>
            <div className="w-24 h-1 bg-emerald-500/60 rounded-full shadow-[0_0_10px_#00ff66]" />
            <div className="text-[10px] text-slate-500">STATUS: READY_FOR_NEURAL_LINK</div>
          </div>
        </div>
      </div>

      {/* Futuristic Floating HUD Theme Controls (Top Left) */}
      <div className="absolute top-4 left-4 z-30 flex items-center space-x-2 bg-slate-950/80 backdrop-blur-md border border-emerald-500/30 p-2 rounded-xl text-[11px]">
        <span className="text-emerald-400 font-bold flex items-center">
          <Radio className="w-3.5 h-3.5 mr-1 text-emerald-400 animate-pulse" /> MATRIX COLOR:
        </span>
        <button
          onClick={() => setMatrixTheme('emerald')}
          className={`w-5 h-5 rounded-full border border-emerald-400 ${matrixTheme === 'emerald' ? 'ring-2 ring-emerald-400 bg-emerald-500' : 'bg-emerald-950'}`}
          title="Matrix Emerald Green"
        />
        <button
          onClick={() => setMatrixTheme('cyan')}
          className={`w-5 h-5 rounded-full border border-cyan-400 ${matrixTheme === 'cyan' ? 'ring-2 ring-cyan-400 bg-cyan-500' : 'bg-cyan-950'}`}
          title="Cyber Cyan"
        />
        <button
          onClick={() => setMatrixTheme('purple')}
          className={`w-5 h-5 rounded-full border border-purple-400 ${matrixTheme === 'purple' ? 'ring-2 ring-purple-400 bg-purple-500' : 'bg-purple-950'}`}
          title="Quantum Violet"
        />
        <button
          onClick={() => setMatrixTheme('red')}
          className={`w-5 h-5 rounded-full border border-rose-400 ${matrixTheme === 'red' ? 'ring-2 ring-rose-400 bg-rose-500' : 'bg-rose-950'}`}
          title="Red Alert Matrix"
        />
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`ml-2 px-2 py-0.5 rounded text-[10px] font-bold border ${soundEnabled ? 'border-emerald-500 text-emerald-300 bg-emerald-950/50' : 'border-slate-700 text-slate-500'}`}
        >
          {soundEnabled ? '🔊 AUDIO ON' : '🔇 AUDIO OFF'}
        </button>
      </div>

      {/* Main Content Card Container */}
      <div className="relative z-10 flex flex-col items-center max-w-xl mx-auto text-center px-4">
        
        {/* Holographic Cyber Robot Emblem */}
        <div className="mb-6 p-4 bg-slate-950/80 rounded-2xl border-2 border-emerald-500/40 shadow-[0_0_30px_rgba(0,255,102,0.3)] backdrop-blur-xl relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-2xl blur-md opacity-30 group-hover:opacity-60 transition duration-500" />
          
          <div className="relative w-20 h-20 bg-gradient-to-tr from-slate-900 via-emerald-950 to-cyan-950 rounded-xl flex items-center justify-center border border-emerald-400/50 shadow-inner">
            <Bot className="w-12 h-12 text-emerald-400 animate-robot-eye drop-shadow-[0_0_12px_#00ff66]" />
            <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          </div>
        </div>

        {/* Cyber Subtitle Tag */}
        <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-mono mb-4 shadow-[0_0_15px_rgba(0,255,102,0.2)]">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
          <span className="tracking-wider">ICICI LOMBARD // QUANTUM MATRIX CORE v4.0</span>
        </div>

        {/* Glitch Robot Title */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-300 to-emerald-200 mb-2 font-mono text-glow-emerald">
          IL QUANTUM
        </h1>
        <p className="text-xs sm:text-sm text-emerald-400/80 font-mono tracking-widest uppercase mb-8">
          AI-POWERED MATRIX HEALTH CLAIMS ANALYTICS PORTAL
        </p>

        {/* Clickable Entry Door Button */}
        <button
          id="enter-portal-btn"
          onClick={handleDoorClick}
          disabled={isOpening}
          className={`group relative inline-flex items-center justify-center px-10 py-5 text-base font-bold text-black bg-gradient-to-r from-emerald-400 via-cyan-400 to-emerald-300 rounded-2xl shadow-[0_0_30px_rgba(0,255,102,0.5)] hover:shadow-[0_0_50px_rgba(0,255,102,0.8)] transition-all duration-300 active:scale-95 cursor-pointer overflow-hidden border-2 border-emerald-300 ${
            !isOpening ? 'animate-breathe' : ''
          }`}
        >
          {/* Top-Right Live Status Indicator Pill */}
          <div
            className={`absolute top-1.5 right-2.5 flex items-center space-x-1.5 text-[9px] font-mono font-bold bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-full border transition-all duration-300 pointer-events-none ${
              isOpening
                ? 'border-amber-400/80 text-amber-300'
                : 'border-emerald-400/60 text-emerald-300'
            }`}
          >
            {isOpening ? (
              <>
                <Lock className="w-2.5 h-2.5 text-amber-300 animate-pulse-then-stop shrink-0" />
                <span className="uppercase tracking-wider">NEURAL DECRYPTING...</span>
              </>
            ) : (
              <>
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400"></span>
                </span>
                <span className="uppercase tracking-wider">ONLINE</span>
                <span className="text-emerald-500">•</span>
                <span className="text-cyan-300">0.4ms</span>
              </>
            )}
          </div>

          {/* Glowing Shimmer */}
          <span className="absolute top-0 right-0 w-12 h-full bg-white/40 transform skew-x-12 -translate-x-32 group-hover:translate-x-56 transition-transform duration-1000 ease-out" />
          
          <span className="relative flex items-center space-x-3 text-black font-black uppercase tracking-widest text-sm sm:text-base">
            <Cpu className="w-5 h-5 text-black animate-pulse" />
            <span>ENTER MATRIX PORTAL</span>
            <ArrowRight className="w-5 h-5 text-black group-hover:translate-x-1 transition-transform" />
          </span>
        </button>

        {/* Security & Matrix HUD System Footer */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400 font-mono">
          <div className="flex items-center space-x-1.5 bg-slate-950/80 px-3 py-1 rounded-lg border border-emerald-500/30">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-300">QUANTUM ENCRYPTED</span>
          </div>
          <span className="text-emerald-500">•</span>
          <div className="bg-slate-950/80 px-3 py-1 rounded-lg border border-cyan-500/30 text-cyan-300">
            SYS_NODE: NEURAL-08
          </div>
          <span className="text-emerald-500">•</span>
          <div className="text-slate-400">v2026.MATRIX.IL</div>
        </div>

      </div>
    </div>
  );
};

