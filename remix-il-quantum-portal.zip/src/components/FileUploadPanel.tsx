import React from 'react';
import { UploadedFileMeta } from '../types';
import { FileSpreadsheet, CheckCircle2, AlertCircle, Clock, X, RefreshCw } from 'lucide-react';

interface FileUploadPanelProps {
  files: UploadedFileMeta[];
  isOpen: boolean;
  onClose: () => void;
  onRemoveFile: (fileId: string) => void;
  onOpenFilePicker: () => void;
}

export const FileUploadPanel: React.FC<FileUploadPanelProps> = ({
  files,
  isOpen,
  onClose,
  onRemoveFile,
  onOpenFilePicker,
}) => {
  if (!isOpen) return null;

  return (
    <div id="file-upload-panel" className="bg-slate-950/95 border-b border-emerald-500/50 text-white p-4 shadow-[0_10px_30px_rgba(0,255,102,0.2)] z-30 transition-all font-mono backdrop-blur-md">
      <div className="max-w-7xl mx-auto space-y-3">
        
        {/* Panel Header */}
        <div className="flex items-center justify-between pb-2 border-b border-emerald-500/40">
          <div className="flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400 text-glow-emerald" />
            <h3 className="text-sm font-black text-white text-glow-emerald uppercase">PARSED MATRIX DATASETS</h3>
            <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/50 text-xs px-2.5 py-0.5 rounded-full font-bold shadow-[0_0_8px_#00ff66]">
              {files.length} FILE{files.length !== 1 ? 'S' : ''}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenFilePicker}
              className="px-3 py-1 bg-emerald-400 hover:bg-emerald-300 text-black rounded-lg text-xs font-black shadow-[0_0_12px_#00ff66] transition-all cursor-pointer"
            >
              + UPLOAD STREAM
            </button>
            <button
              onClick={onClose}
              className="p-1 text-emerald-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* File Queue List */}
        {files.length === 0 ? (
          <div className="py-6 text-center text-emerald-600 text-xs">
            NO STREAM FILE LOADED. CLICK "+ UPLOAD STREAM" TO PARSE CSV/XLSX MATRIX FILE.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-56 overflow-y-auto pr-1">
            {files.map((file) => (
              <div
                key={file.id}
                className="bg-slate-900/90 border border-emerald-500/40 rounded-xl p-3 flex flex-col justify-between space-y-2 text-xs shadow-[0_0_10px_rgba(0,255,102,0.1)]"
              >
                <div className="flex items-start justify-between">
                  <div className="truncate pr-2">
                    <div className="font-bold text-white truncate" title={file.name}>
                      {file.name}
                    </div>
                    <div className="text-[10px] text-emerald-400/80 font-mono mt-0.5">
                      {file.rawSize} • {file.rowCount.toLocaleString()} ROWS
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveFile(file.id)}
                    className="text-emerald-500 hover:text-rose-400 p-0.5 rounded hover:bg-slate-800 cursor-pointer"
                    title="Remove Dataset"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Status Badge & Progress */}
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1 font-bold">
                    <span className="flex items-center">
                      {file.status === 'Uploaded' && <CheckCircle2 className="w-3 h-3 text-emerald-400 mr-1" />}
                      {file.status === 'Processing' && <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin mr-1" />}
                      {file.status === 'Queued' && <Clock className="w-3 h-3 text-cyan-400 mr-1" />}
                      {file.status === 'Error' && <AlertCircle className="w-3 h-3 text-rose-400 mr-1" />}
                      <span
                        className={
                          file.status === 'Uploaded'
                            ? 'text-emerald-400'
                            : file.status === 'Processing'
                            ? 'text-cyan-400'
                            : file.status === 'Error'
                            ? 'text-rose-400'
                            : 'text-cyan-400'
                        }
                      >
                        {file.status}
                      </span>
                    </span>
                    <span className="text-emerald-400 font-mono">{file.progress}%</span>
                  </div>

                  <div className="w-full bg-slate-950 border border-emerald-500/30 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        file.status === 'Uploaded'
                          ? 'bg-emerald-400 shadow-[0_0_8px_#00ff66]'
                          : file.status === 'Error'
                          ? 'bg-rose-500'
                          : 'bg-cyan-400'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
