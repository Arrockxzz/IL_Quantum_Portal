import React, { useState, useRef } from 'react';
import { ChevronLeft, Home, ChevronRight, Menu, FileSpreadsheet, Settings, LogOut, Search, X, Cpu, ChevronDown, Terminal, Radio } from 'lucide-react';

interface DashboardRibbonProps {
  currentModule: string;
  onSelectModule: (moduleName: string) => void;
  onGoHome: () => void;
  onNavigateBack: () => void;
  onNavigateNext: () => void;
  onOpenFilePicker: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
}

export const DashboardRibbon: React.FC<DashboardRibbonProps> = ({
  currentModule,
  onSelectModule,
  onGoHome,
  onNavigateBack,
  onNavigateNext,
  onOpenFilePicker,
  onOpenSettings,
  onLogout,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [menuSearch, setMenuSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Health Claim');

  const menuTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMenuMouseEnter = () => {
    if (menuTimeoutRef.current) clearTimeout(menuTimeoutRef.current);
    setIsMenuOpen(true);
  };

  const handleMenuMouseLeave = () => {
    menuTimeoutRef.current = setTimeout(() => {
      setIsMenuOpen(false);
    }, 200);
  };

  const menuCategories = [
    {
      id: 'Health Claim',
      name: 'Health Claim Matrix',
      submodules: ['GHI Summary', 'Retail Health', 'Claim Rejections', 'OPD Tracker'],
    },
    {
      id: 'Muse Data',
      name: 'Muse Neural Data',
      submodules: ['Policy Ingestion', 'Loss Ratio Summary', 'Underwriting Data'],
    },
    {
      id: 'HCU',
      name: 'HCU Quantum Unit',
      submodules: ['Network Hospitals', 'Tariff Master', 'Pre-Auth Audit'],
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 text-white shadow-[0_0_20px_rgba(0,255,102,0.2)] border-b border-emerald-500/40 backdrop-blur-xl font-mono">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-[54px] flex items-center justify-between">
        
        {/* Left Section: Robot Logo & Brand Name */}
        <div className="flex items-center space-x-3 shrink-0">
          <div
            onClick={onGoHome}
            className="w-9 h-9 bg-emerald-950/80 hover:bg-emerald-900 rounded-lg flex items-center justify-center cursor-pointer transition-colors border border-emerald-400/50 shadow-[0_0_12px_#00ff66]"
            title="ICICI Lombard IL QUANTUM Matrix Portal"
          >
            <Cpu className="w-5 h-5 text-emerald-300 animate-pulse" />
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-sm font-black tracking-wider text-white uppercase text-glow-emerald font-mono">
              ICICI LOMBARD
            </span>
            <span className="hidden sm:inline-block text-xs font-bold text-cyan-300 border-l border-emerald-500/40 pl-2">
              QUANTUM MATRIX PORTAL
            </span>
          </div>
        </div>

        {/* Center/Right Section: Controls & Navigation */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Home Compact Controller [‹ 🏠 ›] */}
          <div className="flex items-center bg-slate-900/90 rounded-lg p-0.5 border border-emerald-500/40 text-xs shadow-inner">
            <button
              onClick={onNavigateBack}
              className="p-1 hover:bg-emerald-950 rounded transition-colors text-emerald-400 hover:text-white cursor-pointer"
              title="Previous Page"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onGoHome}
              className="px-2 py-1 hover:bg-emerald-950 rounded transition-colors text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
              title="Home Gate"
            >
              <Home className="w-3.5 h-3.5 text-emerald-400" />
            </button>
            <button
              onClick={onNavigateNext}
              className="p-1 hover:bg-emerald-950 rounded transition-colors text-emerald-400 hover:text-white cursor-pointer"
              title="Next Page"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Module Menu Hover Dropdown */}
          <div
            className="relative"
            onMouseEnter={handleMenuMouseEnter}
            onMouseLeave={handleMenuMouseLeave}
          >
            <button
              id="dashboard-menu-btn"
              className={`flex items-center px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                isMenuOpen
                  ? 'bg-emerald-400 text-black border-emerald-300 shadow-[0_0_15px_#00ff66]'
                  : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border-emerald-500/50'
              }`}
            >
              <Menu className="w-4 h-4 mr-1.5" />
              <span className="hidden md:inline">MATRIX MENU</span>
            </button>

            {/* Menu Panel with Transparent Hover Bridge */}
            {isMenuOpen && (
              <div
                className="absolute left-0 mt-1 w-72 bg-slate-950 border-2 border-emerald-400 text-slate-100 rounded-xl shadow-[0_0_30px_rgba(0,255,102,0.3)] z-50 p-3 space-y-2 text-xs font-mono"
                onMouseEnter={handleMenuMouseEnter}
                onMouseLeave={handleMenuMouseLeave}
              >
                {/* Search Menu Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-emerald-400" />
                  <input
                    type="text"
                    value={menuSearch}
                    onChange={(e) => setMenuSearch(e.target.value)}
                    placeholder="Filter matrix modules..."
                    className="w-full bg-slate-900 border border-emerald-500/50 rounded-lg pl-8 pr-7 py-1.5 text-xs text-emerald-300 placeholder-emerald-600 focus:outline-none focus:border-emerald-400 font-mono"
                  />
                  {menuSearch && (
                    <button
                      onClick={() => setMenuSearch('')}
                      className="absolute right-2 top-2 text-emerald-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Categories & Submodules */}
                <div className="space-y-1 pt-1 max-h-64 overflow-y-auto">
                  {menuCategories
                    .filter(
                      (cat) =>
                        cat.name.toLowerCase().includes(menuSearch.toLowerCase()) ||
                        cat.submodules.some((s) => s.toLowerCase().includes(menuSearch.toLowerCase()))
                    )
                    .map((cat) => (
                      <div key={cat.id} className="space-y-1">
                        <button
                          onClick={() => setActiveCategory(cat.id)}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg font-bold text-left transition-colors cursor-pointer ${
                            activeCategory === cat.id
                              ? 'bg-emerald-500 text-black font-black'
                              : 'text-emerald-300 hover:bg-slate-900'
                          }`}
                        >
                          <span>{cat.name}</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>

                        {/* Submodules list */}
                        {activeCategory === cat.id && (
                          <div className="pl-3 space-y-1 border-l-2 border-emerald-500/50 my-1">
                            {cat.submodules.map((sub) => (
                              <button
                                key={sub}
                                onClick={() => {
                                  onSelectModule(`${cat.name} > ${sub}`);
                                  setIsMenuOpen(false);
                                }}
                                className={`w-full text-left px-2 py-1 rounded text-[11px] transition-colors cursor-pointer ${
                                  currentModule.includes(sub)
                                    ? 'bg-emerald-500/20 text-cyan-300 font-bold border-l-2 border-cyan-400'
                                    : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-900'
                                }`}
                              >
                                • {sub}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Excel File Upload Trigger Icon [📊 Matrix Ingest] */}
          <button
            id="excel-upload-trigger-btn"
            onClick={onOpenFilePicker}
            className="flex items-center px-3 py-1.5 rounded-lg text-xs font-black bg-emerald-400 hover:bg-emerald-300 text-black border border-emerald-300 shadow-[0_0_12px_rgba(0,255,102,0.4)] transition-all active:scale-95 cursor-pointer"
            title="Upload CSV / XLSX Matrix Claim Files"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-black" />
            <span>INGEST FILE</span>
          </button>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              id="user-profile-btn"
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center space-x-1.5 bg-slate-900 hover:bg-slate-800 border border-emerald-500/40 px-2.5 py-1.5 rounded-lg text-xs font-bold text-emerald-300 transition-all cursor-pointer"
              title="Matrix Operator Settings"
            >
              <div className="w-5 h-5 bg-emerald-400 text-black font-black rounded-full flex items-center justify-center text-[10px]">
                AS
              </div>
              <span className="hidden sm:inline-block font-mono">Ankit Sharma</span>
              <ChevronDown className="w-3 h-3 text-emerald-400" />
            </button>

            {/* Profile Popup Overlay */}
            {isUserMenuOpen && (
              <div className="absolute right-0 mt-1 w-60 bg-slate-950 border-2 border-emerald-400 text-slate-100 rounded-xl shadow-[0_0_30px_rgba(0,255,102,0.3)] z-50 p-3 space-y-3 text-xs font-mono">
                
                {/* User Header with Settings Icon beside Name */}
                <div className="flex items-center justify-between pb-2 border-b border-emerald-500/30">
                  <div>
                    <div className="font-bold text-white text-sm">Ankit Sharma</div>
                    <div className="text-[10px] text-cyan-400 font-bold flex items-center">
                      <Terminal className="w-3 h-3 mr-1 text-emerald-400" /> MATRIX OPERATOR
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="p-1.5 bg-slate-900 hover:bg-emerald-950 text-emerald-300 rounded-lg transition-colors border border-emerald-500/40 cursor-pointer"
                    title="Dashboard Settings"
                  >
                    <Settings className="w-4 h-4 text-emerald-400" />
                  </button>
                </div>

                {/* Profile Actions */}
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-emerald-300 hover:text-white hover:bg-emerald-950/50 transition-colors cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Portal Cyber Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 transition-colors font-bold cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Exit Matrix Session</span>
                  </button>
                </div>

              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};

