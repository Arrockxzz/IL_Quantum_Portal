import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { DepartmentData, RegionalMetric, TimeSeriesPoint } from '../types';
import { TrendingUp, BarChart3, Globe, Cpu, Layers } from 'lucide-react';

interface ChartsSectionProps {
  timeSeries: TimeSeriesPoint[];
  departments: DepartmentData[];
  regions: RegionalMetric[];
  timeRange: '24h' | '7d' | '30d' | 'YTD';
  setTimeRange: (tr: '24h' | '7d' | '30d' | 'YTD') => void;
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({
  timeSeries,
  departments,
  regions,
  timeRange,
  setTimeRange,
}) => {
  const [activeTab, setActiveTab] = useState<'revenue' | 'departments' | 'regions' | 'system'>('revenue');

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}k`;
    return `$${val}`;
  };

  return (
    <section id="charts-main-section" className="hud-card rounded-2xl p-6 shadow-[0_0_25px_rgba(0,255,102,0.15)] font-mono">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-emerald-500/40">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1 rounded-xl text-xs font-bold border border-emerald-500/40">
          <button
            id="chart-tab-revenue"
            onClick={() => setActiveTab('revenue')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
              activeTab === 'revenue'
                ? 'bg-emerald-400 text-black font-black shadow-[0_0_12px_#00ff66]'
                : 'text-emerald-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 mr-1.5" />
            Claim Growth Matrix
          </button>

          <button
            id="chart-tab-departments"
            onClick={() => setActiveTab('departments')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
              activeTab === 'departments'
                ? 'bg-emerald-400 text-black font-black shadow-[0_0_12px_#00ff66]'
                : 'text-emerald-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BarChart3 className="w-4 h-4 mr-1.5" />
            Unit Loss Targets
          </button>

          <button
            id="chart-tab-regions"
            onClick={() => setActiveTab('regions')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
              activeTab === 'regions'
                ? 'bg-emerald-400 text-black font-black shadow-[0_0_12px_#00ff66]'
                : 'text-emerald-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Globe className="w-4 h-4 mr-1.5" />
            Regional Portals
          </button>

          <button
            id="chart-tab-system"
            onClick={() => setActiveTab('system')}
            className={`flex items-center px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
              activeTab === 'system'
                ? 'bg-emerald-400 text-black font-black shadow-[0_0_12px_#00ff66]'
                : 'text-emerald-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Cpu className="w-4 h-4 mr-1.5" />
            Neural Pulse Telemetry
          </button>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl text-xs font-bold border border-emerald-500/40">
          {(['24h', '7d', '30d', 'YTD'] as const).map((tr) => (
            <button
              key={tr}
              id={`time-range-${tr}`}
              onClick={() => setTimeRange(tr)}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                timeRange === tr
                  ? 'bg-cyan-400 text-black font-black shadow-[0_0_10px_#00f0ff]'
                  : 'text-emerald-400 hover:text-white'
              }`}
            >
              {tr}
            </button>
          ))}
        </div>

      </div>

      {/* Chart Body Container */}
      <div className="mt-5 h-[340px] w-full relative">
        
        {/* Tab 1: Revenue Stream */}
        {activeTab === 'revenue' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timeSeries} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorCloud" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00ff66" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="#00ff66" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorAi" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="#00f0ff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorSaas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#00ff6622" vertical={false} />
              <XAxis dataKey="time" stroke="#00ff6688" fontSize={12} tickLine={false} />
              <YAxis
                stroke="#00ff6688"
                fontSize={12}
                tickFormatter={formatCurrency}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#030712',
                  borderColor: '#00ff66',
                  borderRadius: '0.75rem',
                  color: '#00ff66',
                  fontSize: '12px',
                  boxShadow: '0 0 20px rgba(0, 255, 102, 0.4)',
                  fontFamily: 'monospace',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Matrix Telemetry']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#00ff66' }} />
              <Area
                type="monotone"
                dataKey="cloudRevenue"
                name="GHI Claims"
                stroke="#00ff66"
                fillOpacity={1}
                fill="url(#colorCloud)"
                strokeWidth={2.5}
              />
              <Area
                type="monotone"
                dataKey="aiRevenue"
                name="Retail Health"
                stroke="#00f0ff"
                fillOpacity={1}
                fill="url(#colorAi)"
                strokeWidth={2.5}
              />
              <Area
                type="monotone"
                dataKey="saasRevenue"
                name="Pre-Auth Neural"
                stroke="#a855f7"
                fillOpacity={1}
                fill="url(#colorSaas)"
                strokeWidth={2.5}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {/* Tab 2: Department Breakdown */}
        {activeTab === 'departments' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={departments} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#00ff6622" vertical={false} />
              <XAxis dataKey="name" stroke="#00ff6688" fontSize={11} tickLine={false} />
              <YAxis
                stroke="#00ff6688"
                fontSize={12}
                tickFormatter={formatCurrency}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#030712',
                  borderColor: '#00ff66',
                  borderRadius: '0.75rem',
                  color: '#00ff66',
                  fontSize: '12px',
                  boxShadow: '0 0 20px rgba(0, 255, 102, 0.4)',
                  fontFamily: 'monospace',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Value']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#00ff66' }} />
              <Bar dataKey="revenue" name="Audited Revenue ($)" fill="#00ff66" radius={[6, 6, 0, 0]} />
              <Bar dataKey="target" name="Matrix Target ($)" fill="#00f0ff" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}

        {/* Tab 3: Regional Markets */}
        {activeTab === 'regions' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              layout="vertical"
              data={regions}
              margin={{ top: 10, right: 20, left: 20, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#00ff6622" horizontal={false} />
              <XAxis type="number" stroke="#00ff6688" fontSize={12} tickFormatter={formatCurrency} />
              <YAxis
                dataKey="code"
                type="category"
                stroke="#00ff6688"
                fontSize={12}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#030712',
                  borderColor: '#00ff66',
                  borderRadius: '0.75rem',
                  color: '#00ff66',
                  fontSize: '12px',
                  boxShadow: '0 0 20px rgba(0, 255, 102, 0.4)',
                  fontFamily: 'monospace',
                }}
                formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Matrix Volume']}
              />
              <Bar dataKey="revenue" name="Regional Quantum Volume" fill="#00f0ff" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}

        {/* Tab 4: System Health & Throughput */}
        {activeTab === 'system' && (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timeSeries} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#00ff6622" vertical={false} />
              <XAxis dataKey="time" stroke="#00ff6688" fontSize={12} tickLine={false} />
              <YAxis
                yAxisId="left"
                stroke="#00ff66"
                fontSize={12}
                unit=" ms"
                tickLine={false}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#00f0ff"
                fontSize={12}
                unit=" req/s"
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#030712',
                  borderColor: '#00ff66',
                  borderRadius: '0.75rem',
                  color: '#00ff66',
                  fontSize: '12px',
                  boxShadow: '0 0 20px rgba(0, 255, 102, 0.4)',
                  fontFamily: 'monospace',
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', color: '#00ff66' }} />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="latencyMs"
                name="Neural Latency (ms)"
                stroke="#00ff66"
                strokeWidth={3}
                dot={{ r: 4, fill: '#00ff66' }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="requestsPerSec"
                name="Quantum Throughput (Req/s)"
                stroke="#00f0ff"
                strokeWidth={2.5}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        )}

      </div>

    </section>
  );
};
