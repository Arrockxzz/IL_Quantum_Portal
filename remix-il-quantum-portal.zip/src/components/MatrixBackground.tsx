import React, { useEffect, useRef, useState } from 'react';

export type MatrixTheme = 'emerald' | 'cyan' | 'purple' | 'red' | 'amber';

interface MatrixBackgroundProps {
  theme?: MatrixTheme;
  opacity?: number;
  speed?: number;
  className?: string;
  interactive?: boolean;
}

export const MatrixBackground: React.FC<MatrixBackgroundProps> = ({
  theme = 'emerald',
  opacity = 0.85,
  speed = 1,
  className = '',
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: -1000, y: -1000, active: false });

  // Get color palettes based on theme
  const getThemeColors = (t: MatrixTheme) => {
    switch (t) {
      case 'cyan':
        return {
          head: '#ffffff',
          primary: '#00f0ff',
          trail: '#0077aa',
          dim: '#002244',
          bg: 'rgba(3, 10, 20, 0.22)',
        };
      case 'purple':
        return {
          head: '#ffffff',
          primary: '#d946ef',
          trail: '#9333ea',
          dim: '#3b0764',
          bg: 'rgba(15, 5, 25, 0.22)',
        };
      case 'red':
        return {
          head: '#ffffff',
          primary: '#ff0055',
          trail: '#be123c',
          dim: '#450a0a',
          bg: 'rgba(20, 3, 10, 0.22)',
        };
      case 'amber':
        return {
          head: '#ffffff',
          primary: '#ffaa00',
          trail: '#d97706',
          dim: '#451a03',
          bg: 'rgba(18, 10, 3, 0.22)',
        };
      case 'emerald':
      default:
        return {
          head: '#ffffff',
          primary: '#00ff66',
          trail: '#059669',
          dim: '#022c22',
          bg: 'rgba(2, 12, 8, 0.22)',
        };
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resizeCanvas = () => {
      if (canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth || window.innerWidth;
        canvas.height = canvas.parentElement.clientHeight || window.innerHeight;
      } else {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Matrix characters pool: Katakana + Binary + Hex + Math
    const katakana = 'アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン';
    const latin = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<>/{}[]+=*#%&$@!';
    const charPool = katakana + latin;

    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize) + 1;
    const drops: number[] = new Array(columns).fill(1).map(() => Math.floor(Math.random() * -100));

    let scanlineY = 0;

    const render = () => {
      const colors = getThemeColors(theme);

      // Semi-transparent background overlay for trail persistence
      ctx.fillStyle = colors.bg;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = `${fontSize}px "Courier New", monospace`;

      for (let i = 0; i < drops.length; i++) {
        const x = i * fontSize;
        const y = drops[i] * fontSize;

        // Pick random character
        const char = charPool[Math.floor(Math.random() * charPool.length)];

        // Check proximity to mouse
        const distToMouse = Math.hypot(x - mouseRef.current.x, y - mouseRef.current.y);
        const isNearMouse = interactive && distToMouse < 90;

        if (isNearMouse) {
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = colors.primary;
          ctx.shadowBlur = 12;
        } else if (drops[i] === 1 || Math.random() < 0.08) {
          ctx.fillStyle = colors.head;
          ctx.shadowColor = colors.primary;
          ctx.shadowBlur = 8;
        } else {
          ctx.fillStyle = colors.primary;
          ctx.shadowBlur = 0;
        }

        ctx.fillText(char, x, y);

        // Draw faint trailing character behind head
        if (drops[i] > 1) {
          const trailChar = charPool[Math.floor(Math.random() * charPool.length)];
          ctx.fillStyle = colors.trail;
          ctx.shadowBlur = 0;
          ctx.fillText(trailChar, x, y - fontSize);
        }

        // Reset drop when off screen
        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        drops[i] += speed * (isNearMouse ? 1.8 : 1);
      }

      // Draw subtle futuristic sweeping scanline
      scanlineY = (scanlineY + 1.5 * speed) % (canvas.height + 100);
      const gradient = ctx.createLinearGradient(0, scanlineY - 40, 0, scanlineY + 40);
      gradient.addColorStop(0, 'rgba(0,0,0,0)');
      gradient.addColorStop(0.5, colors.primary + '1a'); // 10% opacity
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, scanlineY - 40, canvas.width, 80);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        active: true,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    if (interactive) {
      canvas.addEventListener('mousemove', handleMouseMove);
      canvas.addEventListener('mouseleave', handleMouseLeave);
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
      if (interactive) {
        canvas.removeEventListener('mousemove', handleMouseMove);
        canvas.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, [theme, speed, interactive]);

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none z-0 ${className}`}>
      <canvas
        ref={canvasRef}
        style={{ opacity }}
        className="w-full h-full block pointer-events-auto cursor-crosshair"
      />
      {/* HUD Cyber Overlay Scanlines & Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,rgba(0,0,0,0.85)_100%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(255,255,255,0.02)_50%,rgba(0,0,0,0.4)_50%)] bg-[length:100%_4px] pointer-events-none opacity-40" />
    </div>
  );
};
