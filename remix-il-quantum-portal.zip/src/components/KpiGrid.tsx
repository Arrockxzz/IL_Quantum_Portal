import React from 'react';
import { TrendingUp, Users, DollarSign, Activity, ShieldCheck, Heart, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { MetricKpis } from '../types';
import { INITIAL_KPIS } from '../data/initialData';

interface KpiGridProps {
  kpis: MetricKpis;
  sessionStartKpis?: MetricKpis;
  activeFilterKey?: string;
  onSelectKpiFilter?: (key: string) => void;
}

export const KpiGrid: React.FC<KpiGridProps> = ({
  kpis,
  sessionStartKpis = INITIAL_KPIS,
  activeFilterKey,
  onSelectKpiFilter,
}) => {
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const getPercentChange = (current: number, baseline: number) => {
    if (!baseline) return 0;
    return ((current - baseline) / baseline) * 100;
  };

  // Helper to construct comparison metrics
  const createCardData = (
    id: string,
    title: string,
    value: string,
    currentNum: number,
    baselineNum: number,
    subtext: string,
    changeBenchmark: string,
    icon: any,
    color: string,
    progressVal: number,
    isLowerBetter: boolean = false
  ) => {
    const pctChange = getPercentChange(currentNum, baselineNum);
    const sessionPercentStr = `${pctChange > 0 ? '+' : ''}${pctChange.toFixed(2)}%`;
    
    // Determine if favorable or unfavorable change
    let sessionIsGood = false;
    let sessionIsBad = false;

    if (isLowerBetter) {
      sessionIsGood = pctChange < 0;
      sessionIsBad = pctChange > 0;
    } else {
      sessionIsGood = pctChange > 0;
      sessionIsBad = pctChange < 0;
    }

    return {
      id,
      title,
      value,
      pctChange,
      sessionPercentStr,
      sessionIsGood,
      sessionIsBad,
      subtext,
      changeBenchmark,
      icon,
      color,
      progressVal,
    };
  };

  const cards = [
    createCardData(
      'arr',
      'ARR (Annual Recurring)',
      formatCurrency(kpis.arr),
      kpis.arr,
      sessionStartKpis.arr,
      `+$${((kpis.arr * 0.001) / 1000).toFixed(1)}k today`,
      `+${kpis.arrGrowthYoY}% YoY`,
      DollarSign,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      82
    ),
    createCardData(
      'mrr',
      'MRR (Monthly Run Rate)',
      formatCurrency(kpis.mrr),
      kpis.mrr,
      sessionStartKpis.mrr,
      'Target: $1.25M',
      '+2.8% MoM',
      TrendingUp,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      90
    ),
    createCardData(
      'users',
      'Active Subscribers',
      kpis.activeUsers.toLocaleString(),
      kpis.activeUsers,
      sessionStartKpis.activeUsers,
      `+${kpis.activeUsersTodayDelta} active today`,
      '+14.2% MoM',
      Users,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      75
    ),
    createCardData(
      'latency',
      'System Latency (P95)',
      `${kpis.latencyMs} ms`,
      kpis.latencyMs,
      sessionStartKpis.latencyMs,
      'Peak: 64ms | SLA < 50ms',
      kpis.latencyMs < 45 ? '-4ms Optimal' : '+8ms High',
      Activity,
      kpis.latencyMs < 45 ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-amber-50 text-amber-600 border-amber-100',
      Math.max(10, 100 - kpis.latencyMs),
      true // isLowerBetter
    ),
    createCardData(
      'uptime',
      'System SLA Uptime',
      `${kpis.uptimePercent}%`,
      kpis.uptimePercent,
      sessionStartKpis.uptimePercent,
      '0 downtime incidents in 30d',
      '100% Target',
      ShieldCheck,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      99
    ),
    createCardData(
      'nps',
      'Net Promoter Score',
      `${kpis.npsScore} / 100`,
      kpis.npsScore,
      sessionStartKpis.npsScore,
      'Based on 4,200 surveys',
      'Top 5% SaaS',
      Heart,
      'bg-indigo-50 text-indigo-600 border-indigo-100',
      kpis.npsScore
    ),
  ];

  return (
    <section id="kpi-cards-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 font-mono">
      {cards.map((card) => {
        const Icon = card.icon;
        const isSelected = activeFilterKey === card.id;

        return (
          <div
            key={card.id}
            id={`kpi-card-${card.id}`}
            onClick={() => onSelectKpiFilter && onSelectKpiFilter(card.id)}
            className={`hud-card rounded-2xl p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 cursor-pointer group hover:scale-[1.02] ${
              isSelected ? 'ring-2 ring-cyan-400 border-cyan-400 shadow-[0_0_25px_#00f0ff]' : ''
            }`}
          >
            {/* Top Row: Title + Icon */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-emerald-400 text-[10px] font-extrabold uppercase tracking-widest truncate text-glow-emerald">
                  {card.title}
                </span>
                <div className="p-1.5 rounded-lg border border-emerald-400/50 bg-emerald-950/80 text-emerald-300 shadow-[0_0_8px_#00ff66] shrink-0 ml-1">
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Main Value & Visual Comparison Indicator */}
              <div className="flex items-baseline justify-between mt-1 gap-1">
                <div className="text-2xl lg:text-3xl font-black text-white tracking-tight truncate text-glow-emerald font-mono">
                  {card.value}
                </div>

                {/* Session Comparison Badge with Arrow Indicator */}
                <div className="flex flex-col items-end shrink-0 ml-1">
                  <div
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-black border transition-colors ${
                      card.sessionIsGood
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-400 shadow-[0_0_8px_#00ff66]'
                        : card.sessionIsBad
                        ? 'bg-rose-950 text-rose-300 border-rose-500 shadow-[0_0_8px_#ff0055]'
                        : 'bg-slate-900 text-slate-400 border-slate-700'
                    }`}
                    title={`Session change: ${card.sessionPercentStr} since start`}
                  >
                    {card.pctChange > 0 ? (
                      <ArrowUpRight className={`w-3.5 h-3.5 mr-0.5 shrink-0 ${card.sessionIsGood ? 'text-emerald-300' : 'text-rose-400'}`} />
                    ) : card.pctChange < 0 ? (
                      <ArrowDownRight className={`w-3.5 h-3.5 mr-0.5 shrink-0 ${card.sessionIsGood ? 'text-emerald-300' : 'text-rose-400'}`} />
                    ) : (
                      <Minus className="w-3.5 h-3.5 mr-0.5 shrink-0 text-slate-500" />
                    )}
                    <span>{card.sessionPercentStr}</span>
                  </div>
                  <span className="text-[9px] text-emerald-600 font-bold tracking-tight mt-0.5 uppercase">
                    vs matrix boot
                  </span>
                </div>
              </div>
            </div>

            {/* Subtext, Benchmark, and Progress Bar */}
            <div className="mt-3">
              <div className="w-full bg-slate-900 border border-emerald-500/30 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full rounded-full transition-all duration-500 shadow-[0_0_10px_#00ff66]"
                  style={{ width: `${card.progressVal}%` }}
                />
              </div>
              <div className="flex items-center justify-between mt-2 text-[10px] text-emerald-300/80 font-bold">
                <span className="truncate">{card.subtext}</span>
                <span className="text-[9px] text-cyan-300 font-extrabold shrink-0 ml-1">
                  {card.changeBenchmark}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </section>
  );
};

