import React, { useState } from 'react';
import { PortalSettings } from '../types';
import { Settings, X, RotateCcw, Check, Sun, Moon, Sliders, Palette } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PortalSettings;
  onUpdateSettings: (newSettings: PortalSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [localSettings, setLocalSettings] = useState<PortalSettings>(settings);

  if (!isOpen) return null;

  const handleApply = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const handleReset = () => {
    const defaultSettings: PortalSettings = {
      themePreset: 'il-orange',
      colorScheme: 'default',
      darkMode: false,
      fontSize: 'medium',
      topNLimit: 10,
      maxFileSizeMb: 25,
    };
    setLocalSettings(defaultSettings);
  };

  return (
    <div id="settings-modal-backdrop" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 font-mono">
      <div className="bg-slate-950 rounded-2xl max-w-md w-full shadow-[0_0_40px_rgba(0,255,102,0.3)] border border-emerald-500/60 overflow-hidden space-y-4">
        
        {/* Header */}
        <div className="bg-slate-900 border-b border-emerald-500/40 px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-emerald-400 text-glow-emerald" />
            <h3 className="text-base font-black uppercase text-glow-emerald">CYBER MATRIX CONFIG</h3>
          </div>
          <button onClick={onClose} className="text-emerald-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4 text-xs font-mono text-emerald-300">
          
          {/* Theme Preset */}
          <div>
            <label className="block font-black text-white uppercase mb-1.5 flex items-center gap-1 text-glow-emerald">
              <Palette className="w-3.5 h-3.5 text-emerald-400" /> MATRIX COLOR SCHEME
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'il-orange', name: 'Emerald Matrix', color: 'bg-emerald-400' },
                { id: 'corporate-blue', name: 'Cyan Cyber', color: 'bg-cyan-400' },
                { id: 'slate-dark', name: 'Neon Green', color: 'bg-emerald-500' },
                { id: 'emerald', name: 'Ultra Matrix', color: 'bg-emerald-300' },
              ].map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setLocalSettings((prev) => ({ ...prev, themePreset: preset.id as any }))}
                  className={`flex items-center space-x-2 p-2 rounded-xl border font-bold transition-all cursor-pointer ${
                    localSettings.themePreset === preset.id
                      ? 'border-emerald-400 bg-emerald-950 text-white shadow-[0_0_10px_#00ff66]'
                      : 'border-emerald-500/30 hover:bg-slate-900 text-emerald-400'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full ${preset.color} shrink-0 shadow-[0_0_6px_#00ff66]`} />
                  <span className="truncate">{preset.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Dark Mode Toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-emerald-500/40">
            <div>
              <div className="font-black text-white flex items-center gap-1.5 uppercase">
                {localSettings.darkMode ? <Moon className="w-3.5 h-3.5 text-cyan-400" /> : <Sun className="w-3.5 h-3.5 text-emerald-400" />}
                Matrix Scanline Overlay
              </div>
              <p className="text-[10px] text-emerald-500">Enable CRT terminal scanline HUD effect</p>
            </div>
            <button
              onClick={() => setLocalSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }))}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer border border-emerald-500/40 ${
                localSettings.darkMode ? 'bg-emerald-950 justify-end' : 'bg-slate-950 justify-start'
              }`}
            >
              <span className="w-4 h-4 bg-emerald-400 rounded-full shadow-[0_0_8px_#00ff66]" />
            </button>
          </div>

          {/* Font Size & Top N Limits */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-white mb-1 uppercase text-[10px]">Matrix Text Scale</label>
              <select
                value={localSettings.fontSize}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, fontSize: e.target.value as any }))}
                className="w-full bg-slate-900 border border-emerald-500/40 rounded-lg p-2 font-mono font-bold text-emerald-300 focus:outline-none focus:border-emerald-400 cursor-pointer"
              >
                <option value="small">Compact Node (Small)</option>
                <option value="medium">Default Terminal (Medium)</option>
                <option value="large">High-Def HUD (Large)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-white mb-1 uppercase text-[10px]">Top N Node Limit</label>
              <select
                value={localSettings.topNLimit}
                onChange={(e) => setLocalSettings((prev) => ({ ...prev, topNLimit: Number(e.target.value) }))}
                className="w-full bg-slate-900 border border-emerald-500/40 rounded-lg p-2 font-mono font-bold text-emerald-300 focus:outline-none focus:border-emerald-400 cursor-pointer"
              >
                <option value={5}>Top 5</option>
                <option value={10}>Top 10</option>
                <option value={15}>Top 15</option>
                <option value={25}>Top 25</option>
              </select>
            </div>
          </div>

          {/* Max Upload File Size */}
          <div>
            <label className="block font-bold text-white mb-1 uppercase text-[10px]">Max Data Stream Buffer Size (MB)</label>
            <input
              type="number"
              value={localSettings.maxFileSizeMb}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, maxFileSizeMb: Number(e.target.value) }))}
              className="w-full bg-slate-900 border border-emerald-500/40 rounded-lg p-2 font-mono font-bold text-emerald-300 focus:outline-none focus:border-emerald-400"
              min={5}
              max={100}
            />
          </div>

        </div>

        {/* Footer Buttons */}
        <div className="bg-slate-900 px-5 py-3 border-t border-emerald-500/40 flex items-center justify-between text-xs font-mono">
          <button
            onClick={handleReset}
            className="flex items-center space-x-1 text-emerald-500 hover:text-white font-bold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET DEFAULTS</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-emerald-400 hover:text-white border border-emerald-500/40 rounded-lg font-bold bg-slate-950 cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center space-x-1 px-4 py-1.5 bg-emerald-400 hover:bg-emerald-300 text-black font-black rounded-lg shadow-[0_0_12px_#00ff66] cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>APPLY CONFIG</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
